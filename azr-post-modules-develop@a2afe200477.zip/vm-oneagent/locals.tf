locals {
  dynatrace_tenant = {
    e = "ngt90313"
    d = "kgh74439"
    c = "esq60659"
    p = "esq60659"
  }

  dynatrace_tenant_new_tenant = {
    e = "uym48639"
    d = "tyq83242"
    c = "ziu50812"
    p = "ziu50812"
  }

  infra_environment_long = var.infra_environment == "e" ? "eng" : (var.infra_environment == "d" ? "dev" : (var.infra_environment == "c" ? "cert" : (var.infra_environment == "p" ? "prod" : "unknown")))
}
