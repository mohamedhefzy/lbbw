Was ist das hier? --> Repository für Post-Deployment Module. Sprich alles was nicht direkte Infrastruktur ist sondern Installationen oder Konfigurationen zB. für Shared Services auf der Infrastruktur. (Agenten etc)

Jedes Modul in einem Unterordner ablegen. Modulaufbau analog zum Modulrepository https://confluence.lbbw.sko.de/display/SKYWALKER/Modulrepository

Namenskonvention: Für diese Ebene wurde im Entwicklungsprozess kein Schema festgelegt. Einfachheitshalber ein angelehntes Schema verwenden: "<service-komponente>-<modul-name>" --> Ein Modul für die Installation von Dynatrace in der VM würde dann heißen "vm-dynatrace"

## Ansible Module Context

### Infos zum Provider
Der Ansible Terraform Provider ist kein offizieller Provider und kommt nicht von Hashicorp im gegensatz zu bsp. Azure.
D.h. azurerm ist unter hashicorp/azurerm zu finden während ansible unter ansible/ansible zu finden ist.

Terraform sucht initial jeden genutzen Provider unter hashicorp/#providername#, es sei denn es wird innerhalb des required_providers Block etwas anderes angegeben.

Die Angabe von ansible/ansible im required_providers Block auf Ebene des lz-templates / ops-templates, ergo auf der Ebene in dem der Modulaufruf vom vm-testlocal (dieses Modul) stattfindet ist 'nicht' ausreichend!

Der benötigte Provider Transfer vom Modulaufruf innerhalb des Moduls hinein findet nicht statt. Innerhalb des Moduls wird nach einem hashicorp/ansible provider gesucht, wenn dort keine explizite Angabe im required_providers block stattfindet.

Die Provider Deklaration muss deshalb innerhalb des Moduls erfolgen

#### Wie kann ich die verwendeten Provider herausfinden?
Dieser Test wird per lokaler Terraform ausführung getestet.

Innerhalb des vm-testlocal moduls kann 'terraform providers' aufgerufen werden. Damit werden die benötigten Provider angezeigt. Der Befehl kann ebenfalls aus dem template repository, in dem der Modulaufruf stattfindet ausgeführt werden. Dann werden die benötigten Provider für das template und das Modul separat angezeigt. 
Sofern _nur_ auf der template Ebene die Provider deklariert sind, wird der Unterschied zum 'default' Provider innerhalb des Moduls deutlich.