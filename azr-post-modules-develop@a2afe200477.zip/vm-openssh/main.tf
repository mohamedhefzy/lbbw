# *must* be declared within the module since it is no official provider
terraform {
  required_providers {
    ansible = {
      source = "ansible/ansible"
    }
  }
}

resource "ansible_playbook" "deploy_openssh_windows" {
  # referencing from module call (lz-template) point of view
  for_each = var.vm_windows_ips != null ? var.vm_windows_ips : {}

  playbook   = "../../azr-post-modules/vm-openssh/playbook_openssh_windows.yml"
  name       = each.value
  replayable = true
  verbosity  = 2

  extra_vars = {
    # relevant for ansible ssh
    ansible_username = var.ansible_username
    ansible_password = var.vm_passwords_windows[each.key]

    # relevant for downloading midserver package
    artifactory_user  = var.artifactory_user
    artifactory_token = var.artifactory_token

    # This is a workaround until packages are all correctly staged. Then URL has to be changed again.
    artifactory_url = var.infra_environment == "e" ? "https://artifactory.lbbw.sko.de/artifactory/skywalker-packages-src/tools" : var.artifactory_url

    # relevant for setting target eventhub
    infra_environment = var.infra_environment

    openssh_package_state = var.TF_APPLY == "False" ? "absent" : "present"
  }
}
