## Ansible OpenSSH Module

Module is especially designed for windows vm's and does not work on linux

Approach:

The pipeline will 
- download MID server agent client collector installation package from Artifactory
- download installation script from Artifactory to Windows machine

The Ansible playbook
- executes the installation using the installation script



# OpenSSH Ansible collection

Ansible collection for deploying OpenSSH.

## Description

The OpenSSH Ansible collection is a collection consisting of a single role that handles the installation and configuration of the OpenSSH and ensures the service remains in a running state.

## Requirements

- Ansible >= 2.15.0
- pywinrm >= 0.4.3 (Windows only)

## Installation

The playbook_openssh_windows.yml is being run by the main.tf ansible_playbook resource block.
The written Ansible Code consist of one role which manages the installation specific for windows and linux system automatically.

## Variables

| Name               | Description                                                               | Type   |
| ------------------ | ------------------------------------------------------------------------- | -------|
| infra_environment | This variable defines the environment to be built. (Prod,Cert,Dev,Engineering). | string |
| TF_APPLY | Gets info if a Apply or Destroy is being run. | string |
| vm_windows_ips | Windows VM IPs. | map(string) |
| vm_passwords_windows | Windows VM Password. | map(string) |
| ansible_username | vm username for ansible to use. | object |
| artifactory_user | artifactory user for downloading installer package. | string |
| artifactory_token | artifactory Token for downloading installer package. | string |
| artifactory_url | Installation package name (URL) in Artifactory. | string |
## Output

| Name             | Description                                                                                                       |
| ---------------- | ----------------------------------------------------------------------------------------------------------------- |

## Required Modules
- vm
