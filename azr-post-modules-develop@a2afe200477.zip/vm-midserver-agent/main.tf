# *must* be declared within the module since it is no official provider
terraform {
  required_providers {
    ansible = {
      source = "ansible/ansible"
    }
  }
}

resource "ansible_playbook" "deploy_midserver_linux" {
  # referencing from module call (lz-template) point of view
  for_each = var.vm_linux_ips != null ? var.vm_linux_ips : {}

  playbook   = "../../azr-post-modules/vm-midserver-agent/playbook_midserver-agent_linux.yml"
  name       = each.value
  replayable = true
  verbosity  = 2

  extra_vars = {
    # relevant for ansible ssh
    ansible_username = var.ansible_username
    ansible_password = var.vm_passwords_linux[each.key]

    # relevant for downloading midserver package
    artifactory_user  = var.artifactory_user
    artifactory_token = var.artifactory_token
    artifactory_url   = var.infra_environment == "e" ? "https://artifactory.lbbw.sko.de/artifactory/skywalker-packages-src/tools" : var.artifactory_url

    # relevant for setting target eventhub
    infra_environment = var.infra_environment

    # MidServer instance details
    midserver_instance = var.is_old_tenant ? "wss://${local.midserver_instance[var.infra_environment]}:8800/ws/events" : "wss://${local.midserver_instance_new_tenant[var.infra_environment]}:8800/ws/events"
    MIDSERVER_TOKEN    = var.MIDSERVER_TOKEN

    ms_agent_package_state = var.TF_APPLY == "False" ? "absent" : "present"
  }
}

resource "ansible_playbook" "deploy_midserver_windows" {
  # referencing from module call (lz-template) point of view
  for_each = var.vm_windows_ips != null ? var.vm_windows_ips : {}

  playbook   = "../../azr-post-modules/vm-midserver-agent/playbook_midserver-agent_windows.yml"
  name       = each.value
  replayable = true
  verbosity  = 3

  extra_vars = {
    # relevant for ansible ssh
    ansible_username = var.ansible_username
    ansible_password = var.vm_passwords_windows[each.key]

    # relevant for downloading midserver package
    artifactory_user  = var.artifactory_user
    artifactory_token = var.artifactory_token
    artifactory_url   = var.infra_environment == "e" ? "https://artifactory.lbbw.sko.de/artifactory/skywalker-packages-src/tools" : var.artifactory_url

    # relevant for setting target eventhub
    infra_environment = var.infra_environment

    # MidServer instance details
    midserver_instance = var.is_old_tenant ? "wss://${local.midserver_instance[var.infra_environment]}:8800/ws/events" : "wss://${local.midserver_instance_new_tenant[var.infra_environment]}:8800/ws/events"
    MIDSERVER_TOKEN    = var.MIDSERVER_TOKEN

    ms_agent_package_state = var.TF_APPLY == "False" ? "absent" : "present"
  }
}
