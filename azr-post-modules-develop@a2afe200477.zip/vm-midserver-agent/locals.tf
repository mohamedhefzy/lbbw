locals {
  # to do --- Add instances for all other stages
  midserver_instance = {
    e = "10.238.x.x"
    d = "10.235.6.52"
    c = "10.135.x.x"
    p = "10.35.x.x"
  }

  midserver_instance_new_tenant = {
    e = "10.238.x.x"
    d = "10.235.6.52"
    c = "10.135.x.x"
    p = "10.35.x.x"
  }
}