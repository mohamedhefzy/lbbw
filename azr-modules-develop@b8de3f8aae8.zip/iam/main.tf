provider "kubernetes" {
  host                   = var.cluster_config.host
  username               = var.cluster_config.username
  password               = var.cluster_config.password
  client_certificate     = var.cluster_config.client_certificate
  client_key             = var.cluster_config.client_key
  cluster_ca_certificate = var.cluster_config.cluster_ca_certificate
}

data "azurerm_client_config" "current" {
  # Returns the values of the currently logged in user
  # client_id         - is set to the Azure Client ID (Application Object ID).
  # tenant_id         - is set to the Azure Tenant ID.
  # subscription_id   - is set to the Azure Subscription ID.
  # object_id         - is set to the Azure Object ID.
}

data "azurerm_subscription" "current" {}

data "azurerm_user_assigned_identity" "toolchain_mi_app" {
  count               = var.lz_type == "aks" ? 1 : 0
  name                = "${local.name_prefix}-mid-${local.prefix_app_name}-app"
  resource_group_name = "${local.name_prefix}-rg-${local.prefix_app_name}-infra"
}

data "azurerm_resource_group" "aks" {
  count = var.aks_cluster_id != "" ? 1 : 0
  name  = "${local.name_prefix}-rg-${local.prefix_app_name}-aks-cluster"
}


##############################################################
#
# Special Permissions for Landing Zone specific Managed Identity
#
##############################################################

resource "azurerm_role_assignment" "managed-identity-aks-cluster-user" {
  count = var.aks_cluster_id != "" ? 1 : 0

  scope                = data.azurerm_subscription.current.id
  role_definition_name = "Azure Kubernetes Service Cluster Admin Role"
  principal_id         = data.azurerm_client_config.current.object_id
}

resource "azurerm_role_assignment" "managed-identity-aks-rbac-cluster-admin" {
  count = var.aks_cluster_id != "" ? 1 : 0

  scope                = data.azurerm_subscription.current.id
  role_definition_name = "Azure Kubernetes Service RBAC Cluster Admin"
  principal_id         = data.azurerm_client_config.current.object_id
}


##############################################################
#
# Platform Developer 
#
##############################################################


# add Platform Developer to PostgreSQL Database authentication in Engineering Stage
resource "azurerm_postgresql_flexible_server_active_directory_administrator" "postgres_platform_developer" {
  for_each = var.postgres_server_names != {} && var.infra_environment == "e" ? var.postgres_server_names : {}

  server_name         = each.value
  resource_group_name = "${var.lbbw_location}-${var.infra_environment}-rg-${var.app_environment}${var.app_name}-psql"
  tenant_id           = data.azurerm_client_config.current.tenant_id
  object_id           = "da376cbf-5d78-4ebb-9659-e23af7f55aa3"
  principal_name      = "nm_a_e_SKYWALKER_Plattformdeveloper-dbaccess"
  principal_type      = "Group"
}

##############################################################
#
# Application Developer 
#
##############################################################

resource "azurerm_role_assignment" "app-developer-tier1" {
  for_each = var.infra_environment != "e" || var.is_iam_enabled ? toset(lookup(lookup(local.app-developer-tier1, var.app_type), var.infra_environment)) : []

  scope                = data.azurerm_subscription.current.id
  role_definition_name = each.value
  principal_id         = lookup(var.iam-entra-object-ids, "app-developer-tier1")
}

resource "azurerm_role_assignment" "app-developer-tier1_key_vault" {
  count = var.infra_environment == "e" || var.infra_environment == "d" ? 1 : 0

  scope                = var.keyvault_keyvault_ids.app
  role_definition_name = "Key Vault Administrator"
  principal_id         = lookup(var.iam-entra-object-ids, "app-developer-tier1")
}

resource "azurerm_role_assignment" "app-developer-tier1_aks_ns" {
  for_each = var.infra_environment == "e" || var.infra_environment == "d" ? local.all_created_namespaces : {}

  scope                = "${var.aks_cluster_id}/namespaces/${each.key}"
  role_definition_name = "cr_Azure Kubernetes Service RBAC Writer on namespace level - customized"
  principal_id         = lookup(var.iam-entra-object-ids, "app-developer-tier1")
}

# add Application Developer to PostgreSQL Database authentication
resource "azurerm_postgresql_flexible_server_active_directory_administrator" "app-developer-tier1_postgres" {
  for_each = var.postgres_server_names != {} && var.infra_environment == "d" ? var.postgres_server_names : {}

  server_name         = each.value
  resource_group_name = "${var.lbbw_location}-${var.infra_environment}-rg-${var.app_environment}${var.app_name}-psql"
  tenant_id           = data.azurerm_client_config.current.tenant_id
  object_id           = lookup(var.iam-entra-object-ids, "app-developer-tier1")
  principal_name      = "nm_a_${var.infra_environment}-${var.lbbw_location}-${var.app_type}-${var.app_environment}${var.app_name}_app-developer-tier1" # "nm_a_c-eufho-spoke-xmico_app-developer-tier1"        # 
  principal_type      = "Group"
}


##############################################################
#
# Application Support
#
##############################################################


# DEV STAGE: add Application Support to PostgreSQL Database authentication
resource "azurerm_postgresql_flexible_server_active_directory_administrator" "postgres_app_support_dev" {
  for_each = var.postgres_server_names != {} && var.infra_environment == "d" ? var.postgres_server_names : {}

  server_name         = each.value
  resource_group_name = "${var.lbbw_location}-${var.infra_environment}-rg-${var.app_environment}${var.app_name}-psql"
  tenant_id           = data.azurerm_client_config.current.tenant_id
  object_id           = "450efd5f-9727-4726-a97a-29035a12d5fc"
  principal_name      = "nm_a_d_SKYWALKER_as-dbaccess"
  principal_type      = "Group"
}


# CERT STAGE: add Application Support to PostgreSQL Database authentication
resource "azurerm_postgresql_flexible_server_active_directory_administrator" "postgres_app_support_cert" {
  for_each = var.postgres_server_names != {} && var.infra_environment == "c" ? var.postgres_server_names : {}

  server_name         = each.value
  resource_group_name = "${var.lbbw_location}-${var.infra_environment}-rg-${var.app_environment}${var.app_name}-psql"
  tenant_id           = data.azurerm_client_config.current.tenant_id
  object_id           = "75327254-65b4-45e2-b028-942ff7dae0e0"
  principal_name      = "nm_a_c_SKYWALKER_as-dbaccess"
  principal_type      = "Group"
}


# PROD STAGE: add Application Support to PostgreSQL Database authentication
resource "azurerm_postgresql_flexible_server_active_directory_administrator" "postgres_app_support_prod" {
  for_each = var.postgres_server_names != {} && var.infra_environment == "p" ? var.postgres_server_names : {}

  server_name         = each.value
  resource_group_name = "${var.lbbw_location}-${var.infra_environment}-rg-${var.app_environment}${var.app_name}-psql"
  tenant_id           = data.azurerm_client_config.current.tenant_id
  object_id           = "05ba0ed9-85e8-41f2-ba30-1cfb9ec7b759"
  principal_name      = "nm_a_p_SKYWALKER_as-dbaccess"
  principal_type      = "Group"
}



##############################################################
#
# Platform Support (3rd Level)
#
##############################################################


# DEV STAGE: add Platform Support (3rd Level) to PostgreSQL Database authentication
resource "azurerm_postgresql_flexible_server_active_directory_administrator" "postgres_3rdlvl_platform_support_dev" {
  for_each = var.postgres_server_names != {} && var.infra_environment == "d" ? var.postgres_server_names : {}

  server_name         = each.value
  resource_group_name = "${var.lbbw_location}-${var.infra_environment}-rg-${var.app_environment}${var.app_name}-psql"
  tenant_id           = data.azurerm_client_config.current.tenant_id
  object_id           = "01e8baf2-e474-459c-9945-a088ecadb9b0"
  principal_name      = "nm_a_d_SKYWALKER_3rd-Lvl-ps-dbaccess"
  principal_type      = "Group"
}


# CERT STAGE: add Platform Support (3rd Level) to PostgreSQL Database authentication
resource "azurerm_postgresql_flexible_server_active_directory_administrator" "postgres_3rdlvl_platform_support_cert" {
  for_each = var.postgres_server_names != {} && var.infra_environment == "c" ? var.postgres_server_names : {}

  server_name         = each.value
  resource_group_name = "${var.lbbw_location}-${var.infra_environment}-rg-${var.app_environment}${var.app_name}-psql"
  tenant_id           = data.azurerm_client_config.current.tenant_id
  object_id           = "8a14c8f0-366a-4fb3-84bd-34bba91ac383"
  principal_name      = "nm_a_c_SKYWALKER_3rd-Lvl-ps-dbaccess"
  principal_type      = "Group"
}


# PROD STAGE: add Platform Support (3rd Level) to PostgreSQL Database authentication
resource "azurerm_postgresql_flexible_server_active_directory_administrator" "postgres_3rdlvl_platform_support_prod" {
  for_each = var.postgres_server_names != {} && var.infra_environment == "p" ? var.postgres_server_names : {}

  server_name         = each.value
  resource_group_name = "${var.lbbw_location}-${var.infra_environment}-rg-${var.app_environment}${var.app_name}-psql"
  tenant_id           = data.azurerm_client_config.current.tenant_id
  object_id           = "35a6d49c-072d-4429-866d-7f34e43d20b2"
  principal_name      = "nm_a_p_SKYWALKER_3rd-Lvl-ps-dbaccess"
  principal_type      = "Group"
}


##############################################################
#
# Zugriff erforderlich für Toolchain Deployments
#
##############################################################

resource "azurerm_role_assignment" "toolchain_mi_app_aks_cluster_user" {
  count = var.lz_type == "aks" && var.aks_cluster_id != "" ? 1 : 0

  scope                = data.azurerm_resource_group.aks[0].id
  role_definition_name = "cr_Azure Kubernetes Service Cluster User Role - customized"
  principal_id         = data.azurerm_user_assigned_identity.toolchain_mi_app[0].principal_id
}

resource "kubernetes_role" "toolchain_mi_app_aks_customer_ns_r" {
  for_each = local.all_created_namespaces != {} ? local.all_created_namespaces : {}

  metadata {
    name      = "external-secrets-r"
    namespace = each.key
  }

  rule {
    api_groups = ["external-secrets.io"]
    resources  = ["externalsecrets", "secretstores"]
    verbs      = ["get", "list", "watch", "create", "update", "patch", "delete"]
  }

  rule {
    api_groups = [""]
    resources  = ["pods", "pods/log", "services", "configmaps", "secrets", "persistentvolumeclaims"]
    verbs      = ["get", "list", "watch", "create", "update", "patch", "delete"]
  }

  rule {
    api_groups = ["apps"]
    resources  = ["deployments", "replicasets", "statefulsets", "daemonsets"]
    verbs      = ["get", "list", "watch", "create", "update", "patch", "delete"]
  }

  rule {
    api_groups = ["networking.k8s.io"]
    resources  = ["ingresses", "networkpolicies"]
    verbs      = ["get", "list", "watch", "create", "update", "patch", "delete"]
  }

  rule {
    api_groups = ["rbac.authorization.k8s.io"]
    resources  = ["roles", "rolebindings"]
    verbs      = ["get", "list", "watch", "create", "update", "patch", "delete"]
  }

  rule {
    api_groups = [""]
    resources  = ["serviceaccounts", "users", "groups"]
    verbs      = ["get", "list", "watch", "create", "update", "patch", "delete"]
  }
}

resource "kubernetes_role_binding" "toolchain_mi_app_aks_customer_ns_rb" {
  for_each = var.lz_type == "aks" ? local.all_created_namespaces != {} ? local.all_created_namespaces : {} : {}

  metadata {
    name      = "external-secrets-rb"
    namespace = each.key
  }
  role_ref {
    api_group = "rbac.authorization.k8s.io"
    kind      = "Role"
    name      = kubernetes_role.toolchain_mi_app_aks_customer_ns_r[each.key].metadata[0].name
  }

  subject {
    api_group = "rbac.authorization.k8s.io"
    kind      = "User"
    name      = data.azurerm_user_assigned_identity.toolchain_mi_app[0].principal_id
  }
}

resource "azurerm_resource_group" "rg-iam" {
  name     = "${local.name_prefix}-rg-${local.prefix_app_name}-iam"
  location = var.location

  tags = var.tags

  lifecycle {
    ignore_changes = [
      tags["CreationDateTime"],
      tags["Owner"],
      tags["Environment"],
      tags["ITAB"],
      tags["AppName"],
      tags["AppEnv"],
      tags["SubscriptionType"],
      tags["PlatformId"],
      tags["Availability"],
      tags["Confidentiality"],
      tags["Integrity"]
    ]
  }
}

resource "azurerm_role_definition" "custom-mid-roles" {
  for_each    = var.iam_mids
  name        = "${local.name_prefix}-midrole-${local.prefix_app_name}-${each.key}"
  scope       = each.value.scope != null ? each.value.scope : "${data.azurerm_subscription.current.id}"
  description = "Custom role for custom mids"

  permissions {
    actions      = each.value.actions
    data_actions = each.value.data_actions
    not_actions  = []
  }

  assignable_scopes = [
    each.value.scope != null ? each.value.scope : data.azurerm_subscription.current.id,
  ]
}

resource "azurerm_user_assigned_identity" "custom-mids" {
  for_each            = var.iam_mids
  location            = azurerm_resource_group.rg-iam.location
  name                = "${local.name_prefix}-mid-${local.prefix_app_name}-${each.key}"
  resource_group_name = azurerm_resource_group.rg-iam.name

  tags = var.tags

  lifecycle {
    ignore_changes = [
      tags["Owner"],
      tags["Environment"],
      tags["ITAB"],
      tags["AppName"],
      tags["SubscriptionType"],
      tags["PlatformId"],
      tags["Availability"],
      tags["Confidentiality"],
      tags["Integrity"]
    ]
  }
}

resource "azurerm_role_assignment" "custom-mid-role-assignments" {
  for_each           = var.iam_mids
  scope              = each.value.scope != null ? each.value.scope : "${data.azurerm_subscription.current.id}"
  principal_id       = azurerm_user_assigned_identity.custom-mids[each.key].principal_id
  role_definition_id = azurerm_role_definition.custom-mid-roles[each.key].role_definition_resource_id
}

resource "time_sleep" "wait_45_seconds_before_psql_ad_admin" {
  create_duration = "45s"

  depends_on = [azurerm_user_assigned_identity.custom-mids]
}

resource "azurerm_postgresql_flexible_server_active_directory_administrator" "postgres_active_directory_administrator" {
  for_each            = var.postgres_server_names != {} ? local.map_mids_to_psql_servers : {}
  server_name         = each.value.server_name_key
  resource_group_name = "${var.lbbw_location}-${var.infra_environment}-rg-${var.app_environment}${var.app_name}-psql"
  tenant_id           = data.azurerm_client_config.current.tenant_id
  object_id           = azurerm_user_assigned_identity.custom-mids[each.value.mid_key].principal_id
  principal_name      = azurerm_user_assigned_identity.custom-mids[each.value.mid_key].name
  principal_type      = "ServicePrincipal"

  depends_on = [
    time_sleep.wait_45_seconds_before_psql_ad_admin
  ]
}

// AKS Connection

resource "kubernetes_service_account" "custom-identity-sa" {
  for_each = var.aks_cluster_id != "" ? var.iam_mids : {}
  metadata {
    name      = "custom-identity-${each.key}"
    namespace = each.value.namespace
    annotations = {
      "azure.workload.identity/client-id" : azurerm_user_assigned_identity.custom-mids[each.key].client_id
      "azure.workload.identity/tenant-id" : data.azurerm_client_config.current.tenant_id
    }
  }
}

resource "azurerm_federated_identity_credential" "custom-federated-identity" {
  for_each            = var.aks_cluster_id != "" ? var.iam_mids : {}
  name                = each.key
  resource_group_name = azurerm_resource_group.rg-iam.name
  parent_id           = azurerm_user_assigned_identity.custom-mids[each.key].id
  audience            = ["api://AzureADTokenExchange"]
  issuer              = var.oidc_issuer_url
  subject             = "system:serviceaccount:${each.value.namespace}:custom-identity-${each.key}"
}
