# Identity and Access Management (IAM)
Identity and Access Management (IAM) is required to manage and control user's access permissions. This module is mainly used to associate Entra ID Security Groups to Azure RBAC Roles on subscription level.

## Setup and Delivery of Security Groups
During bootstrapping process of a new project, Entra ID Security Groups will be created for each application for alle three stages. These security groups will be made available in the eng.iam.auto.tfvars.json file which contains the tier-based secrutiy groups for each role.

## Built-in RRBAC Roles
Where possible and sufficient, built-in RBAC roles will be assiged to security groups. Assignments to users are prohibited.

## Custom RRBAC Roles
Few custom roles have been identified and need to be created. These roles need to be createdon Entra ID level as central RBAC roles for assignment on subscriptions

## Role Assignments on Azure Resource Groups (not in scope of this module)
Role assignments on Azure Resource Groups are handeled individually in each Terraform Module due to cross references. In order to avoid (dead locks in) dependencies, there will be specific sections in main.tf. of the respective module to maintain assignments.

