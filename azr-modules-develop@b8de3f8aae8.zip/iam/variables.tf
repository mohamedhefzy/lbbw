variable "lz_type" {
  description = "This variable defines the landing zone type (aks or vm, defaults to aks)"
  type        = string
}

variable "app_environment" {
  description = "This variable defines the app environment of the specific application. Placeholder is 'x' if nothing is set."
  type        = string
}

variable "app_name" {
  description = "Name of the application per subscription"
  type        = string
}

variable "app_type" {
  description = "Type of app (shared, spoke...)"
  type        = string
}

variable "lbbw_location" {
  description = "LBBW Location"
  type        = string
}

variable "location" {
  description = "Azure location"
  type        = string
}

variable "infra_environment" {
  description = "This variable defines the environment to be built. (Prod,Cert,Dev,Engineering)."
  type        = string
}

variable "sbk" {
  description = "This variable defines the 'Schutzbedarfsklasse' (1, 2, 3, 4)"
  type        = string
}

variable "availability" {
  description = "The variable defines the availability (V1, V2, V3, V4)"
  type        = string
}

variable "patchwindow" {
  description = "This variable defines the patchwindow (Option1, Option2, Option3)"
  type        = string
}

variable "backupretention" {
  description = "This variable defines the backupretention (SHORT, MID, LONG)"
  type        = string
}

variable "tags" {
  description = "Map of Tags per subscription"
  type        = map(string)
}

variable "is_iam_enabled" {
  description = "Toggle to disable IAM Entra RBAC role assignments in engineering"
  type        = bool
}

variable "iam-entra-object-ids" {
  description = "Map of Entra Security Group Object IDs for role assignments"
  type        = map(string)
}

variable "keyvault_keyvault_ids" {
  description = "The ids of all keyvaults"
  type        = map(string)
}

variable "kubernetes_customer_namespaces" {
  description = "The custom namespaces on which customers should have access to."
  type        = map(string)
  default     = {}
}

variable "kubernetes_restore_namespaces" {
  description = "The restore namespaces on which customers should have access to in order to restore AKS resources."
  type        = map(string)
  default     = {}
}

variable "aks_cluster_id" {
  description = "The id of the AKS cluster"
  type        = string
  default     = ""
}

variable "cluster_config" {
  description = "Kubernetes Cluster Konfigurationsdetails"
  type = object({
    host                   = string
    username               = string
    password               = string
    client_certificate     = string
    client_key             = string
    cluster_ca_certificate = string
  })
}

variable "iam_mids" {
  description = "Custom managed identities"
  type = map(object({
    scope        = string
    actions      = list(string)
    data_actions = list(string)
    namespace    = string
  }))
}

variable "postgres_server_names" {
  description = "This configuration is used for RBAC permissions from managed identity assigned on postgres."
  type        = map(string)
}

variable "oidc_issuer_url" {
  description = "The oidc issuer url of AKS"
  type        = string
}

variable "aks_rg_name" {
  description = "The `azurerm_kubernetes_cluster`'s resource group name."
  type        = string
}