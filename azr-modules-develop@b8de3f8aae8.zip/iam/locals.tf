locals {
  name_prefix     = "${var.lbbw_location}-${var.infra_environment}"
  prefix_app_name = "${var.app_environment}${var.app_name}"

  map_mids_to_psql_servers = {
    for mapped_mid in(flatten(
      [
        for mid_key, mid in var.iam_mids : [
          for server_key, server_name_key in var.postgres_server_names : {
            key             = "${mid_key}-${server_key}"
            mid_key         = mid_key
            server_name_key = server_name_key
          }
        ]
    ])) : mapped_mid.key => mapped_mid
  }

  all_created_namespaces = merge(var.kubernetes_customer_namespaces, var.kubernetes_restore_namespaces)

  ##############################################################
  #
  # Application/Landing Zone Developer 
  #
  ##############################################################

  app-developer-base = {
    spoke = {
      e = [],
      d = [],
      c = [],
      p = []
    },
    shared = {
      e = [],
      d = [],
      c = [],
      p = []
    }
  }

  # Key Vault Administrator Role is directly assigned to the users
  app-developer-tier1 = {
    spoke = {
      e = [
        "Reader",
        "Virtual Machine Administrator Login",
        "Storage Blob Data Contributor",
        "Storage File Data Privileged Contributor",
        "Storage File Data SMB Share Contributor",
        "SQL DB Contributor",
        "Virtual Machine Administrator Login",
        "cr_Azure Kubernetes Service Cluster User Role - customized"
      ],
      d = [
        "Reader",
        "Virtual Machine Administrator Login",
        "Storage Blob Data Contributor",
        "Storage File Data Privileged Contributor",
        "Storage File Data SMB Share Contributor",
        "SQL DB Contributor",
        "Virtual Machine Administrator Login",
        "cr_Azure Kubernetes Service Cluster User Role - customized"
      ],
      c = [
        "Reader"
      ],
      p = [
        "Reader"
      ]
    },
    # TBD what rights or roles should exist for shared services.
    shared = {
      e = [
        "Reader",
        "Virtual Machine Administrator Login",
        "Storage Blob Data Contributor",
        "Storage File Data Privileged Contributor",
        "Storage File Data SMB Share Contributor",
        "SQL DB Contributor",
        "cr_Azure Kubernetes Service Cluster User Role - customized",
        "Virtual Machine Administrator Login"
      ],
      d = [
        "Reader",
        "Virtual Machine Administrator Login",
        "Storage Blob Data Contributor",
        "Storage File Data Privileged Contributor",
        "Storage File Data SMB Share Contributor",
        "SQL DB Contributor",
        "cr_Azure Kubernetes Service Cluster User Role - customized",
        "Virtual Machine Administrator Login"
      ],
      c = [
        "Reader",
        "Virtual Machine Administrator Login",
        "Storage Blob Data Contributor",
        "Storage File Data Privileged Contributor",
        "Storage File Data SMB Share Contributor",
        "SQL DB Contributor",
        "cr_Azure Kubernetes Service Cluster User Role - customized",
        "Virtual Machine Administrator Login"
      ],
      p = [
        "Reader",
        "Virtual Machine Administrator Login",
        "Storage Blob Data Contributor",
        "Storage File Data Privileged Contributor",
        "Storage File Data SMB Share Contributor",
        "SQL DB Contributor",
        "cr_Azure Kubernetes Service Cluster User Role - customized",
        "Virtual Machine Administrator Login"
      ]
    }
  }
  # app-support_tier1 = {
  #   spoke = {
  #     e = [],
  #     d = [],
  #     c = [],
  #     p = []
  #   }
  # }
}
