locals {
  infra_environment_long = var.infra_environment == "e" ? "eng" : (var.infra_environment == "d" ? "dev" : (var.infra_environment == "c" ? "cert" : (var.infra_environment == "p" ? "prod" : "unknown")))
  name_prefix            = "${var.lbbw_location}-${var.infra_environment}"
  prefix_app_name        = "${var.app_environment}${var.app_name}"

  lbbw_location_pin = var.is_old_tenant ? "euaho" : var.lbbw_location
}