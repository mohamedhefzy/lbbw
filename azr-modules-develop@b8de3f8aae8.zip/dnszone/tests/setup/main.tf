provider "azurerm" {
  features {}
  subscription_id = "541ac1c2-8b44-4aac-abdf-3ce58dd8f753"
}

module "dnszone" {
  source            = "../../"
  app_environment   = var.app_environment
  app_name          = var.app_name
  app_type          = var.app_type
  lbbw_location     = var.lbbw_location
  location          = var.location
  infra_environment = var.infra_environment
  sbk               = var.sbk
  tags = {
    source         = "terraform"
    environment    = "development"
    "ITAB"         = "7656"
    "AppName"      = "test"
    "Owner"        = "test"
    "Creator"      = "iac-admin"
    "ServerRole"   = "container-platform"
    "CreationDate" = "auto-generated"
  }

  ntwspoke_vnet_id = "/subscriptions/xxx-xxx-xxx-xxx-xxx/resourceGroups/euho-e-rg-xtest-ntw/providers/Microsoft.Network/virtualNetworks/euho-e-vnet-xtest"
}