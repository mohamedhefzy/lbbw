run "execute" {
  module {
    source = "./setup"
  }

  command = plan

  assert {
    condition     = module.dnszone.rg_name == "euho-e-rg-xtest-dns"
    error_message = "The rg name does not match"
  }
}