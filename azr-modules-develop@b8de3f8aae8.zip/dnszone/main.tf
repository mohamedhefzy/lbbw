resource "azurerm_resource_group" "rg-dns" {
  name     = "${local.name_prefix}-rg-${local.prefix_app_name}-dns"
  location = var.location

  tags = var.tags

  lifecycle {
    ignore_changes = [
      tags["CreationDateTime"],
      tags["Owner"],
      tags["Environment"],
      tags["ITAB"],
      tags["AppName"],
      tags["AppEnv"],
      tags["SubscriptionType"],
      tags["PlatformId"],
      tags["Availability"],
      tags["Confidentiality"],
      tags["Integrity"]
    ]
  }
}

resource "azurerm_private_dns_zone" "private_dns_zone" {
  name                = "${local.prefix_app_name}.${local.infra_environment_long}.${local.lbbw_location_pin}.azure.lbbw.cloud"
  resource_group_name = azurerm_resource_group.rg-dns.name

  provisioner "local-exec" {
    when    = destroy
    command = "chmod +x ../../azr-modules/dnszone/delete_dnsvnetlink.sh"
  }

  provisioner "local-exec" {
    when    = destroy
    command = "../../azr-modules/dnszone/delete_dnsvnetlink.sh"
    environment = {
      resource_group_name = self.resource_group_name
      dns_zone_name       = self.name
    }
  }

  tags = var.tags

  lifecycle {
    ignore_changes = [
      tags["CreationDateTime"],
      tags["Owner"],
      tags["Environment"],
      tags["ITAB"],
      tags["AppName"],
      tags["AppEnv"],
      tags["SubscriptionType"],
      tags["PlatformId"],
      tags["Availability"],
      tags["Confidentiality"],
      tags["Integrity"]
    ]
  }
}

resource "azurerm_private_dns_zone_virtual_network_link" "vnetlink" {
  name                  = "vnetlink-to-${local.name_prefix}-vnet-${local.prefix_app_name}"
  resource_group_name   = azurerm_resource_group.rg-dns.name
  private_dns_zone_name = azurerm_private_dns_zone.private_dns_zone.name
  virtual_network_id    = var.ntwspoke_vnet_id
  registration_enabled  = true

  tags = var.tags

  lifecycle {
    ignore_changes = [
      tags["CreationDateTime"],
      tags["Owner"],
      tags["Environment"],
      tags["ITAB"],
      tags["AppName"],
      tags["AppEnv"],
      tags["SubscriptionType"],
      tags["PlatformId"],
      tags["Availability"],
      tags["Confidentiality"],
      tags["Integrity"]
    ]
  }
}
