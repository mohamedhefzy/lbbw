output "private_dns_rg_name" {
  description = "Resource Group private DNS Zone"
  value       = azurerm_resource_group.rg-dns.name
}

output "private_dns_zone_id" {
  description = "ID of the private DNS Zone"
  value       = azurerm_private_dns_zone.private_dns_zone.id
}

output "private_dns_zone_name" {
  description = "Name of the private DNS Zone"
  value       = azurerm_private_dns_zone.private_dns_zone.name
}

output "private_dns_vnetlink_id" {
  description = "VNetLink ID of the private DNS Zone"
  value       = azurerm_private_dns_zone_virtual_network_link.vnetlink.id
}
