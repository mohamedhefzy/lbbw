# DNS Zone

This module is used to deploy a DNS Zone.

## Created Resources

This module creates the following resources on azure

- ``azurerm_resource_group.rg-dns``: A resource group where the following resources are located.
- ``azurerm_private_dns_zone.private_dns_zone``: The private dns zone
- ``azurerm_private_dns_zone_virtual_network_link.vnetlink``: The connection between the vent and the private dns zone.


## Variables

| Name               | Description                                                               | Type   |
| ------------------ | ------------------------------------------------------------------------- | ------ |
| app_environment | This variable defines the app environment of the specific application. Placeholder is 'x' if nothing is set. | string |
| app_name | Name of the application per subscription. | string |
| app_type | Type of app (shared, spoke...) | string |
| lbbw_location | LBBW Location | string |
| location | Azure location | string |
| infra_environment | This variable defines the environment to be built. (Prod,Cert,Dev,Engineering). | string |
| sbk | This variable defines the 'Schutzbedarfsklasse' (1, 2, 3, 4) | string |
| ntwspoke_vnet_id | The id of the vnet. | string |
| tags | Map of Tags per subscription | map(string) |


## Output

| Name                 | Description                                                                                                       |
| -------------------- | ----------------------------------------------------------------------------------------------------------------- |
| rg_name | The name of the resource group. (Tests) |
| private_dns_zone_id | The id of the private dns zone. (Tests) |
| vnetlink_id | The id of the vnet link (Tests) |


## Required Modules
- ntwspoke