#!/bin/bash

export DNS_VNET_LINK=$(az network private-dns link vnet list -g $resource_group_name -z $dns_zone_name | jq -r '.[] | select(.name | contains("dns")).name') 

if [[ -z "$DNS_VNET_LINK" ]]; then
  echo "No DNS_VNET_LINK found or configured"
  exit 0
fi

az network private-dns link vnet delete -z $dns_zone_name -n $DNS_VNET_LINK -g $resource_group_name --yes
