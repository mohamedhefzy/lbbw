data "azurerm_client_config" "current" {
  # Returns the values of the currently logged in user
  # client_id         - is set to the Azure Client ID (Application Object ID).
  # tenant_id         - is set to the Azure Tenant ID.
  # subscription_id   - is set to the Azure Subscription ID.
  # object_id         - is set to the Azure Object ID.
}

resource "azurerm_resource_group" "rg-mssql" {
  name     = "${local.name_prefix}-rg-${local.prefix_app_name}-mssql"
  location = var.location

  tags = var.tags

  lifecycle {
    ignore_changes = [
      tags["CreationDateTime"],
      tags["Owner"],
      tags["Environment"],
      tags["ITAB"],
      tags["AppName"],
      tags["AppEnv"],
      tags["SubscriptionType"],
      tags["PlatformId"],
      tags["Availability"],
      tags["Confidentiality"],
      tags["Integrity"]
    ]
  }
}

resource "azurerm_user_assigned_identity" "mid-mssql" {
  for_each            = var.mssql_servers
  location            = azurerm_resource_group.rg-mssql.location
  name                = "${local.name_prefix}-mid-mssql-server-${each.key}-${local.prefix_app_name}"
  resource_group_name = azurerm_resource_group.rg-mssql.name

  tags = var.tags

  lifecycle {
    ignore_changes = [
      tags["CreationDateTime"],
      tags["Owner"],
      tags["Environment"],
      tags["ITAB"],
      tags["AppName"],
      tags["AppEnv"],
      tags["SubscriptionType"],
      tags["PlatformId"],
      tags["Availability"],
      tags["Confidentiality"],
      tags["Integrity"]
    ]
  }
}

resource "azurerm_mssql_server" "mssql-server" {
  for_each            = var.mssql_servers
  name                = "${local.name_prefix}-mssql-server-${local.prefix_app_name}-${each.key}"
  resource_group_name = azurerm_resource_group.rg-mssql.name
  location            = var.location

  version                       = each.value.version
  public_network_access_enabled = each.value.public_network_access_enabled

  azuread_administrator {
    login_username              = azurerm_user_assigned_identity.mid-mssql[each.key].name
    object_id                   = azurerm_user_assigned_identity.mid-mssql[each.key].principal_id
    azuread_authentication_only = true
  }

  identity {
    type = each.value.identity.type
    identity_ids = [
      "/subscriptions/${data.azurerm_client_config.current.subscription_id}/resourceGroups/${local.name_prefix}-rg-${local.prefix_app_name}-infra/providers/Microsoft.ManagedIdentity/userAssignedIdentities/${local.name_prefix}-mid-${local.prefix_app_name}-infra",
      azurerm_user_assigned_identity.mid-mssql[each.key].id
    ]
  }

  primary_user_assigned_identity_id            = "/subscriptions/${data.azurerm_client_config.current.subscription_id}/resourceGroups/${local.name_prefix}-rg-${local.prefix_app_name}-infra/providers/Microsoft.ManagedIdentity/userAssignedIdentities/${local.name_prefix}-mid-${local.prefix_app_name}-infra"
  transparent_data_encryption_key_vault_key_id = contains(["3", "4"], var.sbk) ? var.keyvault_encryption_key_id : null

  tags = var.tags

  lifecycle {
    ignore_changes = [
      tags["CreationDateTime"],
      tags["Owner"],
      tags["Environment"],
      tags["ITAB"],
      tags["AppName"],
      tags["AppEnv"],
      tags["SubscriptionType"],
      tags["PlatformId"],
      tags["Availability"],
      tags["Confidentiality"],
      tags["Integrity"]
    ]
  }
}

resource "azurerm_mssql_database" "mssql-database" {
  for_each = local.mssql_database_flatten
  name     = "${local.name_prefix}-mssql-database-${local.prefix_app_name}-${each.key}"

  server_id = azurerm_mssql_server.mssql-server[each.value.server_key].id

  collation                   = each.value.collation
  auto_pause_delay_in_minutes = each.value.auto_pause_delay_in_minutes
  max_size_gb                 = each.value.max_size_gb
  # min_capacity is always 1/8 of the max vcpu capacity except for GP_S_Gen5_1 & GP_S_Gen5_2 which is 0.5
  min_capacity         = local.sku_min_capacity[each.value.sku_name]
  read_scale           = each.value.read_scale
  read_replica_count   = each.value.read_replica_count
  sku_name             = each.value.sku_name
  zone_redundant       = each.value.zone_redundant
  storage_account_type = each.value.storage_account_type

  short_term_retention_policy {
    retention_days           = local.backup_options[var.backupretention].retention_days
    backup_interval_in_hours = local.backup_options[var.backupretention].backup_interval_in_hours
  }

  # At the time of writing, LTR is not possible when auto pause is active. Therefore it needs to be very clear that auto pause will overwrite the default retention attributes (based on SHORT, MID, LONG).
  dynamic "long_term_retention_policy" {
    for_each = each.value.auto_pause_delay_in_minutes >= 60 ? [] : [1]
    content {
      weekly_retention  = local.backup_options[var.backupretention].weekly_retention
      monthly_retention = local.backup_options[var.backupretention].monthly_retention
      yearly_retention  = local.backup_options[var.backupretention].yearly_retention
      week_of_year      = local.backup_options[var.backupretention].week_of_year
    }
  }

  tags = var.tags

  lifecycle {
    ignore_changes = [
      tags["CreationDateTime"],
      tags["Owner"],
      tags["Environment"],
      tags["ITAB"],
      tags["AppName"],
      tags["AppEnv"],
      tags["SubscriptionType"],
      tags["PlatformId"],
      tags["Availability"],
      tags["Confidentiality"],
      tags["Integrity"]
    ]
  }
}

resource "azurerm_role_assignment" "keyvault_access" {
  for_each             = var.mssql_servers
  scope                = var.keyvault_keyvault_ids["app"]
  role_definition_name = "Key Vault Secrets User"
  principal_id         = azurerm_user_assigned_identity.mid-mssql[each.key].principal_id
}

resource "azurerm_private_endpoint" "pep" {
  for_each            = var.mssql_servers
  name                = "${local.name_prefix}-pep-${local.prefix_app_name}-mssql_${each.key}"
  location            = var.location
  resource_group_name = azurerm_resource_group.rg-mssql.name
  subnet_id           = var.pepsnet_id

  private_service_connection {
    name                           = "pep-sc-${each.key}"
    private_connection_resource_id = azurerm_mssql_server.mssql-server[each.key].id
    subresource_names              = ["sqlServer"]
    is_manual_connection           = false
  }

  // Zentrale Azure Privater DNS Zone in Hub muss hier referenziert werden.
  private_dns_zone_group {
    name                 = "mssql"
    private_dns_zone_ids = var.is_old_tenant ? ["${local.private_dns_zone_ids[var.infra_environment]}privatelink.database.windows.net"] : ["${local.private_dns_zone_id_new_tenant[var.infra_environment]}privatelink.database.windows.net"]
  }

  tags = var.tags

  lifecycle {
    ignore_changes = [
      tags["CreationDateTime"],
      tags["Owner"],
      tags["Environment"],
      tags["ITAB"],
      tags["AppName"],
      tags["AppEnv"],
      tags["SubscriptionType"],
      tags["PlatformId"],
      tags["Availability"],
      tags["Confidentiality"],
      tags["Integrity"]
    ]
  }
}
