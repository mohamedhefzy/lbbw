# Mssql

This module is used to deploy an Azure Mssql-Server.

## Created Resources

This module creates the following resources on azure


- ``azurerm_resource_group.rg-mssql``: A resource group where the following resources are located.
- ``azurerm_mssql_server.mssql-server``: The mssql server
- ``azurerm_mssql_database.mssql-database``: The mssql database
- ``azurerm_private_endpoint.pep``: The private endpoint of the mssql server.


## Variables

| Name               | Description                                                               | Type   |
| ------------------ | ------------------------------------------------------------------------- | -------|
| app_environment | This variable defines the app environment of the specific application. Placeholder is 'x' if nothing is set. | string | 
| app_name | Name of the application per subscription | string|
| app_type | Type of app (shared, spoke...) | string |
| lbbw_location | LBBW Location | string |
| location | Azure location | string |
| infra_environment | This variable defines the environment to be built. (p,c,d,e). | string |
| sbk | This variable defines the 'Schutzbedarfsklasse' (1, 2, 3, 4) | string |
| iam-entra-object-ids | Map of Entra Security Group Object IDs for role assignments | map(string) |
| tags | Map of Tags per subscription | map(string) |
| backupretention | This value provide information which retention policy (short, mid, long) is needed. | string |
| pepsnet_id | The ids of the subnet | string|
| keyvault_encryption_key_id | The id of the key that is used for disk encryption | string |
| mssql_servers | Azure SQL Server | map(object) |


### Mssql Model

Model Deployments are described in a list of objects of the following structure:

```

mssql_servers = map({
    version                       = string
    public_network_access_enabled = bool
    mssql_databases = map({
      collation                   = string
      auto_pause_delay_in_minutes = number
      max_size_gb                 = number
      min_capacity                = number
      read_scale                  = bool
      read_replica_count          = number
      sku_name                    = string
      zone_redundant              = string
      storage_account_type        = string
    })
})

```

### Output
| Name                 | Description                                                                                                       |
| -------------------- | ----------------------------------------------------------------------------------------------------------------- |
| rg_name | The resource group name. (Tests) |
| database_name | The name of the databases. (Tests) |
| server_names | The name of the servers. (Tests) |
| private_endpoint_names | The names of the private endpoint. (Tests) |
| user_assigned_identity_ids | The IDs of the managed identities | 
| user_assigned_identity_client_ids | The client IDs of the managed identities |
| user_assigned_identity_names | The names of the managed identities |

## Required Modules
- ntwspoke
- keyvault