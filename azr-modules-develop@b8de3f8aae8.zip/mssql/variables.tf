variable "is_old_tenant" {
  description = "Is old tenant used"
  type        = bool
}

variable "app_environment" {
  description = "This variable defines the app environment of the specific application. Placeholder is 'x' if nothing is set."
  type        = string
}

variable "app_name" {
  description = "Name of the application per subscription"
  type        = string
}

variable "app_type" {
  description = "Type of app (shared, spoke...)"
  type        = string
}

variable "lbbw_location" {
  description = "LBBW Location"
  type        = string
}

variable "location" {
  description = "Azure location"
  type        = string
}

variable "infra_environment" {
  description = "This variable defines the environment to be built. (Prod,Cert,Dev,Engineering)."
  type        = string
}

variable "sbk" {
  description = "This variable defines the 'Schutzbedarfsklasse' (1, 2, 3, 4)"
  type        = string
}

variable "iam-entra-object-ids" {
  description = "Map of Entra Security Group Object IDs for role assignments"
  type        = map(string)
}

variable "tags" {
  description = "Map of Tags per subscription"
  type        = map(string)
}

variable "backupretention" {
  description = "This value provide information which retention policy (short, mid, long) is needed"
  type        = string
}

// todo refactor this
variable "pepsnet_id" {
  description = "The ids of the subnet"
  type        = string
}

variable "keyvault_encryption_key_id" {
  description = "The id of the key that is used for disk encryption"
  type        = string
}

variable "keyvault_keyvault_ids" {
  description = "The ids of all keyvaults"
  type        = map(string)
}

variable "mssql_servers" {
  description = "Azure SQL Server "
  type = map(object({
    version                       = string
    public_network_access_enabled = bool
    mssql_databases = map(object({
      collation                   = string
      auto_pause_delay_in_minutes = number
      max_size_gb                 = number
      min_capacity                = number
      read_scale                  = bool
      read_replica_count          = number
      sku_name                    = string
      zone_redundant              = string
      storage_account_type        = string
    }))
    identity = object({
      type = string
    })
  }))
}


