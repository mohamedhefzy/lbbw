# outputs
// tests
output "rg_name" {
  value = azurerm_resource_group.rg-mssql.name
}

output "database_names" {
  value = { for k, v in azurerm_mssql_database.mssql-database : k => v.name }
}

output "user_assigned_identity_ids" {
  description = "The user assigned identity id"
  value       = { for k, v in azurerm_user_assigned_identity.mid-mssql : k => v.id }
}

output "user_assigned_identity_client_ids" {
  description = "The user assigned identity client_id"
  value       = { for k, v in azurerm_user_assigned_identity.mid-mssql : k => v.client_id }
}

output "user_assigned_identity_names" {
  description = "The user assigned identity name"
  value       = { for k, v in azurerm_user_assigned_identity.mid-mssql : k => v.name }
}

output "server_names" {
  value = { for k, v in azurerm_mssql_server.mssql-server : k => v.name }
}

output "private_endpoint_names" {
  value = { for k, v in azurerm_private_endpoint.pep : k => v.name }
}