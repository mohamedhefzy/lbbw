variable "is_old_tenant" {
  type    = bool
  default = true
}
variable "app_environment" {
  type    = string
  default = "x"
}
variable "app_name" {
  type    = string
  default = "test"
}
variable "app_type" {
  type    = string
  default = "spoke"
}
variable "lbbw_location" {
  type    = string
  default = "euho"
}
variable "location" {
  type    = string
  default = "westeurope"
}
variable "infra_environment" {
  type    = string
  default = "e"
}
variable "backupretention" {
  type    = string
  default = "SHORT"
}
variable "patchwindow" {
  type    = string
  default = "Option1"
}

variable "sbk" {
  type    = string
  default = "2"
}

variable "availability" {
  type    = string
  default = "V1"
}