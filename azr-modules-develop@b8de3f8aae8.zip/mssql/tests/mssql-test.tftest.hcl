
run "execute" {
  module {
    source = "./setup"
  }

  command = plan

  assert {
    condition     = module.mssql.rg_name == "euho-e-rg-xtest-mssql"
    error_message = "The rg name does not match."
  }

  assert {
    condition     = module.mssql.database_names["database1-server1"] == "euho-e-mssql-database-xtest-database1-server1"
    error_message = "The mssql database name does not match."
  }

  assert {
    condition     = module.mssql.server_names.server1 == "euho-e-mssql-server-xtest-server1"
    error_message = "The mssql server name does not match."
  }

  assert {
    condition     = module.mssql.private_endpoint_names.server1 == "euho-e-pep-xtest-mssql_server1"
    error_message = "The private endpoint name does not match."
  }
}
