locals {
  name_prefix     = "${var.lbbw_location}-${var.infra_environment}"
  prefix_app_name = "${var.app_environment}${var.app_name}"

  # mssql_server is falttened to access the map of mssql_databases.
  mssql_database_flatten = {
    for m in(flatten([
      for server_key, server in var.mssql_servers : [
        for database_key, database in server.mssql_databases : {
          key                         = "${database_key}-${server_key}"
          server_key                  = server_key
          database_key                = database_key
          collation                   = database.collation
          auto_pause_delay_in_minutes = database.auto_pause_delay_in_minutes
          max_size_gb                 = database.max_size_gb
          min_capacity                = database.min_capacity
          read_scale                  = database.read_scale
          read_replica_count          = database.read_replica_count
          sku_name                    = database.sku_name
          zone_redundant              = database.zone_redundant
          storage_account_type        = database.storage_account_type
        }
      ]
    ])) : m.key => m
  }

  backup_options = {
    SHORT = {
      #str
      retention_days           = 14
      backup_interval_in_hours = 12
      #ltr
      weekly_retention  = "P4W"
      monthly_retention = "PT0S"
      yearly_retention  = "PT0S"
      week_of_year      = 0
    }

    MID = {
      #str
      retention_days           = 14
      backup_interval_in_hours = 12
      #ltr
      weekly_retention  = "P12M"
      monthly_retention = "PT0S"
      yearly_retention  = "PT0S"
      week_of_year      = 0
    }

    LONG = {
      #str
      retention_days           = 14
      backup_interval_in_hours = 12
      #ltr
      weekly_retention  = "P12M"
      monthly_retention = "P10Y"
      yearly_retention  = "PT0S"
      week_of_year      = 0
    }
  }

  # Workaround - Maybe this mapping should be done within SNOW
  sku_min_capacity = {
    GP_S_Gen5_1  = 0.5
    GP_S_Gen5_2  = 0.5
    GP_S_Gen5_4  = 0.5
    GP_S_Gen5_6  = 0.75
    GP_S_Gen5_8  = 1
    GP_S_Gen5_10 = 1.25
    GP_S_Gen5_12 = 1.5
    GP_S_Gen5_14 = 1.75
    GP_S_Gen5_16 = 2
    GP_S_Gen5_18 = 2.25
    GP_S_Gen5_20 = 2.5
    GP_S_Gen5_24 = 3
    GP_S_Gen5_32 = 4
    GP_S_Gen5_40 = 5
    GP_S_Gen5_80 = 10
    # The Business Critical SKUs do not have the capability to run at a lower vcpu capacity therefore this has to be mapped to null
    BC_Gen5_2   = null
    BC_Gen5_4   = null
    BC_Gen5_6   = null
    BC_Gen5_8   = null
    BC_Gen5_10  = null
    BC_Gen5_12  = null
    BC_Gen5_14  = null
    BC_Gen5_16  = null
    BC_Gen5_18  = null
    BC_Gen5_20  = null
    BC_Gen5_24  = null
    BC_Gen5_32  = null
    BC_Gen5_40  = null
    BC_Gen5_80  = null
    BC_Gen5_128 = null
  }

  private_dns_zone_ids = {
    e = "/subscriptions/a1ce34e0-ffe5-46be-b04b-1cbf0735eeb5/resourceGroups/euho-e-rg-privatednszone/providers/Microsoft.Network/privateDnsZones/"
    d = "/subscriptions/b8c7d5eb-d942-400c-999c-1c741ffb52bf/resourceGroups/euho-d-rg-privatednszone/providers/Microsoft.Network/privateDnsZones/"
    c = "/subscriptions/b79558eb-d4b4-4d56-8f95-8d5c33f7c3cf/resourceGroups/euho-c-rg-privatednszone/providers/Microsoft.Network/privateDnsZones/"
    p = "/subscriptions/2836bb7c-3eaa-4fdd-9024-3f17daf08755/resourceGroups/euho-p-rg-privatednszone/providers/Microsoft.Network/privateDnsZones/"
  }

  private_dns_zone_id_new_tenant = {
    e = "/subscriptions/3da49d2d-46fc-4deb-a3aa-57cbc662e092/resourceGroups/euho-e-rg-privatednszones/providers/Microsoft.Network/privateDnsZones/"

    d = "/subscriptions/ceeadf22-6dcf-47f7-a232-818623b3afdc/resourceGroups/euho-p-rg-privatednszones/providers/Microsoft.Network/privateDnsZones/"
    c = "/subscriptions/ceeadf22-6dcf-47f7-a232-818623b3afdc/resourceGroups/euho-p-rg-privatednszones/providers/Microsoft.Network/privateDnsZones/"
    p = "/subscriptions/ceeadf22-6dcf-47f7-a232-818623b3afdc/resourceGroups/euho-p-rg-privatednszones/providers/Microsoft.Network/privateDnsZones/"
  }
}