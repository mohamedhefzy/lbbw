# Eventhub

This module is used to deploy an Azure Eventhub.

This module creates the following resources on azure.

## Created Resources


- ``azurerm_resource_group.rg-eventhub``: A resource group where the following resources are located.
- ``azurerm_eventhub_namespace.namespace``: A namespace is a management container.
- ``azurerm_eventhub.eventhubs``: The eventhub.
- ``azurerm_eventhub_authorization_rule.eventhubs_send_rule``: A resource for sending
- ``azurerm_eventhub_authorization_rule.eventhubs_listen_rule``: A resource for listening
- ``azurerm_role_assignment.eventhub_data_receiver_ra``: Role assignment for Azure Event Hubs Data Receiver.
- ``azurerm_role_assignment.eventhub_data_sender_ra``: Role assignment for Azure Event Hubs Data Sender.


## Variables

| Name               | Description                                                               | Type   |
| ------------------ | ------------------------------------------------------------------------- | -------|
| app_environment | This variable defines the app environment of the specific application. Placeholder is 'x' if nothing is set. | string |
| app_name | Name of the application per subscription. | string |
| app_type | Type of app (shared, spoke...) | string |
| sbk | This variable defines the 'Schutzbedarfsklasse' (1, 2, 3, 4) | string |
| lbbw_location | LBBW Location | string |
| location | Azure location | string |
| infra_environment | This variable defines the environment to be built. (Prod,Cert,Dev,Engineering). | string |
| eventhub_namespaces | Configuration map for multiple eventhub namespaces and their eventhubs. | map(object) |
| subnet_ids | Subnet id's to be allowed for every eventhub namespace. | map(string) |
| eventhub_azure_eh_data_receiver_role_assignments | Map of namespaces objects containing the list of service principal object IDs that should get a 'Azure Event Hubs Data Receiver' role assignment on which namespaces. | map(object) |
| eventhub_azure_eh_data_sender_role_assignments | Map of namespaces objects containing the list of service principal object IDs that should get a 'Azure Event Hubs Data Sender' role assignment on which namespaces. | map(object) |
| tags | Map of Tags per subscription | map(string) |



### Eventhub namespace Model

Model Deployments are described in a list of objects of the following structure:

```
eventhub_namespaces =  
    map({
        sku               = string
        capacity          = number
        trusted_service_access_enabled = bool
        allowed_subnet_keys            = list(string)
        allowed_ip_addresses           = list(string)
        eventhubs = map({
            partition_count = number
            message_retention = number
    })
  })

```



## Output

| Name             | Description                                                                                                       |
| ---------------- | ----------------------------------------------------------------------------------------------------------------- |
| rg_id            | The id of the resource group.                                                                                     |
| rg_name          | The resource group name. (Tests)                                                                                  |
| namespace_names  | The names of the namespaces. (Tests)                                                                              |
| authorization_rule_names | The names of the authorization rule. (Tests)                                                              |
| eventhub_names   | The names of the event hubs. (Tests)                                                                              |


## Required Modules
- ntwspoke