output "rg_id" {
  value = azurerm_resource_group.rg-eventhub.id
}

output "rg_name" {
  value = azurerm_resource_group.rg-eventhub.name
}

output "namespace_names" {
  value = { for k, v in azurerm_eventhub_namespace.namespace : k => v.name }
}

output "authorization_rule_names" {
  value = { for k, v in azurerm_eventhub_authorization_rule.eventhubs_send_rule : k => v.name }
}

output "eventhub_names" {
  value = { for k, v in azurerm_eventhub.eventhubs : k => v.name }
}