################################
# Non-Default Application Variables
################################
variable "app_environment" {
  description = "This variable defines the app environment of the specific application. Placeholder is 'x' if nothing is set."
  type        = string
}

variable "app_name" {
  description = "Name of the application per subscription"
  type        = string
}

variable "app_type" {
  description = "Type of app (shared, spoke...)"
  type        = string
}

variable "sbk" {
  description = "This variable defines the 'Schutzbedarfsklasse' (1, 2, 3, 4)"
  type        = string
}

################################
# Default Application Variables
################################
variable "lbbw_location" {
  description = "LBBW Location"
  type        = string
}

variable "location" {
  description = "Azure location"
  type        = string
}

variable "infra_environment" {
  description = "This variable defines the environment to be built. (Prod,Cert,Dev,Engineering)."
  type        = string
}

################################
# Module Specific Variables
################################
variable "eventhub_namespaces" {
  description = "Configuration map for multiple eventhub namespaces and their eventhubs"
  type = map(object({
    sku      = string
    capacity = number

    trusted_service_access_enabled = bool
    allowed_subnet_keys            = list(string)
    allowed_ip_addresses           = list(string)

    # Map of eventhubs which should be inside the namespace, each one may have different partition count and retention time
    eventhubs = map(object({
      partition_count = number
      # Number between 1 and 7 to indicate number of retention days
      message_retention = number
    }))
  }))
}

variable "eventhub_namespace_splunk" {
  description = "Configuration map for the splunk namespace and its eventhub"
  type = object({
    sku      = string
    capacity = number

    trusted_service_access_enabled = bool
    allowed_ip_addresses           = list(string)
    service_principal_object_id    = string

    # Map of eventhubs which should be inside the namespace, each one may have different partition count and retention time
    eventhub = object({
      partition_count = number
      # Number between 1 and 7 to indicate number of retention days
      message_retention = number
    })
  })
}

variable "subnet_ids" {
  description = "Subnet id's to be allowed for every eventhub namespace"
  type        = map(string)
}

variable "eventhub_azure_eh_data_receiver_role_assignments" {
  description = "Map of namespaces objects containing the list of service principal object IDs that should get a 'Azure Event Hubs Data Receiver' role assignment on which namespaces."
  type = map(object({
    service_principal_object_ids = list(string)
  }))
}

variable "eventhub_azure_eh_data_sender_role_assignments" {
  description = "Map of namespaces objects containing the list of service principal object IDs that should get a 'Azure Event Hubs Data Sender' role assignment on which namespaces."
  type = map(object({
    service_principal_object_ids = list(string)
  }))
}

variable "encryption_key_id" {
  description = "The id of the keyvault key that is used for encyption"
  type        = string
}

variable "keyvault_encryp_rg_id" {
  description = "The resource id of the keyvault's resource group"
  type        = string
}

################################
# Other Variables
################################
variable "tags" {
  description = "Map of Tags per subscription"
  type        = map(string)
}
