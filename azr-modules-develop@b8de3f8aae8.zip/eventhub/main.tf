data "azurerm_client_config" "current" {
  # Returns the values of the currently logged in user
  # client_id         - is set to the Azure Client ID (Application Object ID).
  # tenant_id         - is set to the Azure Tenant ID.
  # subscription_id   - is set to the Azure Subscription ID.
  # object_id         - is set to the Azure Object ID.
}

resource "azurerm_resource_group" "rg-eventhub" {
  name     = "${local.name_prefix}-rg-${local.prefix_app_name}-evh"
  location = var.location

  tags = var.tags

  lifecycle {
    ignore_changes = [
      tags["CreationDateTime"],
      tags["Owner"],
      tags["Environment"],
      tags["ITAB"],
      tags["AppName"],
      tags["AppEnv"],
      tags["SubscriptionType"],
      tags["PlatformId"],
      tags["Availability"],
      tags["Confidentiality"],
      tags["Integrity"]
    ]
  }
}

resource "azurerm_eventhub_namespace" "namespace" {
  for_each = var.eventhub_namespaces != null ? var.eventhub_namespaces : {}
  name     = "${local.name_prefix}-evhns-${local.prefix_app_name}-${each.key}"

  location            = azurerm_resource_group.rg-eventhub.location
  resource_group_name = azurerm_resource_group.rg-eventhub.name

  sku                          = each.value.sku == null ? "Standard" : each.value.sku
  capacity                     = each.value.capacity
  local_authentication_enabled = false

  # For Network Setting: selected vNets --> public_network_access_enabled = true and default_action = "Deny"
  # For Network Setting: private --> public_network_access_enabled = false
  public_network_access_enabled = length(concat(local.combined_subnets, each.value.allowed_ip_addresses)) != 0 ? true : false

  network_rulesets {
    default_action                 = "Deny"
    public_network_access_enabled  = length(concat(local.combined_subnets, each.value.allowed_ip_addresses)) != 0 ? true : false
    trusted_service_access_enabled = each.value.trusted_service_access_enabled

    virtual_network_rule = [
      for subney_key in local.combined_subnets : {
        subnet_id                                       = subney_key.subnet_id
        ignore_missing_virtual_network_service_endpoint = true
      }
    ]

    ip_rule = [
      for ip_address in each.value.allowed_ip_addresses : {
        ip_mask = ip_address
        action  = "Allow"
      }
    ]
  }

  identity {
    type         = "UserAssigned"
    identity_ids = ["/subscriptions/${data.azurerm_client_config.current.subscription_id}/resourceGroups/${local.name_prefix}-rg-${local.prefix_app_name}-infra/providers/Microsoft.ManagedIdentity/userAssignedIdentities/${local.name_prefix}-mid-${local.prefix_app_name}-infra"]
  }

  tags = var.tags

  lifecycle {
    ignore_changes = [
      tags["CreationDateTime"],
      tags["Owner"],
      tags["Environment"],
      tags["ITAB"],
      tags["AppName"],
      tags["AppEnv"],
      tags["SubscriptionType"],
      tags["PlatformId"],
      tags["Availability"],
      tags["Confidentiality"],
      tags["Integrity"]
    ]
  }
}

# resource "azurerm_eventhub_namespace_customer_managed_key" "namespace-cmk" {
#   for_each = var.eventhub_namespaces != null && contains(["3", "4"], var.sbk) ? var.infra_environment == "e" ? {} : var.eventhub_namespaces : {} # Not possible to use cmk on engineering. Kinda bad code but no time for good implementation gotta live with it ¯\_(ツ)_/¯

#   eventhub_namespace_id = azurerm_eventhub_namespace.namespace[each.key].id
#   key_vault_key_ids     = [var.encryption_key_id]
#   # infrastructure_encryption_enabled = false
#   user_assigned_identity_id = "/subscriptions/${data.azurerm_client_config.current.subscription_id}/resourceGroups/${local.name_prefix}-rg-${local.prefix_app_name}-infra/providers/Microsoft.ManagedIdentity/userAssignedIdentities/${local.name_prefix}-mid-${local.prefix_app_name}-infra"
# }

resource "azurerm_eventhub" "eventhubs" {
  for_each = local.evhns_eventhub_flatten

  name = "evh-${local.prefix_app_name}-${each.key}"

  namespace_name      = "${local.name_prefix}-evhns-${local.prefix_app_name}-${each.value.eventhub_namespace_key}"
  resource_group_name = azurerm_resource_group.rg-eventhub.name

  partition_count   = each.value.partition_count
  message_retention = each.value.message_retention

  depends_on = [
    azurerm_eventhub_namespace.namespace,
    # azurerm_eventhub_namespace_customer_managed_key.namespace-cmk
  ]
}

resource "azurerm_eventhub_authorization_rule" "eventhubs_send_rule" {
  for_each = local.evhns_eventhub_flatten

  name                = "send-${each.value.eventhub_key}"
  namespace_name      = "${local.name_prefix}-evhns-${local.prefix_app_name}-${each.value.eventhub_namespace_key}"
  eventhub_name       = "evh-${local.prefix_app_name}-${each.key}"
  resource_group_name = azurerm_resource_group.rg-eventhub.name
  listen              = false
  send                = true
  manage              = false

  depends_on = [azurerm_eventhub.eventhubs]
}

resource "azurerm_eventhub_authorization_rule" "eventhubs_listen_rule" {
  for_each = local.evhns_eventhub_flatten

  name                = "listen-${each.key}"
  namespace_name      = "${local.name_prefix}-evhns-${local.prefix_app_name}-${each.value.eventhub_namespace_key}"
  eventhub_name       = "evh-${local.prefix_app_name}-${each.key}"
  resource_group_name = azurerm_resource_group.rg-eventhub.name
  listen              = true
  send                = false
  manage              = false

  depends_on = [azurerm_eventhub.eventhubs]
}

resource "azurerm_role_assignment" "eventhub_data_receiver_ra" {
  for_each = local.eventhub_azure_eh_data_receiver_role_assignments_flatten

  role_definition_name = "Azure Event Hubs Data Receiver"
  principal_type       = "ServicePrincipal"

  scope = lookup(
    { for namespace_name, namespace in azurerm_eventhub_namespace.namespace : namespace_name => namespace.id },
  each.value.namespace, null)

  principal_id = each.value.service_principal_object_id

  depends_on = [azurerm_eventhub_namespace.namespace]
}

resource "azurerm_role_assignment" "eventhub_data_sender_ra" {
  for_each = local.eventhub_azure_eh_data_sender_role_assignments_flatten

  role_definition_name = "Azure Event Hubs Data Sender"
  principal_type       = "ServicePrincipal"

  scope = lookup(
    { for namespace_name, namespace in azurerm_eventhub_namespace.namespace : namespace_name => namespace.id },
  each.value.namespace, null)

  principal_id = each.value.service_principal_object_id

  depends_on = [azurerm_eventhub_namespace.namespace]
}

#########################################
#######         Splunk            #######
#########################################

resource "azurerm_eventhub_namespace" "splunk_namespace" {
  name = "${local.name_prefix}-evhns-${local.prefix_app_name}-splunk"

  location                     = azurerm_resource_group.rg-eventhub.location
  resource_group_name          = azurerm_resource_group.rg-eventhub.name
  sku                          = var.eventhub_namespace_splunk.sku == null ? "Standard" : var.eventhub_namespace_splunk.sku
  capacity                     = var.eventhub_namespace_splunk.capacity
  local_authentication_enabled = false

  # For Network Setting: selected vNets --> public_network_access_enabled = true and default_action = "Deny"
  # For Network Setting: private --> public_network_access_enabled = false
  public_network_access_enabled = true

  network_rulesets {
    default_action                 = "Deny"
    public_network_access_enabled  = true
    trusted_service_access_enabled = var.eventhub_namespace_splunk.trusted_service_access_enabled

    virtual_network_rule = [
      for subnet_id_iter in var.subnet_ids : {
        subnet_id                                       = subnet_id_iter
        ignore_missing_virtual_network_service_endpoint = true
      }
    ]

    ip_rule = [
      for ip_address in var.eventhub_namespace_splunk.allowed_ip_addresses : {
        ip_mask = ip_address
        action  = "Allow"
      }
    ]
  }

  identity {
    type         = "UserAssigned"
    identity_ids = ["/subscriptions/${data.azurerm_client_config.current.subscription_id}/resourceGroups/${local.name_prefix}-rg-${local.prefix_app_name}-infra/providers/Microsoft.ManagedIdentity/userAssignedIdentities/${local.name_prefix}-mid-${local.prefix_app_name}-infra"]
  }

  tags = var.tags

  lifecycle {
    ignore_changes = [
      tags["CreationDateTime"],
      tags["Owner"],
      tags["Environment"],
      tags["ITAB"],
      tags["AppName"],
      tags["AppEnv"],
      tags["SubscriptionType"],
      tags["PlatformId"],
      tags["Availability"],
      tags["Confidentiality"],
      tags["Integrity"]
    ]
  }
}

# resource "azurerm_eventhub_namespace_customer_managed_key" "splunk_namespace-cmk" {
#   count = contains(["3", "4"], var.sbk) ? var.infra_environment == "e" ? 0 : 1 : 0 # Not possible to use cmk on engineering. Kinda bad code but too lazy and this is not really a good workaround ¯\_(ツ)_/¯

#   eventhub_namespace_id = azurerm_eventhub_namespace.splunk_namespace.id
#   key_vault_key_ids     = [var.encryption_key_id]
#   # infrastructure_encryption_enabled = false
#   user_assigned_identity_id = "/subscriptions/${data.azurerm_client_config.current.subscription_id}/resourceGroups/${local.name_prefix}-rg-${local.prefix_app_name}-infra/providers/Microsoft.ManagedIdentity/userAssignedIdentities/${local.name_prefix}-mid-${local.prefix_app_name}-infra"
# }

resource "azurerm_eventhub" "eventhub_splunk" {
  name = "evh-${local.prefix_app_name}-splunk"

  namespace_name      = azurerm_eventhub_namespace.splunk_namespace.name
  resource_group_name = azurerm_resource_group.rg-eventhub.name

  partition_count   = var.eventhub_namespace_splunk.eventhub.partition_count
  message_retention = var.eventhub_namespace_splunk.eventhub.message_retention

  depends_on = [
    azurerm_eventhub_namespace.splunk_namespace,
    # azurerm_eventhub_namespace_customer_managed_key.splunk_namespace-cmk
  ]
}

resource "azurerm_eventhub_authorization_rule" "eventhub_send_rule_splunk" {
  name                = "send-splunk"
  namespace_name      = azurerm_eventhub_namespace.splunk_namespace.name
  eventhub_name       = azurerm_eventhub.eventhub_splunk.name
  resource_group_name = azurerm_resource_group.rg-eventhub.name
  listen              = false
  send                = true
  manage              = false

  depends_on = [azurerm_eventhub.eventhub_splunk]
}

resource "azurerm_eventhub_authorization_rule" "eventhub_listen_rule_splunk" {
  name                = "listen-splunk"
  namespace_name      = azurerm_eventhub_namespace.splunk_namespace.name
  eventhub_name       = azurerm_eventhub.eventhub_splunk.name
  resource_group_name = azurerm_resource_group.rg-eventhub.name
  listen              = true
  send                = false
  manage              = false

  depends_on = [azurerm_eventhub.eventhubs]
}

resource "azurerm_role_assignment" "eventhub_data_receiver_ra_splunk" {
  role_definition_name = "Azure Event Hubs Data Receiver"
  principal_type       = "ServicePrincipal"

  scope = azurerm_eventhub_namespace.splunk_namespace.id

  principal_id = var.eventhub_namespace_splunk.service_principal_object_id

  depends_on = [azurerm_eventhub_namespace.splunk_namespace]
}

resource "azurerm_role_assignment" "eventhub_data_sender_ra_splunk" {
  role_definition_name = "Azure Event Hubs Data Sender"
  principal_type       = "ServicePrincipal"

  scope = azurerm_eventhub_namespace.splunk_namespace.id

  principal_id = var.eventhub_namespace_splunk.service_principal_object_id

  depends_on = [azurerm_eventhub_namespace.splunk_namespace]
}