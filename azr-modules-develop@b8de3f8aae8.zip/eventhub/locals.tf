locals {
  name_prefix     = "${var.lbbw_location}-${var.infra_environment}"
  prefix_app_name = "${var.app_environment}${var.app_name}"

  # Need to flatten the eventhub map inside the eventhub namespace map in order to use them
  # Will result in a new key-value map for every eventhub
  evhns_eventhub_flatten = {
    for e in(flatten([
      for evhns_key, eventhub_namespace in var.eventhub_namespaces : [
        for evh_key, eventhub in eventhub_namespace.eventhubs : {
          key                    = "${evh_key}-${evhns_key}"
          eventhub_namespace_key = evhns_key
          eventhub_key           = evh_key
          partition_count        = eventhub.partition_count
          message_retention      = eventhub.message_retention
        }
      ]
    ])) : e.key => e
  }

  # This for each creates a unique combination of (namespace X service_principal_object_id) for every ID in the given list.
  # For example, the construct 
  # eventhub_azure_eh_data_receiver_role_assignments = { siem = { service_principal_object_ids = ["abc", "def"] }, notsiem = { service_principal_object_ids = ["ghi"]}}}
  # would result in # siem-abc, siem-def and notsiem-ghi. 
  # We then iterate over every combination and create a role assignment for each of them.
  eventhub_azure_eh_data_receiver_role_assignments_flatten = {
    for e in(flatten([
      for evhns_key, eventhub_namespace in var.eventhub_azure_eh_data_receiver_role_assignments : [
        for object_id in eventhub_namespace.service_principal_object_ids : {
          key                         = "${evhns_key}-${object_id}"
          namespace                   = evhns_key
          service_principal_object_id = object_id
        }
      ]
    ])) : e.key => e
  }

  # This for each creates a unique combination of (namespace X service_principal_object_id) for every ID in the given list.
  # For example, the construct 
  # eventhub_azure_eh_data_sender_role_assignments = { siem = { service_principal_object_ids = ["abc", "def"] }, notsiem = { service_principal_object_ids = ["ghi"]}}}
  # would result in # siem-abc, siem-def and notsiem-ghi. 
  # We then iterate over every combination and create a role assignment for each of them.
  eventhub_azure_eh_data_sender_role_assignments_flatten = {
    for e in(flatten([
      for evhns_key, eventhub_namespace in var.eventhub_azure_eh_data_sender_role_assignments : [
        for object_id in eventhub_namespace.service_principal_object_ids : {
          key                         = "${evhns_key}-${object_id}"
          namespace                   = evhns_key
          service_principal_object_id = object_id
        }
      ]
    ])) : e.key => e
  }

  existing_subnets = [
    for subnet_id in [var.subnet_ids["default"], var.subnet_ids["private_endpoint_subnet"]] : {
      subnet_id = subnet_id
    }
  ]

  allowed_subnet_ids = [
    for evhns_key, eventhub_namespace in var.eventhub_namespaces : [
      for subnet_key in eventhub_namespace.allowed_subnet_keys : {
        subnet_id = var.subnet_ids[subnet_key]
      }
    ]
  ]

  combined_subnets = concat(local.existing_subnets, flatten(local.allowed_subnet_ids))
}