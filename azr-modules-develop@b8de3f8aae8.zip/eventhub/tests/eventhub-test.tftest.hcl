run "execute" {
  module {
    source = "./setup"
  }

  command = plan

  assert {
    condition     = module.eventhub.rg_name == "euho-e-rg-xtest-evh"
    error_message = "The rg name does not match"
  }

  assert {
    condition     = module.eventhub.namespace_names.namespace1 == "euho-e-evhns-xtest-namespace1"
    error_message = "The namespace name does not match."
  }

  assert {
    condition     = module.eventhub.authorization_rule_names["eventhub1-namespace1"] == "send-eventhub1"
    error_message = "The authorization rule name does not match."
  }

  assert {
    condition     = module.eventhub.eventhub_names["eventhub1-namespace1"] == "evh-xtest-eventhub1-namespace1"
    error_message = "The event hub name does not match."
  }

}