provider "azurerm" {
  features {}
  subscription_id = "541ac1c2-8b44-4aac-abdf-3ce58dd8f753"
}


module "eventhub" {

  source = "../../"


  app_name          = var.app_name
  app_type          = var.app_type
  app_environment   = var.app_environment
  infra_environment = var.infra_environment
  lbbw_location     = var.lbbw_location
  location          = var.location
  sbk               = var.sbk

  tags = {
    source         = "terraform"
    environment    = "development"
    "ITAB"         = "7656"
    "AppName"      = "test"
    "Owner"        = "test"
    "Creator"      = "iac-admin"
    "ServerRole"   = "container-platform"
    "CreationDate" = "auto-generated"
  }

  subnet_ids = { snet1 : "/subscriptions/541ac1c2-8b44-4aac-abdf-3ce58dd8f753/resourceGroups/euho-e-rg-xtest-ntw/providers/Microsoft.Network/virtualNetworks/euho-e-vnet-xtest/subnets/snet1" }


  eventhub_azure_eh_data_receiver_role_assignments = {
    namespace1 = {
      service_principal_object_ids = ["00000000-0000-0000-0000-000000000000", "00000000-0000-0000-0000-000000000001"]
    }
  }

  eventhub_azure_eh_data_sender_role_assignments = {
    namespace1 = {
      service_principal_object_ids = ["00000000-0000-0000-0000-000000000000", "00000000-0000-0000-0000-000000000001"]
    }
  }


  eventhub_namespaces = {
    namespace1 = {
      sku      = "Standard"
      capacity = 1

      trusted_service_access_enabled = true
      allowed_subnet_keys            = ["snet1"]     // todo
      allowed_ip_addresses           = ["10.0.0.10"] // todo

      eventhubs = {
        eventhub1 = {
          partition_count   = 1
          message_retention = 1

        }
      }
    }
  }
}