# Backup Vault

This module is used to deploy an Azure Backup Vault.

## Created Resources

This module creates the following resources on azure

- ``azurerm_resource_group.rg-bvault``: A reosurce group where the following resources are located.
- ``azurerm_data_protection_backup_vault.bvault``: The backup vault.
- ``azurerm_role_assignment.kv-crypto-officer``: 
- ``azurerm_data_protection_backup_policy_disk.policy-disk``: A policy for managed disks,
- ``azurerm_data_protection_backup_policy_kubernetes_cluster.kubernetes-cluster-default-policy``: A policy for a kubernetes cluster.


## Variables

| Name               | Description                                                               | Type   |
| ------------------ | ------------------------------------------------------------------------- | -------|
| app_environment | This variable defines the app environment of the specific application. Placeholder is 'x' if nothing is set. | string |
| app_name | Name of the application per subscription. | string |
| app_type | Type of app (shared, spoke...) | string |
| lbbw_location | LBBW Location | string |
| location | Azure location | string |
| infra_environment | This variable defines the environment to be built. (Prod,Cert,Dev,Engineering). | string |
| sbk | This variable defines the 'Schutzbedarfsklasse' (1, 2, 3, 4) | string |
| encryption_key_id | The id of the keyvault key that is used for encyption | string |
| keyvault_encryp_rg_id | The resource id of the keyvault's resource group | string |
| backupretention | This variable defines the backupretention. (SHORT, MID, LONG) | string |
| bvault | the object for the bvault | object |
| tags | Map of Tags per subscription | map(string) |


### Vault Model

Model Deployments are described in a list of objects of the following structure:

```
 "bvault" =  {
    soft_delete                = string
    redundancy                 = string
    datastore_type             = string
    retention_duration_in_days = number

    protection_backup_policy_disk = map({
      backup_repeating_time_intervals = list(string)
      default_retention_duration      = string
      time_zone                       = string
      retention_rules = map({
        name     = string
        duration = string
        priority = number
        criteria = {
          absolute_criteria = string
        }
      })
    })

    protection_backup_policy_kubernetes_cluster = map({
      backup_repeating_time_intervals = list(string)
      time_zone                       = string
      retention_rules = map({
        name     = string
        priority = number
        life_cycle = {
          duration        = string
          data_store_type = string
        }
        criteria = {
          absolute_criteria      = string
          days_of_week           = list(string)
          months_of_year         = list(string)
          scheduled_backup_times = list(string)
          weeks_of_month         = list(string)
        }
      })
      default_retention_rule = {
        life_cycle = {
          duration        = string
          data_store_type = string
        }
      }
    })
}

```

## Output

| Name                 | Description                                                                                                       |
| -------------------- | ----------------------------------------------------------------------------------------------------------------- |
| id                   | The id of the backup vault.                                                                                       |
| name                 | The name of the backup vault.                                                                                     |
| rg_name              | The name of the resource group where the backup vault is located.                                                 |
| principal_id         | The principal id of the backup vault.                                                                             |
| kubernetes_policy_id | The id of the kubernetes policy.                                                                                  |
| disk_policy_names    | The names of the disk policies. (Tests)                                                                           |
| kubernetes_policy_names | The names of the kubernetes policies. (Tests)                                                                  |
| blob_policy_id       | The Id  of the blob policy                                                                                        |

## Required Modules
- keyvault