locals {
  name_prefix     = "${var.lbbw_location}-${var.infra_environment}"
  prefix_app_name = "${var.app_environment}${var.app_name}"

  common_tags = merge(
    var.tags,
    { CreationDateTime = formatdate("YYYY-MM-DD'T'hh:mm:ss'Z'", timestamp()) }
  )

  backup_options = {
    Option1 = {
      e = {
        weekdays          = ["Tuesday"]
        weekday_as_number = "02"
        time              = "13:00"
      }
      d = {
        weekdays          = ["Tuesday"]
        weekday_as_number = "02"
        time              = "13:00"
      }
      c = {
        weekdays          = ["Tuesday"]
        weekday_as_number = "02"
        time              = "13:00"
      }
      p = {
        weekdays          = ["Tuesday"]
        weekday_as_number = "02"
        time              = "15:00"
      }
    }
    Option2 = {
      e = {
        weekdays          = ["Wednesday"]
        weekday_as_number = "03"
        time              = "13:00"
      }
      d = {
        weekdays          = ["Wednesday"]
        weekday_as_number = "03"
        time              = "13:00"
      }
      c = {
        weekdays          = ["Wednesday"]
        weekday_as_number = "03"
        time              = "13:00"
      }
      p = {
        weekdays          = ["Thursday"]
        weekday_as_number = "04"
        time              = "15:00"
      }
    }
    Option3 = {
      e = {
        weekdays          = ["Thursday"]
        weekday_as_number = "04"
        time              = "13:00"
      }
      d = {
        weekdays          = ["Thursday"]
        weekday_as_number = "04"
        time              = "13:00"
      }
      c = {
        weekdays          = ["Thursday"]
        weekday_as_number = "04"
        time              = "13:00"
      }
      p = {
        weekdays          = ["Saturday"]
        weekday_as_number = "06"
        time              = "04:00"
      }
    }
  }

  backupretention_aks = var.backupretention == "SHORT" ? "30" : "90" # if MID or LONG: 90
}

