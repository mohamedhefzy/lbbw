variable "app_environment" {
  description = "This variable defines the app environment of the specific application. Placeholder is 'x' if nothing is set."
  type        = string
}

variable "app_name" {
  description = "Name of the application per subscription"
  type        = string
}

variable "app_type" {
  description = "Type of app (shared, spoke...)"
  type        = string
}

variable "lbbw_location" {
  description = "LBBW Location"
  type        = string
}

variable "location" {
  description = "Azure location"
  type        = string
}

variable "infra_environment" {
  description = "This variable defines the environment to be built. (Prod,Cert,Dev,Engineering)."
  type        = string
}

variable "sbk" {
  description = "This variable defines the 'Schutzbedarfsklasse' (1, 2, 3, 4)"
  type        = string
}

variable "encryption_key_id" {
  description = "The id of the keyvault key that is used for encyption"
  type        = string
}

variable "keyvault_encryp_rg_id" {
  description = "The resource id of the keyvault's resource group"
  type        = string
}

variable "patchwindow" {
  description = "This variable defines the patchwindow (Option1, Option2, Option3)"
  type        = string
}

variable "backupretention" {
  description = "This variable defines the backupretention (SHORT, MID, LONG)"
  type        = string
}


variable "bvault" {
  type = object({
    soft_delete                = string
    redundancy                 = string
    datastore_type             = string
    retention_duration_in_days = number
  })
}

variable "tags" {
  description = "Map of Tags per subscription"
  type        = map(string)
}
