output "id" {
  value = azurerm_data_protection_backup_vault.bvault.id
}

output "name" {
  value = azurerm_data_protection_backup_vault.bvault.name
}

output "rg_name" {
  value = azurerm_resource_group.rg-bvault.name
}

output "principal_id" {
  value = azurerm_data_protection_backup_vault.bvault.identity[0].principal_id
}

output "kubernetes_policy_id" {
  value = azurerm_data_protection_backup_policy_kubernetes_cluster.kubernetes-cluster-default-policy.id
}

output "disk_policy_id" {
  value = azurerm_data_protection_backup_policy_disk.policy-disk.id
}

output "postgres_policy_id" {
  value = azurerm_data_protection_backup_policy_postgresql_flexible_server.policy-postgres-flex-server.id
}

output "kubernetes_policy_name" {
  value = azurerm_data_protection_backup_policy_kubernetes_cluster.kubernetes-cluster-default-policy.name
}

output "disk_policy_name" {
  value = azurerm_data_protection_backup_policy_disk.policy-disk.name
}

output "postgres_policy_name" {
  value = azurerm_data_protection_backup_policy_postgresql_flexible_server.policy-postgres-flex-server.name
}

output "blob_policy_id" {
  value = azurerm_data_protection_backup_policy_blob_storage.policy-blob.id
}