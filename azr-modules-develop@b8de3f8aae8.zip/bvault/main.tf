data "azurerm_client_config" "current" {
  # Returns the values of the currently logged in user
  # client_id         - is set to the Azure Client ID (Application Object ID).
  # tenant_id         - is set to the Azure Tenant ID.
  # subscription_id   - is set to the Azure Subscription ID.
  # object_id         - is set to the Azure Object ID.
}

// todo why?
data "azurerm_subscription" "current" {
}

resource "azurerm_resource_group" "rg-bvault" {
  name     = "${local.name_prefix}-rg-${local.prefix_app_name}-bvault"
  location = var.location

  # tags = local.common_tags
  tags = var.tags

  lifecycle {
    ignore_changes = [
      tags["CreationDateTime"],
      tags["Owner"],
      tags["Environment"],
      tags["ITAB"],
      tags["AppName"],
      tags["AppEnv"],
      tags["SubscriptionType"],
      tags["PlatformId"],
      tags["Availability"],
      tags["Confidentiality"],
      tags["Integrity"]
    ]
  }
}

resource "azurerm_data_protection_backup_vault" "bvault" {
  name                       = "${local.name_prefix}-bvault-${local.prefix_app_name}"
  resource_group_name        = azurerm_resource_group.rg-bvault.name
  location                   = azurerm_resource_group.rg-bvault.location
  datastore_type             = var.bvault.datastore_type
  redundancy                 = var.bvault.redundancy
  soft_delete                = var.bvault.soft_delete
  retention_duration_in_days = var.bvault.retention_duration_in_days

  identity {
    type = "SystemAssigned"
  }

  tags = var.tags

  lifecycle {
    ignore_changes = [
      tags["CreationDateTime"],
      tags["Owner"],
      tags["Environment"],
      tags["ITAB"],
      tags["AppName"],
      tags["AppEnv"],
      tags["SubscriptionType"],
      tags["PlatformId"],
      tags["Availability"],
      tags["Confidentiality"],
      tags["Integrity"]
    ]
  }

}

## Give the SystemAssigned Identiy the right to read from the encryp 

# Importing the Key Vault Crypto Officer role. This is necessary bc of a bug: https://github.com/hashicorp/terraform-provider-azurerm/issues/4258
data "azurerm_role_definition" "kv-crypto-officer-role" {
  role_definition_id = "14b46e9e-c2b7-41b4-b07b-48a6ebf60603" # Key Vault Administrator
}

resource "azurerm_role_assignment" "kv-crypto-officer" {
  scope              = var.keyvault_encryp_rg_id
  role_definition_id = data.azurerm_role_definition.kv-crypto-officer-role.id
  principal_id       = azurerm_data_protection_backup_vault.bvault.identity[0].principal_id
  lifecycle {
    ignore_changes = [
      # Somehow the reole definition id gets forced to recreate which introduces a bug when creating new keys.
      # ignore it for now
      role_definition_id
    ]
  }
}

resource "azurerm_data_protection_backup_vault_customer_managed_key" "cmk-encryption" {
  count = contains(["3", "4"], var.sbk) ? 1 : 0

  data_protection_backup_vault_id = azurerm_data_protection_backup_vault.bvault.id
  key_vault_key_id                = var.encryption_key_id

  depends_on = [azurerm_data_protection_backup_vault.bvault, azurerm_role_assignment.kv-crypto-officer]
}

resource "azurerm_data_protection_backup_policy_disk" "policy-disk" {
  name     = "bkpol-d"
  vault_id = azurerm_data_protection_backup_vault.bvault.id
  # backup frequency is represented via ISO 8601
  backup_repeating_time_intervals = ["R/2024-01-${local.backup_options[var.patchwindow][var.infra_environment].weekday_as_number}T${local.backup_options[var.patchwindow][var.infra_environment].time}:00+00:00/PT1H"]
  default_retention_duration      = "P14D"

  retention_rule {
    name     = "short-term"
    duration = "P14D"
    priority = 3

    criteria {
      absolute_criteria = "FirstOfDay"
    }
  }
}

resource "azurerm_data_protection_backup_policy_postgresql_flexible_server" "policy-postgres-flex-server" {
  name     = "bkpol-psql"
  vault_id = azurerm_data_protection_backup_vault.bvault.id
  # backup frequency is represented via ISO 8601
  backup_repeating_time_intervals = ["R/2024-01-${local.backup_options[var.patchwindow][var.infra_environment].weekday_as_number}T${local.backup_options[var.patchwindow][var.infra_environment].time}:00+00:00/P1W"]

  default_retention_rule {
    life_cycle {
      # temporarily increased to 35 days as workaround for vaulted recovery failing (SKYWALKER-3202)
      duration        = "P35D"
      data_store_type = "VaultStore"
    }
  }

  dynamic "retention_rule" {
    for_each = var.backupretention == "SHORT" ? [1] : []
    content {
      name = "short-term"
      life_cycle {
        duration        = "P4W"
        data_store_type = "VaultStore"
      }
      priority = 3

      criteria {
        weeks_of_month = ["First"]
        days_of_week   = local.backup_options[var.patchwindow][var.infra_environment].weekdays
      }
    }
  }

  dynamic "retention_rule" {
    for_each = var.backupretention != "SHORT" ? [1] : [] // For MID and LONG
    content {
      name = "mid-term"
      life_cycle {
        duration        = "P12M"
        data_store_type = "VaultStore"
      }
      priority = 2

      criteria {
        weeks_of_month = ["First"]
        days_of_week   = local.backup_options[var.patchwindow][var.infra_environment].weekdays
      }
    }
  }

  dynamic "retention_rule" {
    for_each = var.backupretention == "LONG" ? [1] : []
    content {
      name = "long-term"
      life_cycle {
        duration        = "P10Y"
        data_store_type = "VaultStore"
      }
      priority = 1

      criteria {
        weeks_of_month = ["First"]
        days_of_week   = local.backup_options[var.patchwindow][var.infra_environment].weekdays
      }
    }
  }
}

resource "azurerm_data_protection_backup_policy_kubernetes_cluster" "kubernetes-cluster-default-policy" {
  name                            = "bkpol-k"
  vault_name                      = azurerm_data_protection_backup_vault.bvault.name
  resource_group_name             = azurerm_resource_group.rg-bvault.name
  backup_repeating_time_intervals = ["R/2024-01-${local.backup_options[var.patchwindow][var.infra_environment].weekday_as_number}T${local.backup_options[var.patchwindow][var.infra_environment].time}:00+00:00/PT4H"]

  default_retention_rule {
    life_cycle {
      duration        = "P30D"
      data_store_type = "OperationalStore"
    }
  }

  retention_rule {
    name = "kube-retention"
    life_cycle {
      duration        = "P${local.backupretention_aks}D"
      data_store_type = "OperationalStore"
    }
    priority = 3

    criteria {
      absolute_criteria = "FirstOfDay"
    }
  }
}

resource "azurerm_data_protection_backup_policy_blob_storage" "policy-blob" {
  name                             = "bkpol-blob"
  vault_id                         = azurerm_data_protection_backup_vault.bvault.id
  vault_default_retention_duration = "P30D"
  backup_repeating_time_intervals  = ["R/2025-05-${local.backup_options[var.patchwindow][var.infra_environment].weekday_as_number}T${local.backup_options[var.patchwindow][var.infra_environment].time}:00+00:00/P1D"]

  retention_rule {
    name = "short-term"
    life_cycle {
      duration        = "P4W"
      data_store_type = "VaultStore"
    }
    priority = 3

    criteria {
      absolute_criteria = "FirstOfDay"
    }
  }

  dynamic "retention_rule" {
    for_each = var.backupretention != "SHORT" ? [1] : [] // For MID and LONG
    content {
      name = "mid-term"
      life_cycle {
        duration        = "P12M"
        data_store_type = "VaultStore"
      }
      priority = 2

      criteria {
        days_of_week = local.backup_options[var.patchwindow][var.infra_environment].weekdays
      }
    }
  }

  dynamic "retention_rule" {
    for_each = var.backupretention == "LONG" ? [1] : []
    content {
      name = "long-term"
      life_cycle {
        duration        = "P10Y"
        data_store_type = "VaultStore"
      }
      priority = 1

      criteria {
        weeks_of_month = ["First"]
        days_of_week   = local.backup_options[var.patchwindow][var.infra_environment].weekdays
      }
    }
  }
}
