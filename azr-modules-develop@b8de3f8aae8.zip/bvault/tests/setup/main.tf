provider "azurerm" {
  features {}
  subscription_id = "541ac1c2-8b44-4aac-abdf-3ce58dd8f753"
}

module "bvault" {

  source = "../../"

  app_name          = var.app_name
  app_type          = var.app_type
  app_environment   = var.app_environment
  infra_environment = var.infra_environment
  lbbw_location     = var.lbbw_location
  location          = var.location

  backupretention = var.backupretention
  patchwindow     = var.patchwindow

  sbk = var.sbk

  tags = {
    source         = "terraform"
    environment    = "development"
    "ITAB"         = "7656"
    "AppName"      = "test"
    "Owner"        = "test"
    "Creator"      = "iac-admin"
    "ServerRole"   = "container-platform"
    "CreationDate" = "auto-generated"
  }

  encryption_key_id     = "https://euho-e-kv-xtest-encryp.vault.azure.net/keys/kvk-xtest-rsvault/4f6f9a1ad9264dc6a1baa724f3461de3"
  keyvault_encryp_rg_id = "/subscriptions/541ac1c2-8b44-4aac-abdf-3ce58dd8f753/resourceGroups/euho-e-rg-xtest-kv"

  bvault = {
    soft_delete                = "On"
    redundancy                 = "GeoRedundant"
    datastore_type             = "VaultStore"
    retention_duration_in_days = 30
  }
}
