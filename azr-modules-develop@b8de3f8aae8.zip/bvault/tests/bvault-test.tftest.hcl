run "execute" {
  module {
    source = "./setup"
  }

  command = plan

  assert {
    condition     = module.bvault.name == "euho-e-bvault-xtest"
    error_message = "The name of the backup vault does not match."
  }

  assert {
    condition     = module.bvault.rg_name == "euho-e-rg-xtest-bvault"
    error_message = "The name of the backup vault resource group does not match"
  }

  assert {
    condition     = module.bvault.kubernetes_policy_name == "bkpol-k"
    error_message = "The name of the kubernetes policy does not match"
  }

  assert {
    condition     = module.bvault.disk_policy_name == "bkpol-d"
    error_message = "The name of the disk policy does ot match"
  }

  assert {
    condition     = module.bvault.postgres_policy_name == "bkpol-psql"
    error_message = "The name of the postgres policy does ot match"
  }
}