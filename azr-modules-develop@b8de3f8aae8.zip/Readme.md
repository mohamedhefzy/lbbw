### Landing Zone Deployment Order

This table describes which modules have to get rolled-out in which order for a functioning landing zone (LZ) to be created.
It's meant as a supportive view for people creating LZs. Real technical dependencies between each modules are depicted in the second table on this page.

#### Comments

- Numbers in brackets does mean that this deployment is optional for the LZ.
- If you check the respective modules in the deployment pipeline all at once, the pipeline will take care of the deployment order automatically.


| Module Folder        | AKS | VM |
| :--------------------- | :---: | :---: |
| defender             |  1  |  1  |
| ntwspoke             |  2  |  2  |
| dnszone              |  3  |  3  |
| keyvault             |  4  |  4  |
| eventhub             |  5  |  5  |
| bvault               |  6  |     |
| rsvault              |     |  6  |
| azsql (mssql)        | (7) | (7) |
| postgres             | (8) | (8) |
| storageaccount       |  9  |  9  |
| aks                  | 10 |     |
| kubernetes           | 11 |     |
| pmakskured           | 12 |     |
| pmaksingressnginx    | 13 |     |
| pmaksexternaldns     | 14 |     |
| pmaksexternalsecrets | 15 |     |
| vm                   |     | 10 |
| pmvmoneagent         |     | 11 |
| pmvmmsagent          |     | 12 |
| pmvmopenssh          |     | 13 |
| lb                   |     |     |
| pmaksoneagent        | 16 |     |
| iam                  | 17 | 14 |

### Dependency Matrix (Apply)

This table depicts the technical dependencies between each modules if wanting to apply it. Destruction has to happen in reverse order.

#### Comments

- `x`: Required for deployment.
- `-`: Not applicable.
- Defender introduces no hard dependency onto other modules but can't scan resources that got deployed before it's activation.


| Module Folder | DEFENDER | NTWSPOKE | DNSZONE | Keyvault | EventHub | BVault | RSVault | Azure SQL | Postgres | Storage | AKS | Kubernetes | Helm | VM | VM Postmodules | LB | IAM | AKS OneAgent |
| :--------------: | :--------: | :--------: | :-------: | :--------: | :--------: | :------: | :-------: | :---------: | :--------: | :-------: | :---: | :----------: | :----: | :--: | :--------------: | :--: | :-----: | :------------: |
|    defender    |    -    |    x    |    x    |    x    |    x    |   x   |    x    |     x     |    x    |    x    |  x  |     x     |  x  | x |       x       | x |     |      x      |
|    ntwspoke    |         |    -    |    x    |    x    |    x    |   x   |    x    |     x     |    x    |    x    |  x  |     x     |  x  | x |       x       |   |     |      x      |
|    dnszone    |         |         |    -    |         |         |       |         |           |         |         |  x  |     x     |  x  | x |       x       |   |     |      x      |
|    keyvault    |         |         |         |    -    |    x    |   x   |    x    |     x     |    x    |    x    |  x  |     x     |  x  | x |       x       |   | x   |      x      |
|    eventhub    |         |         |         |         |    -    |       |         |           |         |         |  x  |           |     |   |               |   |     |             |
|     bvault     |         |         |         |         |         |   -   |         |           |    x    |    x    |  x  |     x     |  x  | x |       x       |   |     |      x      |
|    rsvault    |         |         |         |         |         |       |    -    |           |         |         |  x  |     x     |  x  | x |       x       |   |     |      x      |
|     azsql     |         |         |         |         |         |       |         |     -     |         |         |     |           |     |   |               |   |     |             |
|    postgres    |         |         |         |         |         |       |         |           |    -    |         | (x) |           |     |   |               |   |     |             |
| storageaccount |         |         |         |         |         |       |         |           |         |    -    |  x  |     x     |  x  |   |               |   |     |      x      |
|      aks      |         |         |         |         |         |       |         |           |         |         |  -  |     x     |  x  |   |               |   | (x) |      x      |
|   kubernetes   |         |         |         |         |         |       |         |           |         |         |     |     -     |  x  |   |               |   | (x) |      x      |
|      helm      |         |         |         |         |         |       |         |           |         |         |     |           |  -  |   |               |   |     |             |
|       vm       |         |         |         |         |         |       |         |           |         |         |     |           |     | - |       x       |   |     |             |
| vm postmodules |         |         |         |         |         |       |         |           |         |         |     |           |     |   |       -       |   |     |             |
|       lb       |         |         |         |         |         |       |         |           |         |         |     |           |     |   |               |   |     |             |
|      iam      |         |         |         |         |         |       |         |           |         |         |  x  |     x     |  x  | x |       x       |   | -   |      x      |
|  pm aks agent  |         |         |         |         |         |       |         |           |         |         |     |           |     |   |               |   |     |      -      |
