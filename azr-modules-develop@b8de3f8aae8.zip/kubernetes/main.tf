provider "kubernetes" {
  host                   = var.cluster_config.host
  username               = var.cluster_config.username
  password               = var.cluster_config.password
  client_certificate     = var.cluster_config.client_certificate
  client_key             = var.cluster_config.client_key
  cluster_ca_certificate = var.cluster_config.cluster_ca_certificate
}

data "azurerm_client_config" "current" {
  # Returns the values of the currently logged in user
  # client_id         - is set to the Azure Client ID (Application Object ID).
  # tenant_id         - is set to the Azure Tenant ID.
  # subscription_id   - is set to the Azure Subscription ID.
  # object_id         - is set to the Azure Object ID.
}

resource "kubernetes_namespace" "namespaces" {
  for_each = local.all_created_namespaces
  metadata {
    name = each.value
  }
  lifecycle {
    ignore_changes = [metadata["labels"]]
  }
}

resource "kubernetes_secret" "docker_registry" {
  for_each = local.all_platform_namespaces
  metadata {
    name      = "artifactory-registry-secret"
    namespace = each.value
  }

  type = "kubernetes.io/dockerconfigjson"

  data = {
    ".dockerconfigjson" : jsonencode({
      auths = {
        "${local.artifactory_docker_url}.artifactory.lbbw.sko.de" = {
          auth = base64encode("${var.artifactory_username}:${var.artifactory_password}")
        }

      }
    })
  }
  depends_on = [kubernetes_namespace.namespaces]
}

resource "kubernetes_service_account" "workload_identity_sa" {
  for_each = var.user_assigned_identity_client_ids_aks != null ? var.user_assigned_identity_client_ids_aks : {}
  metadata {
    name      = "workload-identity-sa-${each.key}"
    namespace = each.key
    annotations = {
      "azure.workload.identity/client-id" : each.value
      "azure.workload.identity/tenant-id" : data.azurerm_client_config.current.tenant_id
    }
  }
}

resource "kubernetes_service_account" "workload_identity_sa_mssql" {
  for_each = local.mssql_mid_all_created_namespaces_combination != null ? local.mssql_mid_all_created_namespaces_combination : {}
  metadata {
    name      = "workload-identity-sa-mssql-${each.value.mssql_mid_name}"
    namespace = each.value.namespace
    annotations = {
      "azure.workload.identity/client-id" : each.value.mssql_mid_client_id
      "azure.workload.identity/tenant-id" : data.azurerm_client_config.current.tenant_id
    }
  }
}

##############################################
#### Connection between aks and key vault ####
##############################################

resource "azurerm_federated_identity_credential" "federated_identity" {
  for_each            = var.user_assigned_identity_ids_aks != null ? var.user_assigned_identity_ids_aks : {}
  name                = each.key
  resource_group_name = var.aks_rg_name
  parent_id           = each.value
  audience            = ["api://AzureADTokenExchange"]
  issuer              = var.oidc_issuer_url
  subject             = "system:serviceaccount:${each.key}:workload-identity-sa-${each.key}"
}

resource "azurerm_federated_identity_credential" "federated_identity_mssql" {
  for_each            = local.mssql_mid_all_created_namespaces_federation_combination != null ? local.mssql_mid_all_created_namespaces_federation_combination : {}
  name                = each.value.namespace
  resource_group_name = var.mssql_rg_name
  parent_id           = each.value.mssql_mid_id
  audience            = ["api://AzureADTokenExchange"]
  issuer              = var.oidc_issuer_url
  subject             = "system:serviceaccount:${each.value.namespace}:workload-identity-sa-mssql-${each.value.mssql_mid_name}"
}

#####################################################
#### Connection between aks and private dns zone ####
#####################################################

resource "azurerm_federated_identity_credential" "federated_identity-external-dns" {
  name                = "external-dns"
  resource_group_name = var.aks_rg_name
  parent_id           = var.user_assigned_identity_default_id_aks
  audience            = ["api://AzureADTokenExchange"]
  issuer              = var.oidc_issuer_url
  subject             = "system:serviceaccount:external-dns:external-dns"
}


###################################################
############### Service Account ###################
###################################################
// todo ???
resource "kubernetes_service_account" "service-accounts" {
  for_each = var.kubernetes.service_accounts
  metadata {
    name      = each.value.name
    namespace = each.value.namespace
  }
}

resource "kubernetes_cluster_role" "cluster-role" {
  for_each = length(var.kubernetes.service_accounts) != 0 ? local.roles : {}
  metadata {
    name = each.value.name
  }

  dynamic "rule" {
    for_each = each.value.rules
    content {
      api_groups = rule.value.api_groups
      resources  = rule.value.resources
      verbs      = rule.value.verbs
    }
  }
}

resource "kubernetes_cluster_role_binding" "role-binding" {
  count = length(var.kubernetes.service_accounts) != 0 ? 1 : 0

  metadata {
    name = "pod-admin-role-binding"
  }

  dynamic "subject" {
    for_each = var.kubernetes.service_accounts

    content {
      kind      = "ServiceAccount"
      name      = subject.value.name
      namespace = subject.value.namespace
    }
  }

  role_ref {
    kind      = "ClusterRole"
    name      = "pod-admin" // at the momemt there is only one type on offer. For new types, a dynamic solution must be built here.
    api_group = "rbac.authorization.k8s.io"

  }

  depends_on = [kubernetes_service_account.service-accounts, kubernetes_cluster_role_binding.role-binding]
}



###################################################
###############    ServiceNow   ###################
###################################################

resource "kubernetes_cluster_role" "cluster-role-servicenow" {
  metadata {
    name = "servicenow-role"
  }

  rule {
    api_groups = [""]
    resources  = ["nodes"]
    verbs      = ["list"]
  }
}

resource "kubernetes_cluster_role_binding" "role-binding-servicenow" {
  metadata {
    name = "servicenow-rolebinding"
  }
  subject {
    kind = "User"
    name = local.servicenow_cmdb_sp
  }
  role_ref {
    kind      = "ClusterRole"
    name      = "servicenow-role"
    api_group = "rbac.authorization.k8s.io"
  }

  depends_on = [kubernetes_service_account.service-accounts, kubernetes_cluster_role_binding.role-binding]
}