variable "app_environment" {
  description = "This variable defines the app environment of the specific application. Placeholder is 'x' if nothing is set."
  type        = string
}

variable "app_name" {
  description = "Name of the application per subscription"
  type        = string
}

variable "infra_environment" {
  description = "This variable defines the environment to be built. (Prod,Cert,Dev,Engineering)."
  type        = string
}

variable "artifactory_username" {
  description = "The artifatory username"
  type        = string
}

variable "artifactory_password" {
  description = "The artifactory passowrd"
  type        = string
}

variable "user_assigned_identity_ids_aks" {
  description = "The user assigend identity ids of the aks"
  type        = map(string)
}

variable "user_assigned_identity_client_ids_aks" {
  description = "The user assigend identities client ids."
  type        = map(string)
}

variable "user_assigned_identity_default_id_aks" {
  description = "The default user assigend identity id."
  type        = string
}

variable "user_assigned_identity_ids_mssql" {
  description = "The user assigned identity ids of the mssql server"
  type        = map(string)
}

variable "user_assigned_identity_client_ids_mssql" {
  description = "The user assigned identity client ids of the mssql server"
  type        = map(string)
}

variable "oidc_issuer_url" {
  description = "The oidc issuer url of AKS"
  type        = string
}

variable "aks_rg_name" {
  description = "The `azurerm_kubernetes_cluster`'s resource group name."
  type        = string
}


variable "mssql_rg_name" {
  description = "The mssql servers resource group name."
  type        = string
}

variable "cluster_config" {
  description = "Kubernetes Cluster Konfigurationsdetails"
  type = object({
    host                   = string
    username               = string
    password               = string
    client_certificate     = string
    client_key             = string
    cluster_ca_certificate = string
  })
}

variable "kubernetes" {
  description = "The kubernetes config for the aks."
  type = object({
    namespaces = map(string)
    service_accounts = map(object({
      name      = string
      namespace = string
      type      = string
    }))
  })
}
