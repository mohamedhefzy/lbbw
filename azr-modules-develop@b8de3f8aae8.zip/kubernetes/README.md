# Postgres

This module is used to deploy kubernetes resources in the aks.

## Created Resources

This module creates the following resources
``kubernetes_namespace.namespaces``: All required namespaces are created.
``kubernetes_secret.docker_registry``:  The docker-regestry secrets in all namespaces to be able to pull docker images.
``kubernetes_service_account.workload_identity_sa``:  Creates a service account for the workload identity inside aks.
``azurerm_federated_identity_credential.federated_identity``: Is used for authentication between managed identity, aks to keyvault.
``azurerm_federated_identity_credential.federated_identity-external-dns``: Is used for authentication between managed identity, aks to private dns zone.
``kubernetes_service_account.service-accounts``: Creates service accounts
``kubernetes_cluster_role.cluster-role``: Creates a cluster role. At the moment only the role pod admin exists.
``kubernetes_cluster_role_binding.role-binding``: Connects the service account with the role.

## Variables

| Name               | Description                                                               | Type   |
| ------------------ | --------------------------------------------------------------------------| -------|
| app_environment | This variable defines the app environment of the specific application. Placeholder is 'x' if nothing is set. | string |
| app_name | Name of the application per subscription. | string |
| infra_environment |  This variable defines the environment to be built. (Prod,Cert,Dev,Engineering). | string |
| artifactory_username| The artifactory user name | string |
| artifactory_password | The artifactory password | string |
| user_assigned_identity_ids_aks | The user assigend identity ids of the aks | string |
| user_assigned_identity_client_ids_aks | The user assigend identity client_ids of the aks | string |
| oidc_issuer_url | The oidc issuer url of AKS. | string |
| aks_rg_name | The azurerm_kubernetes_cluster's resource group name. | string |
| cluster_config | The cluster config of the aks. | object |
| kubernetes | Config of the kubernetes resources. | object |
| user_assigned_identity_ids_mssql | The IDs of the MSSQL MID. If MSSQL is not rolled out, it's an empty object. | object | 
| user_assigned_identity_client_ids_mssql | The client IDs of the MSSQL MID. If MSSQL is not rolled out, it's an empty object | object |
| mssql_rg_name | The Resource Group of the MSSQL MID. If MSSQL is not rolled out, it's an empty string | string |


### Kubernetes Model

Model Deployments are described in a list of objects of the following structure:

```

kubernetes = {
    namespaces      = map(string)
    vnet_subnet_key = string
    service_accounts = map({
      name      = string
      namespace = string
      type      = string
    })
}

```

### Output

| Name                 | Description                                                                                                       |
| -------------------- | ----------------------------------------------------------------------------------------------------------------- |

## Required Modules
- aks