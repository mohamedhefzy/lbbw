output "restore_namespaces" {
  description = "The custom namespaces on which customers should have access to."
  value       = local.restore_namespaces
}