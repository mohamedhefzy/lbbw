locals {
  artifactory_docker_url = var.infra_environment == "e" ? "skywalker-docker-dev" : "skywalker-docker-prod"
  servicenow_cmdb_sp     = var.infra_environment == "e" ? "1b63e410-7f34-4476-96a6-91ed77b74d19" : (var.infra_environment == "d" ? "c93ca423-ceac-42f4-b01f-e49fd7a8cc6d" : (var.infra_environment == "c" ? "636f3009-f028-473e-a216-f88b40eef1a2" : (var.infra_environment == "p" ? "f3526a3a-dd5b-4770-b514-fd1f7ea87b9a" : "unknown")))

  # euho-e-8588-shared-CMDB	1b63e410-7f34-4476-96a6-91ed77b74d19
  # euho-d-8588-shared-CMDB	c93ca423-ceac-42f4-b01f-e49fd7a8cc6d
  # euho-c-8588-shared-CMDB	636f3009-f028-473e-a216-f88b40eef1a2
  # euho-p-8588-shared-CMDB	f3526a3a-dd5b-4770-b514-fd1f7ea87b9a

  existing_namespaces = {
    default = "default"
  }
  default_namespaces = {
    dynatrace        = "dynatrace"
    infrastructure   = "infrastructure"
    external-secrets = "external-secrets"
    external-dns     = "external-dns"
    kured            = "kured"
  }
  restore_namespaces = {
    restore = "restore"
  }

  all_platform_namespaces = merge(local.existing_namespaces, local.default_namespaces)
  all_created_namespaces  = merge(var.kubernetes.namespaces, local.default_namespaces, local.restore_namespaces)

  # Wir brauchen leider das Produkt aller Namespace x aller MSSQL Server MIDs IDs. Grund hierfür ist, dass jeder Namespace einen Service Account mit
  # allen MSSQL Server MID IDs benötigt. Falls jemand eine bessere Lösung findet, gerne refactoren.
  mssql_mid_all_created_namespaces_combination = {
    for combination in flatten([
      for ns in local.all_created_namespaces : [
        for k, v in var.user_assigned_identity_client_ids_mssql : {
          key = "${ns}-${k}"
          value = {
            namespace           = ns
            mssql_mid_name      = k
            mssql_mid_client_id = v
          }
        }
      ]
    ]) : combination.key => combination.value
  }

  # Wir brauchen leider das Produkt aller Namespace x aller MSSQL Server MIDs Client IDs. Grund hierfür ist, dass jeder Namespace einen Service Account mit
  # allen MSSQL Server MID IDs benötigt. Falls jemand eine bessere Lösung findet, gerne refactoren.  
  mssql_mid_all_created_namespaces_federation_combination = {
    for combination in flatten([
      for ns in local.all_created_namespaces : [
        for k, v in var.user_assigned_identity_ids_mssql : {
          key = "${ns}-${k}"
          value = {
            namespace      = ns
            mssql_mid_name = k
            mssql_mid_id   = v
          }
        }
      ]
    ]) : combination.key => combination.value
  }



  roles = {
    pod-admin = {
      name = "pod-admin"
      rules = {
        rule1 = {
          api_groups = [""]
          resources  = ["pods"]
          verbs      = ["create", "get", "list", "watch", "delete", "update", "patch"]
        }
        rule2 = {
          api_groups = [""]
          resources  = ["pods/exec"]
          verbs      = ["create", "delete", "get", "list", "patch", "update", "watch"]
        }
        rule3 = {
          api_groups = [""]
          resources  = ["pods/log"]
          verbs      = ["get", "list", "watch"]
        }
        rule4 = {
          api_groups = [""]
          resources  = ["events"]
          verbs      = ["watch"]
        }
        rule5 = {
          api_groups = [""]
          resources  = ["secrets"]
          verbs      = ["get"]
        }
      }
    }
  }
}
