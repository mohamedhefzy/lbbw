# Postgres

This module is used to deploy helm resources in the aks.

## Created Resources

This module creates the following resources

``helm_release.generic_chart``: A generic resource to deploy helm charts.


## Variables

| Name               | Description                                                               | Type   |
| ------------------ | --------------------------------------------------------------------------| -------|
| app_environment | This variable defines the app environment of the specific application. Placeholder is 'x' if nothing is set. | string |
| app_name | Name of the application per subscription. | string |
| infra_environment |  This variable defines the environment to be built. (Prod,Cert,Dev,Engineering). | string |
| artifactory_username| The artifactory user name | string |
| artifactory_password | The artifactory password | string |
| private_dns_rg_name | Private DNS Zone Resource Group Name | string |
| private_dns_zone_name | Private DNS Zone Name | string |
| cluster_config | The cluster config of the aks. | object |
| user_assigned_identity_default_mid_client_id | The default user assigned identity client_id of aks | string |
| helm | Config of the helm resources. | object |


### Helm Model

Model Deployments are described in a list of objects of the following structure:

```

helm = {
    vnet_subnet_key      = string
    helm_release_configs = map({
        name       = string
        chart      = string
        repository = string
        namespace  = string
        version    = string
        set = list(object({
            name  = string
            value = string
            type  = string
        }))
        set_list = list(object({
            name  = string
            value = list(string)
        }))
    })
}

```

### Output

| Name                 | Description                                                                                                       |
| -------------------- | ----------------------------------------------------------------------------------------------------------------- |

## Required Modules
- dnszone
- aks