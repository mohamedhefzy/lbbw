provider "helm" {
  kubernetes {
    host                   = var.cluster_config.host
    username               = var.cluster_config.username
    password               = var.cluster_config.password
    client_certificate     = var.cluster_config.client_certificate
    client_key             = var.cluster_config.client_key
    cluster_ca_certificate = var.cluster_config.cluster_ca_certificate
  }
}

data "azurerm_client_config" "current" {
  # Returns the values of the currently logged in user
  # client_id         - is set to the Azure Client ID (Application Object ID).
  # tenant_id         - is set to the Azure Tenant ID.
  # subscription_id   - is set to the Azure Subscription ID.
  # object_id         - is set to the Azure Object ID.
}

resource "helm_release" "generic_chart" {
  for_each            = merge(local.filtered_default_helm_charts, var.helm.helm_release_configs)
  name                = each.value.name
  chart               = each.value.chart
  repository          = each.value.repository
  namespace           = each.value.namespace
  repository_username = var.artifactory_username
  repository_password = var.artifactory_password
  version             = each.value.version
  timeout             = 1800

  # config of helm chart
  dynamic "set" {
    for_each = each.value.set
    content {
      name  = set.value.name
      value = set.value.value
      type  = set.value.type
    }
  }
  dynamic "set_list" {
    for_each = each.value.set_list
    content {
      name  = set_list.value.name
      value = set_list.value.value
    }
  }
  values = each.value.values
}
