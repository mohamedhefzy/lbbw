# outputs

output "rg_name" {
  value = azurerm_resource_group.rg-lb.name
}

output "lb_name" {
  value = azurerm_lb.lb.name
}

output "backend_pool_name" {
  value = azurerm_lb_backend_address_pool.lb-backend-pool.name
}

output "backend_address_pool_names" {
  value = { for k, v in azurerm_lb_backend_address_pool_address.lb-backend-pool-address : k => v.name }
}

output "probe_names" {
  value = { for k, v in azurerm_lb_probe.lb-probe : k => v.name }
}

output "rule_names" {
  value = { for k, v in azurerm_lb_rule.lb-rule : k => v.name }
}