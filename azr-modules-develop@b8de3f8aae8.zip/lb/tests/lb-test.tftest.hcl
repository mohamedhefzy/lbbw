
run "execute" {
  module {
    source = "./setup"
  }

  command = plan

  assert {
    condition     = module.lb.rg_name == "euho-e-rg-xtest-lb"
    error_message = "The rg name does not match."
  }

  assert {
    condition     = module.lb.lb_name == "euho-e-lb-xtest"
    error_message = "The lb name does not match."
  }

  assert {
    condition     = module.lb.backend_pool_name == "backend_pool"
    error_message = "The backend pool name does not match."
  }

  assert {
    condition     = module.lb.backend_address_pool_names["address_pool1"] == "lb-bpa-address_pool1"
    error_message = "The address pool name does not match."
  }

  assert {
    condition     = module.lb.probe_names.probe1 == "lb-probe-probe1"
    error_message = "The probe name does not match."
  }

  assert {
    condition     = module.lb.rule_names.rule1 == "lb-rule-rule1"
    error_message = "The rule name does not match."
  }

}
