provider "azurerm" {
  features {}
  subscription_id = "541ac1c2-8b44-4aac-abdf-3ce58dd8f753"
}

module "lb" {

  source = "../../"

  app_name          = var.app_name
  app_type          = var.app_type
  app_environment   = var.app_environment
  infra_environment = var.infra_environment
  lbbw_location     = var.lbbw_location
  location          = var.location

  sbk = var.sbk

  tags = {
    source         = "terraform"
    environment    = "development"
    "ITAB"         = "7656"
    "AppName"      = "test"
    "Owner"        = "test"
    "Creator"      = "iac-admin"
    "ServerRole"   = "container-platform"
    "CreationDate" = "auto-generated"
  }

  ntwspoke_snet_ids = { snet1 : "/subscriptions/xxx-xxx-xxx-xxx-xxx/resourceGroups/euho-e-rg-xtest-ntw/providers/Microsoft.Network/virtualNetworks/euho-e-vnet-xtest/subnets/snet1" }
  ntwspoke_vnet_id  = "/subscriptions/xxx-xxx-xxx-xxx-xxx/resourceGroups/euho-e-rg-xtest-ntw/providers/Microsoft.Network/virtualNetworks/euho-e-vnet-xtest"

  lb = {
    sku = "Standard"


    frontend_ip_configurations = {
      config1 = {
        subnet_id                     = "snet1"
        private_ip_address_allocation = "Static"
        private_ip_address            = "10.0.2.4"
      }
    }

    rules = {
      rule1 = {
        protocol                       = "Tcp"
        frontend_port                  = 3389
        backend_port                   = 3389
        probe_name                     = "probe1"
        backend_pool_name              = "backend_pool"
        frontend_ip_configuration_name = "config1"
      }
    }

    backend_pool = {
      backend_pool_name = "backend_pool"
      address_pool_addresses = {
        address_pool1 = {
          ip_address = "10.0.2.4"
        }
      }
    }

    probes = {
      probe1 = {
        port = 80
      }
    }

  }

}
