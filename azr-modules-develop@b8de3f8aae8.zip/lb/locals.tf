locals {
  name_prefix     = "${var.lbbw_location}-${var.infra_environment}"
  prefix_app_name = "${var.app_environment}${var.app_name}"
}