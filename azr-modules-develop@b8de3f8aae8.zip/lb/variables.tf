variable "app_environment" {
  description = "This variable defines the app environment of the specific application. Placeholder is 'x' if nothing is set."
  type        = string
}

variable "app_name" {
  description = "Name of the application per subscription"
  type        = string
}

variable "app_type" {
  description = "Type of app (shared, spoke...)"
  type        = string
}

variable "lbbw_location" {
  description = "LBBW Location"
  type        = string
}

variable "location" {
  description = "Azure location"
  type        = string
}

variable "infra_environment" {
  description = "This variable defines the environment to be built. (Prod,Cert,Dev,Engineering)."
  type        = string
}

variable "sbk" {
  description = "This variable defines the 'Schutzbedarfsklasse' (1, 2, 3, 4)"
  type        = string
}

variable "ntwspoke_snet_ids" {
  description = ""
  type        = map(string)
}

variable "ntwspoke_vnet_id" {
  description = ""
  type        = string
}

variable "lb" {
  description = "LoadBalancer to be created."
  type = object({
    sku = string


    frontend_ip_configurations = map(object({
      subnet_id                     = string
      private_ip_address_allocation = string
      private_ip_address            = string
    }))

    rules = map(object({
      protocol                       = string
      frontend_port                  = number
      backend_port                   = number
      probe_name                     = string
      backend_pool_name              = string
      frontend_ip_configuration_name = string
    }))

    backend_pool = object({
      backend_pool_name = string
      address_pool_addresses = map(object({
        ip_address = string
      }))
    })

    probes = map(object({
      port = number
    }))
  })
}

variable "tags" {
  description = "Map of Tags per subscription"
  type        = map(string)
}