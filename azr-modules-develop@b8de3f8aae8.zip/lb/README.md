# Load Balancer

This module is used to deploy a Load Balancer.

## Created Resources

This module creates the following resources on azure


- ``azurerm_resource_group.rg-lb``: A resource group where the following resources are located.
- ``azurerm_lb.lb``: The load balancer.
- ``azurerm_lb_probe.lb-probe``: Creates a load balancer probe. A probe monitors the health of backend instances.
- ``azurerm_lb_rule.lb-rule``: Creates a rule how traffic is distributed to the backend pool instances
- ``azurerm_lb_backend_address_pool.lb-backend-pool``: Creates a load balancer backend pool. A backend pool is a collection of backend instances.
- ``azurerm_lb_backend_address_pool_address.lb-backend-pool-address``: Creates a load balancer pool address which refers to the network addresses of the instances.


## Variables

| Name               | Description                                                               | Type   |
| ------------------ | ------------------------------------------------------------------------- | ------ |
| app_environment | This variable defines the app environment of the specific application. Placeholder is 'x' if nothing is set. | string |
| app_name | Name of the application per subscription. | string |
| app_type | Type of app (shared, spoke...) | string |
| lbbw_location | LBBW Location | string |
| location | Azure location | string |
| infra_environment | This variable defines the environment to be built. (Prod,Cert,Dev,Engineering). | string |
| sbk | This variable defines the 'Schutzbedarfsklasse' (1, 2, 3, 4). | string |
| ntwspoke_snet_ids | "" | map(string) |
| ntwspoke_vnet_id | "" | string |
| lb | LoadBalancer to be created. | object |
| tags | Map of Tags per subscription. | map(string) |


### LoadBalancer Model

Model Deployments are described in a list of objects of the following structure:

```

 "lb" = {
    sku = string
    frontend_ip_configurations = map({
      subnet_id                     = string
      private_ip_address_allocation = string
      private_ip_address            = string
    })

    rules = map({
      protocol                       = string
      frontend_port                  = number
      backend_port                   = number
      probe_name                     = string
      backend_pool_name              = string
      frontend_ip_configuration_name = string
    })

    backend_pool = {
      backend_pool_name = string
      address_pool_addresses = map({
        ip_address = string
      })
    }

    probes = map({
      port = number
    })
}

```

### Output
| Name                 | Description                                                                                                       |
| -------------------- | ----------------------------------------------------------------------------------------------------------------- |
| rg_name | The name of the reosurce group. (Tests) |
| lb_name | The name of the load balancer. (Tests) |
| backend_pool_name | The nam eof the backend pool. (Tests) |
| backend_address_pool_names | The backend address pool names. (Tests) |
| probe_names | The name of the probes. (Tests) |
| rule_names | The name of the rules. (Test) |


## Required Modules
- ntwspoke