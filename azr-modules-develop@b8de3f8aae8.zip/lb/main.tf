resource "azurerm_resource_group" "rg-lb" {
  name     = "${local.name_prefix}-rg-${local.prefix_app_name}-lb"
  location = var.location

  tags = var.tags

  lifecycle {
    ignore_changes = [
      tags["CreationDateTime"],
      tags["Owner"],
      tags["Environment"],
      tags["ITAB"],
      tags["AppName"],
      tags["AppEnv"],
      tags["SubscriptionType"],
      tags["PlatformId"],
      tags["Availability"],
      tags["Confidentiality"],
      tags["Integrity"]
    ]
  }
}

resource "azurerm_lb" "lb" {
  name                = "${local.name_prefix}-lb-${local.prefix_app_name}"
  location            = azurerm_resource_group.rg-lb.location
  resource_group_name = azurerm_resource_group.rg-lb.name
  sku                 = var.lb.sku

  dynamic "frontend_ip_configuration" {
    for_each = var.lb.frontend_ip_configurations
    content {
      name                          = frontend_ip_configuration.key
      subnet_id                     = var.ntwspoke_snet_ids[frontend_ip_configuration.value.subnet_id]
      private_ip_address_allocation = frontend_ip_configuration.value.private_ip_address_allocation
      private_ip_address            = frontend_ip_configuration.value.private_ip_address
    }
  }

  tags = var.tags

  lifecycle {
    ignore_changes = [
      tags["CreationDateTime"],
      tags["Owner"],
      tags["Environment"],
      tags["ITAB"],
      tags["AppName"],
      tags["AppEnv"],
      tags["SubscriptionType"],
      tags["PlatformId"],
      tags["Availability"],
      tags["Confidentiality"],
      tags["Integrity"]
    ]
  }
}

resource "azurerm_lb_probe" "lb-probe" {
  for_each        = var.lb.probes
  name            = "lb-probe-${each.key}"
  port            = each.value.port
  loadbalancer_id = azurerm_lb.lb.id
}

resource "azurerm_lb_rule" "lb-rule" {
  for_each                       = var.lb.rules
  name                           = "lb-rule-${each.key}"
  protocol                       = each.value.protocol
  frontend_port                  = each.value.frontend_port
  backend_port                   = each.value.backend_port
  frontend_ip_configuration_name = each.value.frontend_ip_configuration_name
  backend_address_pool_ids       = [azurerm_lb_backend_address_pool.lb-backend-pool.id]
  probe_id                       = azurerm_lb_probe.lb-probe[each.value.probe_name].id
  loadbalancer_id                = azurerm_lb.lb.id
}

resource "azurerm_lb_backend_address_pool" "lb-backend-pool" {
  name            = var.lb.backend_pool.backend_pool_name
  loadbalancer_id = azurerm_lb.lb.id
}

resource "azurerm_lb_backend_address_pool_address" "lb-backend-pool-address" {
  for_each                = var.lb.backend_pool.address_pool_addresses
  name                    = "lb-bpa-${each.key}"
  backend_address_pool_id = azurerm_lb_backend_address_pool.lb-backend-pool.id
  ip_address              = each.value.ip_address
  virtual_network_id      = var.ntwspoke_vnet_id
}
