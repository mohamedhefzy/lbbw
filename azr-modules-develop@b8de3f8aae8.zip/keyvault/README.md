# Key Vault

This module is used to deploy an [Azure Key Vault](https://azure.microsoft.com/en-us/products/key-vault).

## Created Resources

This module creates the following resources on azure

- ``azurerm_resource_group.rg-kv``: A resource group where the following resources are located.
- ``azurerm_key_vault.kv[*]``: The key vaults. Two key vaults are created by default.
- ``azurerm_role_assignment.kv-admin``:  Assign Key Vault Adminstrator Role to the current Managed Idenity - see all Roles: https://learn.microsoft.com/en-us/azure/key-vault/general/rbac-guide
- ``azurerm_key_vault_key.services-encryption-keys``: Creation of encryption keys for all potential services that suppot encryption in this subscription
- ``azurerm_private_endpoint.pls``: Private endpoint to access this module

## Variables

| Name               | Description                                                               | Type   |
| ------------------ | ------------------------------------------------------------------------- | -------|
| app_environment | This variable defines the app environment of the specific application. Placeholder is 'x' if nothing is set. | string |
| app_name | Name of the application per subscription. | string |
| app_type | Type of app (shared, spoke...) | string |
| lbbw_location | LBBW Location | string |
| location | Azure location | string |
| infra_environment | This variable defines the environment to be built. (Prod,Cert,Dev,Engineering). | string |
| sbk | This variable defines the 'Schutzbedarfsklasse' (1, 2, 3, 4) | string |
| subnet_id | Subnet ID for private endpoints. | string |
| tags | Map of Tags per subscription | map(string) |
| vaults | Key vaults | map(object) |


### Vault Model

Model Deployments are described in a list of objects of the following structure:

```
vault = map({
    enabled_for_disk_encryption   = bool
    enabled_for_deployment        = bool
    soft_delete_retention_days    = number
    purge_protection_enabled      = bool
    enable_rbac_authorization     = bool
    public_network_access_enabled = bool
    sku_name                      = string
})

```

| Name          | Description                                      |
| ------------- | ------------------------------------------------ |
| enabled_for_disk_encryption  | Boolean flag to specify whether Azure Disk Encryption is permitted to retrieve secrets from the vault and unwrap keys. |
| enabled_for_deployment   | Boolean flag to specify whether Azure Virtual Machines are permitted to retrieve certificates stored as secrets from the key vault. |
| soft_delete_retention_days | The number of days that items should be retained for once soft-deleted.  |
| purge_protection_enabled | Is Purge Protection enabled for this Key Vault? Is always true if app_environment is not e and sbk is less than 3.  |
| enable_rbac_authorization | Boolean flag to specify whether Azure Key Vault uses Role Based Access Control (RBAC) for authorization of data actions. |
| public_network_access_enabled | Whether public network access is allowed for this Key Vault. |
| sku_name | The Name of the SKU used for this Key Vault. |


## Output

| Name             | Description                                                                                                       |
| ---------------- | ----------------------------------------------------------------------------------------------------------------- |
| kv_ids           | The ids of the key vaults                                                                                         |
| encryp_key_ids   | Endpoint of this cognitive account                                                                                |
| encryp_rg_id     | Id of the resource group where the vault is located.                                                              |
| kv_names         | The names of the key vaults. (Tests)                                                                              |

## Required Modules
- ntwspoke