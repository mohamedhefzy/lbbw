// todo refactor rename this output?
output "encryp_rg_id" {
  value = azurerm_resource_group.rg-kv.id
}

output "kv_ids" {
  value = { for k, v in azurerm_key_vault.kv : k => v.id }
}

output "encryp_key_ids" {
  value = { for k, v in azurerm_key_vault_key.services-encryption-keys : k => v.id }
}

output "kv_names" {
  value = { for k, v in azurerm_key_vault.kv : k => v.name }
}