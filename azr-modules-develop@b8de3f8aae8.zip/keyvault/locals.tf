locals {
  name_prefix     = "${var.lbbw_location}-${var.infra_environment}"
  prefix_app_name = "${var.app_environment}${var.app_name}"

  encryption_vault = {
    encryp = {
      enabled_for_disk_encryption   = true
      enabled_for_deployment        = true
      soft_delete_retention_days    = 89   # There is a bug with 90. It was therefore set to 89.
      purge_protection_enabled      = true // todo !!!!!!!
      enable_rbac_authorization     = true
      sku_name                      = "premium"
      public_network_access_enabled = false
    }
  }

  application_vault = {
    app = {
      enabled_for_disk_encryption   = true
      enabled_for_deployment        = true
      soft_delete_retention_days    = 89   # There is a bug with 90. It was therefore set to 89.
      purge_protection_enabled      = true // todo !!!!
      enable_rbac_authorization     = true
      sku_name                      = "premium"
      public_network_access_enabled = true # Needs to be true in order to enable first movers and their operational engineers to write secrets before AVDs or Jumphost exist. (only works because of policy exemption)
    }
  }

  # Combining the encryp default vault with the user-defined vaults TODO: Is this even necessary or only because shared is no explicit "app"??
  vaults_with_defaults = merge(var.vaults, local.encryption_vault, local.application_vault)
  # vaults_with_defaults = var.app_type == "shared" ? merge(var.vaults, local.encryption_vault) : merge(var.vaults, local.encryption_vault, local.application_vault)

  # List with default encryption keys that get created in the encyrp vault.
  # Attention the keys are used in other modules.
  services_to_encrypt = {
    "vm"             = { key_size = 3072 },
    "bvault"         = { key_size = 3072 },
    "aks"            = { key_size = 3072 },
    "rsvault"        = { key_size = 3072 },
    "storageaccount" = { key_size = 3072 },
    "postgres"       = { key_size = 3072 },
    "azuresql"       = { key_size = 3072 },
    "eventhub"       = { key_size = 3072 }
  }

  private_dns_zone_ids = {
    e = "/subscriptions/a1ce34e0-ffe5-46be-b04b-1cbf0735eeb5/resourceGroups/euho-e-rg-privatednszone/providers/Microsoft.Network/privateDnsZones/"
    d = "/subscriptions/b8c7d5eb-d942-400c-999c-1c741ffb52bf/resourceGroups/euho-d-rg-privatednszone/providers/Microsoft.Network/privateDnsZones/"
    c = "/subscriptions/b79558eb-d4b4-4d56-8f95-8d5c33f7c3cf/resourceGroups/euho-c-rg-privatednszone/providers/Microsoft.Network/privateDnsZones/"
    p = "/subscriptions/2836bb7c-3eaa-4fdd-9024-3f17daf08755/resourceGroups/euho-p-rg-privatednszone/providers/Microsoft.Network/privateDnsZones/"
  }

  private_dns_zone_id_new_tenant = {
    e = "/subscriptions/3da49d2d-46fc-4deb-a3aa-57cbc662e092/resourceGroups/euho-e-rg-privatednszones/providers/Microsoft.Network/privateDnsZones/"
    d = "/subscriptions/ceeadf22-6dcf-47f7-a232-818623b3afdc/resourceGroups/euho-p-rg-privatednszones/providers/Microsoft.Network/privateDnsZones/"
    c = "/subscriptions/ceeadf22-6dcf-47f7-a232-818623b3afdc/resourceGroups/euho-p-rg-privatednszones/providers/Microsoft.Network/privateDnsZones/"
    p = "/subscriptions/ceeadf22-6dcf-47f7-a232-818623b3afdc/resourceGroups/euho-p-rg-privatednszones/providers/Microsoft.Network/privateDnsZones/"
  }
}