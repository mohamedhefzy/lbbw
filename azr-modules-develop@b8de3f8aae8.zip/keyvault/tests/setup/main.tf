provider "azurerm" {
  features {}
  subscription_id = "541ac1c2-8b44-4aac-abdf-3ce58dd8f753"
}


module "keyvault" {

  source = "../../"

  is_old_tenant     = var.is_old_tenant
  app_name          = var.app_name
  app_type          = var.app_type
  app_environment   = var.app_environment
  infra_environment = var.infra_environment
  lbbw_location     = var.lbbw_location
  location          = var.location
  sbk               = var.sbk

  tags = {
    source         = "terraform"
    environment    = "development"
    "ITAB"         = "7656"
    "AppName"      = "test"
    "Owner"        = "test"
    "Creator"      = "iac-admin"
    "ServerRole"   = "container-platform"
    "CreationDate" = "auto-generated"
  }


  subnet_id = "/subscriptions/541ac1c2-8b44-4aac-abdf-3ce58dd8f753/resourceGroups/euho-e-rg-xtest-ntw/providers/Microsoft.Network/virtualNetworks/euho-e-vnet-xtest/subnets/snet-xtest-private_endpoint_subnet"

  vaults = {
    v1 = {
      enabled_for_disk_encryption   = true
      enabled_for_deployment        = true
      soft_delete_retention_days    = 89
      purge_protection_enabled      = true
      enable_rbac_authorization     = true
      public_network_access_enabled = false
      sku_name                      = "premium"
    }
  }
}