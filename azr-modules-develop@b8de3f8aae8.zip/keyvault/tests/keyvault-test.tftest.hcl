run "execute" {
  module {
    source = "./setup"
  }

  command = plan

  assert {
    condition     = module.keyvault.kv_names.v1 == "euho-e-kv-xtest-v1"
    error_message = "The name of the custom vault does not match"
  }

  assert {
    condition     = module.keyvault.kv_names.encryp == "euho-e-kv-xtest-encryp"
    error_message = "The name of the encryption vault does not match."
  }

  assert {
    condition     = module.keyvault.kv_names.app == "euho-e-kv-xtest-app"
    error_message = "The name of the application vault does not match."
  }

  assert {
    condition     = length(module.keyvault.encryp_key_ids) == 7
    error_message = "The length of encryp keys does not match."
  }

}