data "azurerm_client_config" "current" {
  # Returns the values of the currently logged in user
  # client_id         - is set to the Azure Client ID (Application Object ID).
  # tenant_id         - is set to the Azure Tenant ID.
  # subscription_id   - is set to the Azure Subscription ID.
  # object_id         - is set to the Azure Object ID.
}

# Importing the Key Vault Administrator Role. This is necessary bc of a bug: https://github.com/hashicorp/terraform-provider-azurerm/issues/4258
data "azurerm_role_definition" "kv-admin-role" {
  role_definition_id = "00482a5a-887f-4fb3-b363-3b7fe8e74483" # Key Vault Administrator
}

resource "azurerm_resource_group" "rg-kv" {
  name     = "${local.name_prefix}-rg-${local.prefix_app_name}-kv"
  location = var.location

  tags = var.tags

  lifecycle {
    ignore_changes = [
      tags["CreationDateTime"],
      tags["Owner"],
      tags["Environment"],
      tags["ITAB"],
      tags["AppName"],
      tags["AppEnv"],
      tags["SubscriptionType"],
      tags["PlatformId"],
      tags["Availability"],
      tags["Confidentiality"],
      tags["Integrity"]
    ]
  }
}

resource "azurerm_key_vault" "kv" {
  for_each = local.vaults_with_defaults

  name                          = "${local.name_prefix}-kv-${local.prefix_app_name}-${each.key}"
  location                      = var.location
  resource_group_name           = azurerm_resource_group.rg-kv.name
  enabled_for_disk_encryption   = each.value.enabled_for_disk_encryption
  enabled_for_deployment        = each.value.enabled_for_deployment
  tenant_id                     = data.azurerm_client_config.current.tenant_id
  soft_delete_retention_days    = each.value.soft_delete_retention_days
  purge_protection_enabled      = each.value.purge_protection_enabled
  enable_rbac_authorization     = each.value.enable_rbac_authorization
  public_network_access_enabled = each.value.public_network_access_enabled
  sku_name                      = each.value.sku_name

  network_acls {
    bypass         = "AzureServices"
    default_action = "Deny"
    ip_rules       = ["193.111.169.0/24", "91.198.67.0/24"]
  }

  tags = var.tags

  lifecycle {
    ignore_changes = [
      tags["CreationDateTime"],
      tags["Owner"],
      tags["Environment"],
      tags["ITAB"],
      tags["AppName"],
      tags["AppEnv"],
      tags["SubscriptionType"],
      tags["PlatformId"],
      tags["Availability"],
      tags["Confidentiality"],
      tags["Integrity"]
    ]
  }
}

resource "azurerm_role_assignment" "kv-admin" {
  for_each = local.vaults_with_defaults

  scope              = azurerm_key_vault.kv[each.key].id
  role_definition_id = data.azurerm_role_definition.kv-admin-role.id
  principal_id       = data.azurerm_client_config.current.object_id

  lifecycle {
    ignore_changes = [
      # Somehow the reole definition id gets forced to recreate which introduces a bug when creating new keys.
      # ignore it for now
      role_definition_id
    ]
  }
}

resource "azurerm_role_assignment" "kv-des-crypto-encryp" {
  count                = contains(["3", "4"], var.sbk) ? 1 : 0
  scope                = azurerm_key_vault.kv["encryp"].id
  role_definition_name = "Key Vault Crypto Service Encryption User"
  principal_id         = data.azurerm_client_config.current.object_id
}

resource "azurerm_private_endpoint" "pls" {
  for_each = local.vaults_with_defaults

  name                = "${local.name_prefix}-pep-${local.prefix_app_name}-${each.key}"
  location            = azurerm_resource_group.rg-kv.location
  resource_group_name = azurerm_resource_group.rg-kv.name
  subnet_id           = var.subnet_id

  private_service_connection {
    name                           = "pep-sc-${each.key}"
    private_connection_resource_id = azurerm_key_vault.kv[each.key].id
    subresource_names              = ["vault"]
    is_manual_connection           = false
  }
  private_dns_zone_group {
    name                 = "vault"
    private_dns_zone_ids = var.is_old_tenant ? ["${local.private_dns_zone_ids[var.infra_environment]}privatelink.vaultcore.azure.net"] : ["${local.private_dns_zone_id_new_tenant[var.infra_environment]}privatelink.vaultcore.azure.net"]
  }

  tags = var.tags

  lifecycle {
    ignore_changes = [
      tags["CreationDateTime"],
      tags["Owner"],
      tags["Environment"],
      tags["ITAB"],
      tags["AppName"],
      tags["AppEnv"],
      tags["SubscriptionType"],
      tags["PlatformId"],
      tags["Availability"],
      tags["Confidentiality"],
      tags["Integrity"]
    ]
  }
}

# The role assignment needs time to become active.
resource "time_sleep" "wait_60_seconds" {
  depends_on = [azurerm_role_assignment.kv-admin]

  create_duration = "60s"
}

# The pls needs time to become active.
resource "time_sleep" "wait_for_pls" {
  depends_on = [azurerm_private_endpoint.pls]

  create_duration = "120s"
}

resource "azurerm_key_vault_key" "services-encryption-keys" {
  for_each = local.services_to_encrypt

  name         = "kvk-${local.prefix_app_name}-${each.key}"
  key_vault_id = azurerm_key_vault.kv["encryp"].id
  key_type     = "RSA-HSM"
  key_size     = each.value.key_size

  key_opts = [
    "decrypt",
    "encrypt",
    "sign",
    "unwrapKey",
    "verify",
    "wrapKey",
  ]

  rotation_policy {
    automatic {
      # Rotate key automatically 30 days before it expires
      time_before_expiry = "P30D"
    }
    # Key expires after 365 days after creation
    expire_after = "P365D"
    # Notification 30 days before expiry
    notify_before_expiry = "P30D"
  }

  tags = var.tags

  lifecycle {
    ignore_changes = [
      tags["CreationDateTime"],
      tags["Owner"],
      tags["Environment"],
      tags["ITAB"],
      tags["AppName"],
      tags["AppEnv"],
      tags["SubscriptionType"],
      tags["PlatformId"],
      tags["Availability"],
      tags["Confidentiality"],
      tags["Integrity"]
    ]
  }

  depends_on = [time_sleep.wait_for_pls, time_sleep.wait_60_seconds, azurerm_key_vault.kv, azurerm_private_endpoint.pls, azurerm_role_assignment.kv-admin]
}