variable "is_old_tenant" {
  description = "Flag to check if provided LZ is deployed in the old tenant or not"
  type        = bool
}

variable "app_environment" {
  description = "This variable defines the app environment of the specific application. Placeholder is 'x' if nothing is set."
  type        = string
}

variable "app_name" {
  description = "Name of the application per subscription"
  type        = string
}

variable "app_type" {
  description = "Type of app (shared, spoke...)"
  type        = string
}

variable "lbbw_location" {
  description = "LBBW Location"
  type        = string
}

variable "location" {
  description = "Azure location"
  type        = string
}

variable "infra_environment" {
  description = "This variable defines the environment to be built. (Prod,Cert,Dev,Engineering)."
  type        = string
}

variable "sbk" {
  description = "This variable defines the 'Schutzbedarfsklasse' (1, 2, 3, 4)"
  type        = string
}

variable "vaults" {
  description = "Key vaults"
  type = map(object({
    enabled_for_disk_encryption   = bool
    enabled_for_deployment        = bool
    soft_delete_retention_days    = number
    purge_protection_enabled      = bool
    enable_rbac_authorization     = bool
    public_network_access_enabled = bool
    sku_name                      = string
  }))
}

variable "subnet_id" {
  description = "Subnet ID for private endpoints"
  type        = string
}

variable "ntw_rg_name" {
  description = "The name of the ntw resource group."
  type        = string
}

variable "ntw_vnet_id" {
  description = "The id of the ntw vnet."
  type        = string
}

variable "tags" {
  description = "Map of Tags per subscription"
  type        = map(string)
}