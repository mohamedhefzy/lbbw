#azr client config
data "azurerm_client_config" "current" {
  # Returns the values of the currently logged in user
  # client_id         - is set to the Azure Client ID (Application Object ID).
  # tenant_id         - is set to the Azure Tenant ID.
  # subscription_id   - is set to the Azure Subscription ID.
  # object_id         - is set to the Azure Object ID.
}

data "azurerm_subscription" "current" {
}
#resource group for rsv
resource "azurerm_resource_group" "rg-rsv" {
  name     = "${local.name_prefix}-rg-${local.prefix_app_name}-rsv"
  location = var.location

  tags = var.tags

  lifecycle {
    ignore_changes = [
      tags["CreationDateTime"],
      tags["Owner"],
      tags["Environment"],
      tags["ITAB"],
      tags["AppName"],
      tags["AppEnv"],
      tags["SubscriptionType"],
      tags["PlatformId"],
      tags["Availability"],
      tags["Confidentiality"],
      tags["Integrity"]
    ]
  }
}

resource "azurerm_recovery_services_vault" "vault" {
  name                = "${local.name_prefix}-rsv-${local.prefix_app_name}"
  location            = azurerm_resource_group.rg-rsv.location
  resource_group_name = azurerm_resource_group.rg-rsv.name
  sku                 = "Standard"

  soft_delete_enabled = var.rsvault.soft_delete_enabled
  storage_mode_type   = var.rsvault.storage_mode_type
  # cross_region_restore_enabled  = var.rsvault.storage_mode_type == "GeoRedundant" ? true : false
  public_network_access_enabled = false

  monitoring {
    alerts_for_all_job_failures_enabled = var.rsvault.alerts_for_all_job_failures_enabled
  }

  identity {
    type = "SystemAssigned"
  }

  dynamic "encryption" {
    for_each = contains(["3", "4"], var.sbk) ? [1] : []
    content {
      key_id                            = var.keyvault_encryption_key_id
      use_system_assigned_identity      = true
      infrastructure_encryption_enabled = false
    }
  }

  tags = var.tags

  lifecycle {
    ignore_changes = [
      tags["CreationDateTime"],
      tags["Owner"],
      tags["Environment"],
      tags["ITAB"],
      tags["AppName"],
      tags["AppEnv"],
      tags["SubscriptionType"],
      tags["PlatformId"],
      tags["Availability"],
      tags["Confidentiality"],
      tags["Integrity"]
    ]
  }
}

data "azurerm_role_definition" "kv-crypto-officer-role" {
  role_definition_id = "14b46e9e-c2b7-41b4-b07b-48a6ebf60603" # Key Vault Administrator
}

#Assign role for Key Vault Crypto Officer (Requrired for CMK Acccess)
resource "azurerm_role_assignment" "kv-crypto-officer" {
  scope              = var.keyvault_encryp_rg_id
  role_definition_id = data.azurerm_role_definition.kv-crypto-officer-role.id
  principal_id       = azurerm_recovery_services_vault.vault.identity[0].principal_id

  lifecycle {
    ignore_changes = [
      # Somehow the reole definition id gets forced to recreate which introduces a bug when creating new keys.
      # ignore it for now
      role_definition_id
    ]
  }
}

resource "azurerm_backup_policy_vm" "policy-vm" {
  name                = "bkpol-rsv-vm"
  resource_group_name = azurerm_resource_group.rg-rsv.name
  recovery_vault_name = azurerm_recovery_services_vault.vault.name
  policy_type         = "V2"
  timezone            = "W. Europe Standard Time"

  backup {
    frequency = "Daily"
    time      = local.backup_options[var.patchwindow][var.infra_environment].time
  }

  retention_daily {
    count = 30
  }

  dynamic "retention_weekly" {
    for_each = var.backupretention != "SHORT" ? [1] : [] // For MID and LONG
    content {
      count    = 52
      weekdays = local.backup_options[var.patchwindow][var.infra_environment].weekdays
    }
  }

  dynamic "retention_monthly" {
    for_each = var.backupretention == "LONG" ? [1] : []
    content {
      count    = 120
      weeks    = ["First"]
      weekdays = local.backup_options[var.patchwindow][var.infra_environment].weekdays
    }
  }
}

resource "azurerm_backup_policy_file_share" "policy-file-share" {
  name                = "bkpol-rsv-share"
  resource_group_name = azurerm_resource_group.rg-rsv.name
  recovery_vault_name = azurerm_recovery_services_vault.vault.name
  timezone            = "W. Europe Standard Time"

  backup {
    frequency = "Daily"
    time      = local.backup_options[var.patchwindow][var.infra_environment].time
  }

  retention_daily {
    count = 30
  }

  dynamic "retention_weekly" {
    for_each = var.backupretention != "SHORT" ? [1] : [] // For MID and LONG
    content {
      count    = 52
      weekdays = local.backup_options[var.patchwindow][var.infra_environment].weekdays
    }
  }

  dynamic "retention_monthly" {
    for_each = var.backupretention == "LONG" ? [1] : []
    content {
      count    = 120
      weeks    = ["First"]
      weekdays = local.backup_options[var.patchwindow][var.infra_environment].weekdays
    }
  }
}

resource "azurerm_private_endpoint" "pls" {
  name                = "${local.name_prefix}-pep-${local.prefix_app_name}-rsv"
  location            = azurerm_resource_group.rg-rsv.location
  resource_group_name = azurerm_resource_group.rg-rsv.name
  subnet_id           = var.subnet_id

  private_service_connection {
    name                           = "pep-sc-rsv"
    private_connection_resource_id = azurerm_recovery_services_vault.vault.id
    subresource_names              = ["AzureBackup"]
    is_manual_connection           = false
  }

  // Zentrale Azure Privater DNS Zone in Hub muss hier referenziert werden.
  private_dns_zone_group {
    name                 = "rsvault"
    private_dns_zone_ids = var.is_old_tenant ? ["${local.private_dns_zone_ids[var.infra_environment]}privatelink.we.backup.windowsazure.com"] : ["${local.private_dns_zone_id_new_tenant[var.infra_environment]}privatelink.we.backup.windowsazure.com"]
  }

  tags = var.tags

  lifecycle {
    ignore_changes = [
      tags["CreationDateTime"],
      tags["Owner"],
      tags["Environment"],
      tags["ITAB"],
      tags["AppName"],
      tags["AppEnv"],
      tags["SubscriptionType"],
      tags["PlatformId"],
      tags["Availability"],
      tags["Confidentiality"],
      tags["Integrity"]
    ]
  }
}