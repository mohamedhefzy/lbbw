output "rsvault_id" {
  value = azurerm_recovery_services_vault.vault.id
}

output "name" {
  value = azurerm_recovery_services_vault.vault.name
}

output "rg_name" {
  value = azurerm_resource_group.rg-rsv.name
}

output "share_policy_id" {
  value = azurerm_backup_policy_file_share.policy-file-share.id
}

output "vm_policy_id" {
  value = azurerm_backup_policy_vm.policy-vm.id
}

output "private_endpoint_name" {
  value = azurerm_private_endpoint.pls.name
}

output "policy_file_share_name" {
  value = azurerm_backup_policy_file_share.policy-file-share.name
}