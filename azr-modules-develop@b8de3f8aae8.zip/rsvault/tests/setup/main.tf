provider "azurerm" {
  features {}
  subscription_id = "541ac1c2-8b44-4aac-abdf-3ce58dd8f753"
}

module "rsvault" {

  source = "../../"

  is_old_tenant     = var.is_old_tenant
  app_name          = var.app_name
  app_type          = var.app_type
  app_environment   = var.app_environment
  infra_environment = var.infra_environment
  lbbw_location     = var.lbbw_location
  location          = var.location

  backupretention = var.backupretention
  patchwindow     = var.patchwindow

  sbk = var.sbk

  tags = {
    source         = "terraform"
    environment    = "development"
    "ITAB"         = "7656"
    "AppName"      = "test"
    "Owner"        = "test"
    "Creator"      = "iac-admin"
    "ServerRole"   = "container-platform"
    "CreationDate" = "auto-generated"
  }

  # module specific variables
  subnet_id                  = "/subscriptions/541ac1c2-8b44-4aac-abdf-3ce58dd8f753/resourceGroups/euho-e-rg-xtest-ntw/providers/Microsoft.Network/virtualNetworks/euho-e-vnet-xtest/subnets/snet-xtest-subnet1"
  keyvault_encryp_rg_id      = "/subscriptions/541ac1c2-8b44-4aac-abdf-3ce58dd8f753/resourceGroups/euho-e-rg-xtest-kv"
  keyvault_encryption_key_id = "https://euho-e-kv-xtest-encryp.vault.azure.net/keys/kvk-xtest-rsvault/4f6f9a1ad9264dc6a1baa724f3461de3"
  rsvault = {
    storage_mode_type                   = "GeoRedundant"
    alerts_for_all_job_failures_enabled = true
    soft_delete_enabled                 = true
  }

}