run "execute" {
  module {
    source = "./setup"
  }

  command = plan

  assert {
    condition     = module.rsvault.name == "euho-e-rsv-xtest"
    error_message = "The name of the recovery service vault does not match."
  }

  assert {
    condition     = module.rsvault.rg_name == "euho-e-rg-xtest-rsv"
    error_message = "he name of the resource group does not match."
  }

  assert {
    condition     = module.rsvault.private_endpoint_name == "euho-e-pep-xtest-rsv"
    error_message = "The name of the private endpoint does not match."
  }

  assert {
    condition     = module.rsvault.policy_file_share_name == "bkpol-share-SHORT"
    error_message = "The name of the policy filre share does not match."
  }

}