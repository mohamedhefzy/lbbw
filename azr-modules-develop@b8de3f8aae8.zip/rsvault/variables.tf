variable "is_old_tenant" {
  description = "Is old tenant used"
  type        = bool
}

variable "app_environment" {
  description = "This variable defines the app environment of the specific application. Placeholder is 'x' if nothing is set."
  type        = string
}

variable "app_name" {
  description = "Name of the application per subscription"
  type        = string
}

variable "app_type" {
  description = "Type of app (shared, spoke...)"
  type        = string
}

variable "lbbw_location" {
  description = "LBBW Location"
  type        = string
}

variable "location" {
  description = "Azure location"
  type        = string
}

variable "infra_environment" {
  description = "This variable defines the environment to be built. (Prod,Cert,Dev,Engineering)."
  type        = string
}

variable "sbk" {
  description = "This variable defines the 'Schutzbedarfsklasse' (1, 2, 3, 4)"
  type        = string
}

variable "tags" {
  description = "Map of Tags per subscription"
  type        = map(string)
}

variable "patchwindow" {
  description = "This variable defines the patchwindow (Option1, Option2, Option3)"
  type        = string
}

variable "backupretention" {
  description = "This variable defines the backupretention (SHORT, MID, LONG)"
  type        = string
}

variable "subnet_id" {
  description = "The id of the subnet where the rsvault should be placed"
  type        = string
}

variable "keyvault_encryp_rg_id" {
  description = "The resource id of the keyvault's resource group"
  type        = string
}

variable "keyvault_encryption_key_id" {
  description = "The id of the keyvault key that is used for encyption"
  type        = string
}

variable "rsvault" {
  description = "Recovery service vault"
  type = object({
    storage_mode_type                   = string
    alerts_for_all_job_failures_enabled = bool
    soft_delete_enabled                 = bool
  })
}
