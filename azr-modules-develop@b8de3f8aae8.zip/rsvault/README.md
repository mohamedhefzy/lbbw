# Recovery Service Vault

This module is used to deploy a Recovery Service Vault.

## Created Resources

This module creates the following resources on azure


- ``azurerm_resource_group.rg-rsv``: A resource group where the following resources are loacted.
- ``azurerm_recovery_services_vault.vault``: The recovery service vault.
- ``azurerm_role_assignment.kv-crypto-officer``: Role assignment for key vault crypto officer. This role is needed fpr sbk 3 and 4.
- ``azurerm_backup_policy_file_share.policy-file-share``: The backup policy or file shares.
- ``azurerm_private_endpoint.pls``: The private endpoint of the recovery service vault.


## Variables

| Name               | Description                                                               | Type   |
| ------------------ | --------------------------------------------------------------------------| -------|
| app_environment | This variable defines the app environment of the specific application. Placeholder is 'x' if nothing is set. | string |
| app_name | Name of the application per subscription. | string |
| app_type | Type of app (shared, spoke...) | string |
| lbbw_location | LBBW Location | string |
| location | Azure location | string |
| infra_environment | This variable defines the environment to be built. (Prod,Cert,Dev,Engineering). | string |
| sbk | This variable defines the 'Schutzbedarfsklasse' (1, 2, 3, 4) | string |
| tags | Map of Tags per subscription | map(string) |
| patchwindow | This variable defines the patchwindow (Option1, Option2, Option3) | string |
| backupretention | This variable defines the backupretention (SHORT, MID, LONG) | string |
| subnet_id | The id of the subnet where the rsvault should be placed | string |
| keyvault_encryp_rg_id | The resource id of the keyvault's resource group. | string |
| keyvault_encryption_key_id | The id of the keyvault key that is used for encyption. | string |
| rsvault | Recovery service vault. | object |


### RSVault Model

Model Deployments are described in a list of objects of the following structure:

```
rsvault = {
    storage_mode_type                   = string
    alerts_for_all_job_failures_enabled = bool
    soft_delete_enabled                 = bool
}

```

## Output

| Name                 | Description                                                                                                       |
| -------------------- | ----------------------------------------------------------------------------------------------------------------- |
| rsvault_id | The id of the rs vault. |
| name | The name of the rs vault. |
| rg_name | The name of the resource group. |
| share_policy_id | The id of the backup policy share. |
| private_endpoint_name | The names of the private endpoint. (Tests) |
| policy_file_share_name | The name sof the file share policy. (Tests) |


## Required Modules
- ntwspoke
- keyvault