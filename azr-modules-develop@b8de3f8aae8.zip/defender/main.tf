data "azurerm_client_config" "current" {
  # Returns the values of the currently logged in user
  # client_id         - is set to the Azure Client ID (Application Object ID).
  # tenant_id         - is set to the Azure Tenant ID.
  # subscription_id   - is set to the Azure Subscription ID.
  # object_id         - is set to the Azure Object ID.
}

resource "null_resource" "defender-server-workaround" {
  triggers = {
    always_run = timestamp()
  }

  provisioner "local-exec" {
    command = "az security pricing create --name VirtualMachines --tier Free"
  }
}

resource "azurerm_security_center_subscription_pricing" "defender_server" {
  tier          = "Standard"
  resource_type = "VirtualMachines"
  subplan       = "P2"

  extension {
    name = "MdeDesignatedSubscription"
  }

  extension {
    name = "AgentlessVmScanning"
    additional_extension_properties = {
      ExclusionTags = "[]"
    }
  }

  timeouts {
    create = "20m"
    update = "15m"
    delete = "15m"
  }

  depends_on = [null_resource.defender-server-workaround]
}

resource "azurerm_security_center_subscription_pricing" "defender_container" {
  tier          = "Standard"
  resource_type = "Containers"

  extension {
    name = "ContainerSensor"
  }

  extension {
    name = "AgentlessDiscoveryForKubernetes"
  }

  extension {
    name = "ContainerRegistriesVulnerabilityAssessments"
  }

  extension {
    name = "AgentlessVmScanning"
    additional_extension_properties = {
      ExclusionTags = "[]"
    }
  }

}

resource "azurerm_security_center_subscription_pricing" "defender_storage" {
  tier          = "Standard"
  resource_type = "StorageAccounts"
  subplan       = "DefenderForStorageV2"

  extension {
    name = "OnUploadMalwareScanning"
  }

  extension {
    name = "SensitiveDataDiscovery"
  }
}

resource "azurerm_security_center_subscription_pricing" "defender_sql_server" {
  tier          = "Standard"
  resource_type = "SqlServers"
}

resource "azurerm_security_center_subscription_pricing" "defender_open_source_relational_db" {
  tier          = "Standard"
  resource_type = "OpenSourceRelationalDatabases"
}

resource "azurerm_security_center_subscription_pricing" "defender_key_vault" {
  tier          = "Standard"
  resource_type = "KeyVaults"
}
