
run "execute" {
  module {
    source = "./setup"
  }

  command = plan

  assert {
    condition     = length(module.defender.active_defender_sensor_ids) == 1
    error_message = "The count of active denfender sensors does not match."
  }

  assert {
    condition     = length(module.defender.deactive_defender_sensor_ids) == 1
    error_message = "Thee count of deactive defender sensor ids does not match."
  }

}
