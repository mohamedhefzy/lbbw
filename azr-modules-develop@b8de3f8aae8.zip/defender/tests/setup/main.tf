provider "azurerm" {
  features {}
  subscription_id = "541ac1c2-8b44-4aac-abdf-3ce58dd8f753"
}

module "defender" {

  source = "../../"

  is_old_tenant     = var.is_old_tenant
  app_name          = var.app_name
  app_environment   = var.app_environment
  lbbw_location     = var.lbbw_location
  infra_environment = var.infra_environment
  aks_clusters = {
    c1 = {
      rg_name      = "rg1"
      cluster_name = "cluster1"
    }
  }

}
