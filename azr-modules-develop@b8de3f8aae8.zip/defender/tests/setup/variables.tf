variable "is_old_tenant" {
  type    = bool
  default = true
}
variable "app_environment" {
  type    = string
  default = "x"
}
variable "app_name" {
  type    = string
  default = "test"
}
variable "infra_environment" {
  type    = string
  default = "e"
}
variable "lbbw_location" {
  type    = string
  default = "euho"
}
