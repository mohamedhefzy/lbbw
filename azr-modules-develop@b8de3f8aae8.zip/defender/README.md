# Azure Defender Subscription Module

This module enables and configures Azure Defender plans for multiple resource types under Azure Security Center to enhance security across various Azure services.

## Created Resources

This module creates the following resources in Azure:

- **`azurerm_security_center_subscription_pricing.defender_server`**:  
    Configures Azure Defender for Servers (Virtual Machines) at the `Standard` pricing tier. Includes the following extensions:  
    - `MdeDesignatedSubscription`
    - `AgentlessVmScanning`, with `ExclusionTags` set to `[]`.

- **`azurerm_security_center_subscription_pricing.defender_container`**:  
    Configures Azure Defender for Containers at the `Standard` pricing tier. Includes extensions for:  
    - `ContainerSensor`
    - `AgentlessDiscoveryForKubernetes`
    - `ContainerRegistriesVulnerabilityAssessments`
    - `AgentlessVmScanning`, with `ExclusionTags` set to `[]`.

- **`azurerm_security_center_subscription_pricing.defender_storage`**:  
    Configures Azure Defender for Storage Accounts at the `Standard` pricing tier. Subplan is set to `DefenderForStorageV2`. Includes extensions for:  
    - `OnUploadMalwareScanning`
    - `SensitiveDataDiscovery`.

- **`azurerm_security_center_subscription_pricing.defender_sql_server`**:  
    Configures Azure Defender for SQL Servers at the `Standard` pricing tier.

- **`azurerm_security_center_subscription_pricing.defender_open_source_relational_db`**:  
    Configures Azure Defender for Open Source Relational Databases at the `Standard` pricing tier.

- **`azurerm_security_center_subscription_pricing.defender_key_vault`**:  
    Configures Azure Defender for Key Vaults at the `Standard` pricing tier.

## Features

This module ensures comprehensive security for infrastructure and services in Azure by enabling Azure Defender for specific resource types. It makes use of optional extensions and additional configurations to enhance functionality (e.g., `AgentlessVmScanning` and `ExclusionTags`).

## Timeouts

For `azurerm_security_center_subscription_pricing.defender_server`, custom timeouts are specified:  
- `create`: `15m`  
- `update`: `15m`  
- `delete`: `15m`.

## Purpose

This module is useful for organizations looking to enforce consistent security standards across their Azure resources using Azure Defender and advanced configurations like agentless scanning and vulnerability assessments.


## Inputs

### Variables
|Name|Description  |
|--|--|

### Locals
|Name|Description  |
|--|--|