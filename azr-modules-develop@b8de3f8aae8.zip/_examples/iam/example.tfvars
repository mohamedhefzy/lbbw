iam_mids = {
  samid = {
    scope        = "/subscriptions/xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx",
    data_actions = ["Microsoft.Storage/storageAccounts/blobServices/containers/blobs/*"],
    actions      = ["Microsoft.Storage/storageAccounts/blobServices/containers/read"]
  },
  rgreadmid2 = {
    actions = ["Microsoft.Resources/subscriptions/resourceGroups/read"]
  }
}