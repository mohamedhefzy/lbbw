# Global variables
global_is_old_tenant     = false
global_lz_type           = "aks"
global_lbbw_location     = "eufho"
global_location          = "germanywestcentral"
global_app_environment   = "x"
global_infra_environment = "e"
global_app_name          = "modt"
global_app_type          = "spoke"
### Requiered global_var
# Please be aware that the CMK and "Encryption at host" feature depend on the SBK 
# if 1 or 2: Encryption at host is disable and PMK is used
# if 3 or 4: Encryption at host is enbabled and CMK is used
global_itab            = "8588"
global_sbk             = "1"
global_integrity       = "I1"
global_availability    = "V1"
global_confidentiality = "S1"
global_criticality     = "C2"
global_patchwindow     = "Option1"
global_backupretention = "SHORT"
global_is_iam_enabled  = true
global_tags            = {}

### vars for ntwspoke module
ntwspoke_vnet = {
  private_subnet_address_spaces = ["10.238.7.192/28"]
  address_space                 = ["10.238.7.192/27"]
  subnets = {
    default = {
      address_prefixes = ["10.238.7.208/28"]
    }
  }
}

ntwspoke_rules = {
  default_star = {
    direction_short_name       = "ib",
    access                     = "Allow",
    protocol                   = "*",
    source_port_range          = "*",
    destination_port_range     = "*",
    source_address_prefix      = "*",
    destination_address_prefix = "*",
    subnet_key_name            = "default"
  },
  pe_star = {
    direction_short_name       = "ib",
    access                     = "Allow",
    protocol                   = "*",
    source_port_range          = "*",
    destination_port_range     = "*",
    source_address_prefix      = "*",
    destination_address_prefix = "*",
    subnet_key_name            = "private_endpoint_subnet"
  }
}

### vars for eventhub
eventhub_eventhub_namespaces = {
  # results in euho-e-evhns-opto-namespace1 for eventhub namespace name 
  #   only letters, numbers and - are allowed in naming
  namespace1 = {
    sku      = "Standard" # Basic, Standard and Premium are possible values 
    capacity = 2          # defines possible throughout in diffuse azure metric (TU for Standard Tier)

    # subnets allowed to communicate with this eventhub namespace
    #   use your ntwspoke subnet keys in this list
    allowed_subnet_keys = ["subnet1"]

    # OPTIONAL IP Addresses to be whitelisted for the eventhub namespace
    # Can either be an IP Address (1.2.3.4) 
    # or an IP Mask (1.2.3.4/32)
    allowed_ip_addresses = ["1.2.3.4", "8.8.8.8/32"]

    eventhubs = {
      # results in euho-e-defender-raw-evh-opto for eventhub name
      #   across all namespace names each eventhub must have a distinguished name
      eventhub1 = {
        partition_count   = 1
        message_retention = 1 # number between 1 and 7, indicates retention time in days
      }
    }
  }
  # results in euho-e-evhns-opto-namespace2 for eventhub namespace name
  namespace2 = {
    sku      = "Standard"
    capacity = 1

    # subnets allowed to communicate with this eventhub namespace
    #   use your ntwspoke subnet keys in this list
    # allowed_subnet_keys = ["subnet1", "subnet3", "subnet3"]

    # OPTIONAL IP Addresses to be whitelisted for the eventhub namespace
    # Can either be an IP Address (1.2.3.4) 
    # or an IP Mask (1.2.3.4/32)
    # allowed_ip_addresses = ["1.2.3.4", "8.8.8.8/32"]

    eventhubs = {
      eventhub1 = {
        partition_count   = 1
        message_retention = 1
      }
      eventhub2 = {
        partition_count   = 1
        message_retention = 1
      }
    }
  }
}

eventhub_eventhub_azure_eh_data_receiver_role_assignments = {
  # the namespace name the role assignment for the role 'Azure Event Hubs Data Receiver' is supposed to be created upon
  # MUST have been created in this same step, otherwise the event hub namespace will NOT be found.
  namespace1 = {
    # the object IDs of the service principals to get the role assignment for the given namespace
    # MUST be a service principal
    service_principal_object_ids = ["00000000-0000-0000-0000-000000000000", "00000000-0000-0000-0000-000000000001"]
  }
  namespace2 = {
    service_principal_object_ids = ["00000000-0000-0000-0000-000000000000"]
  }
}

# Identical to eventhub_eventhub_azure_eh_data_receiver_role_assignments
eventhub_eventhub_azure_eh_data_sender_role_assignments = {
  namespace1 = {

    service_principal_object_ids = ["00000000-0000-0000-0000-000000000000", "00000000-0000-0000-0000-000000000001"]
  }
  namespace2 = {
    service_principal_object_ids = ["00000000-0000-0000-0000-000000000000"]
  }
}