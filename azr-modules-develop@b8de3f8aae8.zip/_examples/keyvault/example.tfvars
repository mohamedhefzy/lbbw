# Global variables
global_is_old_tenant     = false
global_lz_type           = "aks"
global_lbbw_location     = "eufho"
global_location          = "germanywestcentral"
global_app_environment   = "x"
global_infra_environment = "e"
global_app_name          = "modt"
global_app_type          = "spoke"
### Requiered global_var
# Please be aware that the CMK and "Encryption at host" feature depend on the SBK 
# if 1 or 2: Encryption at host is disable and PMK is used
# if 3 or 4: Encryption at host is enbabled and CMK is used
global_itab            = "8588"
global_sbk             = "1"
global_integrity       = "I1"
global_availability    = "V1"
global_confidentiality = "S1"
global_criticality     = "C2"
global_patchwindow     = "Option1"
global_backupretention = "SHORT"
global_is_iam_enabled  = true
global_tags            = {}

### vars for ntwspoke module
ntwspoke_vnet = {
  private_subnet_address_spaces = ["10.238.7.192/28"]
  address_space                 = ["10.238.7.192/27"]
  subnets = {
    default = {
      address_prefixes = ["10.238.7.208/28"]
    }
  }
}

ntwspoke_rules = {
  default_star = {
    direction_short_name       = "ib",
    access                     = "Allow",
    protocol                   = "*",
    source_port_range          = "*",
    destination_port_range     = "*",
    source_address_prefix      = "*",
    destination_address_prefix = "*",
    subnet_key_name            = "default"
  },
  pe_star = {
    direction_short_name       = "ib",
    access                     = "Allow",
    protocol                   = "*",
    source_port_range          = "*",
    destination_port_range     = "*",
    source_address_prefix      = "*",
    destination_address_prefix = "*",
    subnet_key_name            = "private_endpoint_subnet"
  }
}

### vars for keyvault module
keyvault_vaults = {
  "default" = {
    purge_protection_enabled      = false,
    enable_rbac_authorization     = true,
    public_network_access_enabled = true,
    soft_delete_retention_days    = 89,
  },
  "vault1" = {
    purge_protection_enabled      = false,
    enable_rbac_authorization     = true,
    public_network_access_enabled = false,
    soft_delete_retention_days    = 89,
  }
}