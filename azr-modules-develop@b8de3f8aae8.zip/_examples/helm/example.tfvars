# Global variables
global_is_old_tenant     = false
global_lz_type           = "aks"
global_lbbw_location     = "eufho"
global_location          = "germanywestcentral"
global_app_environment   = "x"
global_infra_environment = "e"
global_app_name          = "modt"
global_app_type          = "spoke"
### Requiered global_var
# Please be aware that the CMK and "Encryption at host" feature depend on the SBK 
# if 1 or 2: Encryption at host is disable and PMK is used
# if 3 or 4: Encryption at host is enbabled and CMK is used
global_itab            = "8588"
global_sbk             = "1"
global_integrity       = "I1"
global_availability    = "V1"
global_confidentiality = "S1"
global_criticality     = "C2"
global_patchwindow     = "Option1"
global_backupretention = "SHORT"
global_is_iam_enabled  = true
global_tags            = {}

### vars for ntwspoke module
ntwspoke_vnet = {
  private_subnet_address_spaces = ["10.238.7.192/28"]
  address_space                 = ["10.238.7.192/27"]
  subnets = {
    default = {
      address_prefixes = ["10.238.7.208/28"]
    }
  }
}

ntwspoke_rules = {
  default_star = {
    direction_short_name       = "ib",
    access                     = "Allow",
    protocol                   = "*",
    source_port_range          = "*",
    destination_port_range     = "*",
    source_address_prefix      = "*",
    destination_address_prefix = "*",
    subnet_key_name            = "default"
  },
  pe_star = {
    direction_short_name       = "ib",
    access                     = "Allow",
    protocol                   = "*",
    source_port_range          = "*",
    destination_port_range     = "*",
    source_address_prefix      = "*",
    destination_address_prefix = "*",
    subnet_key_name            = "private_endpoint_subnet"
  }
}

### vars for keyvault module
keyvault_vaults = {}

rsvault_rsvault = {
  soft_delete_enabled = false
}

### vars for bvault
bvault_bvault = {
  soft_delete = "Off"
  protection_backup_policy_disk = {
    rule1 = {
      retention_rules = {
        retention_rule1 = {
          criteria = {}
        }
      }
    }
  }

  protection_backup_policy_kubernetes_cluster = {
    policy1 = {
      retention_rules = {
        retention_rule1 = {
          life_cycle = {}
          criteria   = {}
        }
      }
      default_retention_rule = {
        life_cycle = {}
      }
    }
  }

  protection_backup_policy_postgresql = {
    rule1 = {
      retention_rules = {}
    }
  }

  protection_backup_policy_blob_storage = {
    retention_duration = "P30D"
  }
}

### vars for storageaccount module
storageaccount_storage_accounts = {
  "sa1" = {
    account_tier              = "Standard"
    account_replication_type  = "ZRS"
    shared_access_key_enabled = false
    dynamic_storage           = false
    is_hns_enabled            = false
    nfsv3_enabled             = true
    blob_properties = {
      delete_retention_policy = {
        days = 22
      }
      container_delete_retention_policy = {
        days = 22
      }
      restore_policy = {
        days = 21
      }
    }
  }
  "sa2" = {
    account_tier             = "Standard"
    account_replication_type = "ZRS"

    storage_containers = {
      "container1" = {}
      "container2" = {}
    }
    shares = {
      "share1" = {}
      "share2" = {}
      "share3" = {}
    }

    blob_properties = {
      delete_retention_policy = {
        days = 22
      }
      container_delete_retention_policy = {
        days = 22
      }
      restore_policy = {
        days = 21
      }
    }
  }
  "sa3" = {
    account_tier             = "Standard"
    account_replication_type = "ZRS"

    shares = {
      "share4" = {}
    }

    blob_properties = {
      delete_retention_policy = {
        days = 22
      }
      container_delete_retention_policy = {
        days = 22
      }
      restore_policy = {
        days = 21
      }
    }
  }
}

### vars for aks module
aks = {
  cluster = {
    kubernetes_version                  = "1.32.7"
    private_cluster_enabled             = true
    private_cluster_public_fqdn_enabled = false
    workload_identity_enabled           = true
    oidc_issuer_enabled                 = true
    vnet_subnet_key                     = "default"
    dynamic_storage                     = false
    default_node_pool = {
      node_count              = "3"
      auto_scaling_enabled    = true
      min_count               = "1"
      max_count               = "3"
      os_sku                  = "AzureLinux"
      vm_size                 = "Standard_D4s_v5"
      kubelet_disk_type       = "OS"
      os_disk_type            = "Managed"
      os_disk_size_gb         = 128
      type                    = "VirtualMachineScaleSets"
      host_encryption_enabled = true
      node_labels             = { "poolnode" = "test" }
      zones                   = ["3"]
    }
    app_node_pool = {
      n1 = {
        node_count           = "1"
        auto_scaling_enabled = false
        vm_size              = "Standard_D4s_v5"
        os_disk_size_gb      = "64"
        node_labels          = { "poolnode" = "test" }
        node_taints          = ["worker:PreferNoSchedule"]
      }
    }
    identity = {
      type = "UserAssigned"
    }
    azure_active_directory_role_based_access_control = {
      azure_rbac_enabled = true
    }
    file_shares = {
      share1 = {
        storage_account_key = "sa1"
        share_key           = "share1"
        secret_name         = "secret-1"
      }
    }
    blobs = {
      blob1 = {
        storage_account_key = "sta1"
        container_key       = "xarvp-container-0"
      }
    }
    managed_disks = {
      disk1 = {
        disk_size = "32"
        shared    = true
      }
    }
    network_profile = {
      network_plugin      = "azure"
      network_data_plane  = "cilium"
      network_plugin_mode = "overlay"
      dns_service_ip      = "10.1.0.10"
      service_cidr        = "10.1.0.0/21"
      outbound_type       = "userDefinedRouting"
    }
    storage_profile = {
      blob_driver_enabled = true
      disk_driver_enabled = true
      file_driver_enabled = true
    }
  }
}


### vars for kubernetes module
kubernetes = {
  namespaces = { projectns = "projectns", xapp = "xapp" }
}

### vars for helm module
helm = {
  vnet_subnet_key = "default"
  helm_release_configs = {
    pmakskured           = {}
    pmaksingressnginx    = {}
    pmaksexternalsecrets = {}
    pmaksexternaldns     = {}
  }
}
