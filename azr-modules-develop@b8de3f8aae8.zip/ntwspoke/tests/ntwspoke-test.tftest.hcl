run "execute" {
  module {
    source = "./setup"
  }
  command = plan

  assert {
    condition     = module.ntwspoke.rg_name == "euho-e-rg-xtest-ntw"
    error_message = "The rg name does not match."
  }

  assert {
    condition     = length(module.ntwspoke.snet_ids) == 2
    error_message = "The length of the snets does not match"
  }

  assert {
    condition     = length(module.ntwspoke.custom_nsgsr_ids) == 2
    error_message = "The custom nsgsr length should be 2"
  }

  assert {
    condition     = length(module.ntwspoke.default_nsgr_ids) == 4
    error_message = "The default nsgsr length should be 4"
  }
}