provider "azurerm" {
  features {}
  subscription_id = "541ac1c2-8b44-4aac-abdf-3ce58dd8f753"
}

module "ntwspoke" {
  source = "../../"

  rules = {
    default_star = {
      direction_short_name       = "ib",
      access                     = "Allow",
      protocol                   = "*",
      source_port_range          = "*",
      destination_port_range     = "*",
      source_address_prefix      = "*",
      destination_address_prefix = "*",
      subnet_key_name            = "subnet1"
      priority                   = 100
    },
    pe_star = {
      direction_short_name       = "ib",
      access                     = "Allow",
      protocol                   = "*",
      source_port_range          = "*",
      destination_port_range     = "*",
      source_address_prefix      = "*",
      destination_address_prefix = "*",
      subnet_key_name            = "private_endpoint_subnet"
      priority                   = 100
    }
  }
  app_type = var.app_type

  lbbw_location     = var.lbbw_location
  location          = var.location
  app_environment   = var.app_environment
  infra_environment = var.infra_environment
  app_name          = var.app_name
  sbk               = var.sbk

  tags = {
    source         = "terraform"
    environment    = "development"
    "ITAB"         = "7656"
    "AppName"      = "test"
    "Owner"        = "test"
    "Creator"      = "iac-admin"
    "ServerRole"   = "container-platform"
    "CreationDate" = "auto-generated"
  }

  vnet = {
    private_subnet_address_spaces = ["10.0.1.0/24"]
    address_space                 = ["10.0.0.0/16"]
    dns_servers                   = []
    encryption_enforcement        = "AllowUnencrypted"
    subnets = {
      subnet1 = {
        private_endpoint_network_policies = "Disabled"
        address_prefixes                  = ["10.0.2.0/24"]
        delegation = {
          name    = ""
          actions = []
        }
      }
    }
  }
}

