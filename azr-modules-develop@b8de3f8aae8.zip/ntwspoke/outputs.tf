output "rg_id" {
  value = azurerm_resource_group.rg-ntw.id
}

output "vnet_id" {
  value = azurerm_virtual_network.vnet.id
}

output "snet_ids" {
  value = { for k, v in azurerm_subnet.subnets : k => v.id }
}

output "rg_name" {
  value = azurerm_resource_group.rg-ntw.name
}

output "custom_nsgsr_ids" {
  value = { for k, v in azurerm_network_security_rule.custom-nsgsr : k => v.id }
}

output "default_nsgr_ids" {
  value = { for k, v in azurerm_network_security_rule.default-nsgsr : k => v.id }
}
