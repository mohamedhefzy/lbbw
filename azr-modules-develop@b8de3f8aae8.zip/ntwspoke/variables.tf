variable "is_old_tenant" {
  description = "Flag to check if provided LZ is deployed in the old tenant or not"
  type        = bool
}

variable "app_environment" {
  description = "This variable defines the app environment of the specific application. Placeholder is 'x' if nothing is set."
  type        = string
}

variable "app_name" {
  description = "Name of the application per subscription"
  type        = string
}

variable "app_type" {
  description = "Type of app (shared, spoke...)"
  type        = string
}

variable "lbbw_location" {
  description = "LBBW Location"
  type        = string
}

variable "location" {
  description = "Azure location"
  type        = string
}

variable "infra_environment" {
  description = "This variable defines the environment to be built. (Prod,Cert,Dev,Engineering)."
  type        = string
}

variable "sbk" {
  description = "This variable defines the 'Schutzbedarfsklasse' (1, 2, 3, 4)"
  type        = string
}

variable "rules" {
  description = "NSG Rules for Subnets"
  type = map(object({
    direction_short_name       = string
    access                     = string
    protocol                   = string
    priority                   = number
    source_port_range          = string
    destination_port_range     = string
    source_address_prefix      = string
    destination_address_prefix = string
    subnet_key_name            = string
  }))
}

variable "vnet" {
  description = "Vnet to be created"
  type = object({
    private_subnet_address_spaces = list(string)
    address_space                 = list(string)
    dns_servers                   = list(string)
    encryption_enforcement        = string
    subnets = map(object({
      private_endpoint_network_policies = string
      address_prefixes                  = list(string)
      delegation = optional(object({
        name    = string
        actions = list(string)
        }),
        {
          name    = ""
          actions = []
      })
      #      routes = map(object({
      #        address_prefix         = string
      #        next_hop_type          = string
      #        next_hop_in_ip_address = string
      #      }))
    }))
  })
}

variable "tags" {
  description = "Map of Tags per subscription"
  type        = map(string)
}
