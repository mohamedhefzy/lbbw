resource "azurerm_resource_group" "rg-ntw" {
  name     = "${local.name_prefix}-rg-${local.prefix_app_name}-ntw"
  location = var.location

  tags = var.tags

  lifecycle {
    ignore_changes = [
      tags["CreationDateTime"],
      tags["Owner"],
      tags["Environment"],
      tags["ITAB"],
      tags["AppName"],
      tags["AppEnv"],
      tags["SubscriptionType"],
      tags["PlatformId"],
      tags["Availability"],
      tags["Confidentiality"],
      tags["Integrity"]
    ]
  }
}

resource "azurerm_network_security_group" "nsg" {
  for_each = local.subnets_with_default

  name                = "${local.name_prefix}-nsg-${local.prefix_app_name}-${each.key}"
  location            = azurerm_resource_group.rg-ntw.location
  resource_group_name = azurerm_resource_group.rg-ntw.name

  tags = var.tags

  lifecycle {
    ignore_changes = [
      tags["CreationDateTime"],
      tags["Owner"],
      tags["Environment"],
      tags["ITAB"],
      tags["AppName"],
      tags["AppEnv"],
      tags["SubscriptionType"],
      tags["PlatformId"],
      tags["Availability"],
      tags["Confidentiality"],
      tags["Integrity"]
    ]
  }
}

resource "azurerm_network_security_rule" "custom-nsgsr" {
  for_each = var.rules

  name                        = "nsgsr-${each.key}-${each.value.subnet_key_name}"
  priority                    = each.value.priority
  direction                   = each.value.direction_short_name == "ob" ? "Outbound" : "Inbound"
  access                      = each.value.access
  protocol                    = each.value.protocol
  source_port_range           = each.value.source_port_range
  destination_port_range      = each.value.destination_port_range
  source_address_prefix       = each.value.source_address_prefix
  destination_address_prefix  = each.value.destination_address_prefix
  resource_group_name         = azurerm_resource_group.rg-ntw.name
  network_security_group_name = azurerm_network_security_group.nsg[each.value.subnet_key_name].name
}

resource "azurerm_network_security_rule" "default-nsgsr" {
  for_each = {
    for combination in flatten([
      for subnet_key, subnet in local.subnets_with_default : [
        for rule_key, rule in local.default_rules : {
          key        = "${rule_key}-${subnet_key}"
          subnet_key = subnet_key
          rule       = rule
        }
      ]
    ]) :
    combination.key => combination
  }

  name                        = each.value.rule.name
  priority                    = each.value.rule.priority
  direction                   = each.value.rule.direction_short_name == "ob" ? "Outbound" : "Inbound"
  access                      = each.value.rule.access
  protocol                    = each.value.rule.protocol
  source_port_range           = each.value.rule.source_port_range
  destination_port_range      = each.value.rule.destination_port_range
  source_address_prefix       = each.value.rule.source_address_prefix
  destination_address_prefix  = each.value.rule.destination_address_prefix
  resource_group_name         = azurerm_resource_group.rg-ntw.name
  network_security_group_name = azurerm_network_security_group.nsg[each.value.subnet_key].name
}

resource "azurerm_virtual_network" "vnet" {
  name                = "${local.name_prefix}-vnet-${local.prefix_app_name}"
  location            = azurerm_resource_group.rg-ntw.location
  resource_group_name = azurerm_resource_group.rg-ntw.name
  address_space       = var.vnet.address_space
  dns_servers         = var.vnet.dns_servers == null || length(var.vnet.dns_servers) == 0 ? local.default_dns_servers : var.vnet.dns_servers

  encryption {
    enforcement = var.vnet.encryption_enforcement
  }

  tags = var.tags

  lifecycle {
    ignore_changes = [
      tags["CreationDateTime"],
      tags["Owner"],
      tags["Environment"],
      tags["ITAB"],
      tags["AppName"],
      tags["AppEnv"],
      tags["SubscriptionType"],
      tags["PlatformId"],
      tags["Availability"],
      tags["Confidentiality"],
      tags["Integrity"]
    ]
  }
}

resource "azurerm_subnet" "subnets" {
  for_each = local.valid_subnets

  name                              = "snet-${local.prefix_app_name}-${each.key}"
  resource_group_name               = azurerm_resource_group.rg-ntw.name
  virtual_network_name              = azurerm_virtual_network.vnet.name
  address_prefixes                  = each.value.address_prefixes
  private_endpoint_network_policies = each.value.private_endpoint_network_policies

  dynamic "delegation" {
    for_each = each.value.delegation.name == "" ? [] : [1]

    content {
      name = "delegation-${each.key}"

      service_delegation {
        name    = each.value.delegation.name
        actions = each.value.delegation.actions
      }
    }
  }
  service_endpoints = ["Microsoft.KeyVault", "Microsoft.Eventhub", "Microsoft.Storage"]

  lifecycle {
    ignore_changes       = [service_endpoints] # Microsoft.Eventhub is always getting recreated
    replace_triggered_by = [azurerm_virtual_network.vnet.address_space]
  }
}

resource "azurerm_subnet_network_security_group_association" "snet-nsgs" {
  for_each                  = local.subnets_with_default
  subnet_id                 = azurerm_subnet.subnets[each.key].id
  network_security_group_id = azurerm_network_security_group.nsg[each.key].id
}

