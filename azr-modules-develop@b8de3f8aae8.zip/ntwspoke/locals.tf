locals {
  name_prefix     = "${var.lbbw_location}-${var.infra_environment}"
  prefix_app_name = "${var.app_environment}${var.app_name}"

  ### Enable this again when azure monitor workaround will be disabled ###
  # default_dns_servers = var.is_old_tenant ? var.infra_environment == "e" ? ["10.238.3.244", "168.63.129.16"] : contains(["d", "c", "p"], var.infra_environment) ? ["10.35.4.4", "168.63.129.16"] : [] : ["192.168.53.53"]
  # INT - eng: ["10.238.3.244", "168.63.129.16"]
  # INT - dev, cert, prod: ["10.35.4.4", "168.63.129.16"]
  # EU: ["192.168.53.53"]

  ### Delete this line when azure monitor workaround will be disabled ###
  default_dns_servers = var.is_old_tenant ? var.infra_environment == "e" ? ["10.238.3.244", "168.63.129.16"] : contains(["d", "c", "p"], var.infra_environment) ? ["10.35.4.4", "168.63.129.16"] : [] : contains(["c", "p"], var.infra_environment) ? [] : ["192.168.53.53"]


  default_rules = {
    default1 = {
      name                       = "DenyAllInBoundOverride"
      direction_short_name       = "ib"
      access                     = "Deny"
      protocol                   = "*"
      priority                   = 4096
      source_port_range          = "*"
      destination_port_range     = "*"
      source_address_prefix      = "*"
      destination_address_prefix = "*"
    },
    default2 = {
      name                       = "AllowAzureLoadBalancerInBoundOverride"
      direction_short_name       = "ib"
      access                     = "Allow"
      protocol                   = "*"
      priority                   = 4095
      source_port_range          = "*"
      destination_port_range     = "*"
      source_address_prefix      = "AzureLoadBalancer"
      destination_address_prefix = "*"
    }
  }

  private_endpoint_subnet = {
    private_endpoint_subnet = {
      private_endpoint_network_policies = "Enabled"
      address_prefixes                  = var.vnet.private_subnet_address_spaces
      routes                            = []
      delegation = {
        name    = ""
        actions = []
      }
    }
  }

  subnets_with_default = merge(var.vnet.subnets, local.private_endpoint_subnet)

  valid_private_endpoint_policies = ["Disabled", "Enabled", "NetworkSecurityGroupEnabled", "RouteTableEnabled"]

  valid_subnets = tomap({
    for subnet_name, subnet in local.subnets_with_default :
    subnet_name => {
      address_prefixes = subnet.address_prefixes
      delegation       = subnet.delegation
      # If a private_endpoint_network_policies  was set that is not part of the valid options, throw an error.
      private_endpoint_network_policies = contains(local.valid_private_endpoint_policies, subnet.private_endpoint_network_policies) ? subnet.private_endpoint_network_policies : throw("Invalid value for private_endpoint_network_policies in subnet '${subnet_name}'. Must be one of 'Disabled', 'Enabled', 'NetworkSecurityGroupEnabled', 'RouteTableEnabled'")
    }
  })
}
