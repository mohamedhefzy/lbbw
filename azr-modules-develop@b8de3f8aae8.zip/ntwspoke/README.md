# Network Spoke
A spoke has several components that are related to each other. Hence, network specific resources are grouped in this module and in a single terraform state.


## Virtual Network
There is only one VNet deployed by default for each spoke. The address range(s) need to be aligned internally/IPAM. 

### Subnets
There are two default subnets created by default: PrivateEndpoint and workload-subnet1
Depending on subnet type, there might be additional settings such as delegation which are set by purpose.

## Network Security Group
Each subnet is associatd with a dedicated Network Security Group which handles incoming network traffic

## User Defined Route
By default, UDRs are not utilized except they are absolutely needed. All kind of network routings are propagated using Azur Route Server. However, Azure services might make of use of UDRs. For those purposes, UDRs can be used. 
For Azure Kubernetes Service, there is a special treatment - see Specifics below.

# Technical implementation and Specifics
## Azure Kubernetes Service
This service requires a User Defined Route in order to route traffic internally via Network Virtual Appliance.
The required UDR will be maintained by aks module as part of the lifecycle