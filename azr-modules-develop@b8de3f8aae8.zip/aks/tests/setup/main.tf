provider "azurerm" {
  features {}
  subscription_id = "541ac1c2-8b44-4aac-abdf-3ce58dd8f753"
}


module "aks" {

  source = "../../"

  is_old_tenant     = var.is_old_tenant
  app_name          = var.app_name
  app_type          = var.app_type
  app_environment   = var.app_environment
  infra_environment = var.infra_environment
  lbbw_location     = var.lbbw_location
  location          = var.location
  backupretention   = var.backupretention
  patchwindow       = var.patchwindow
  sbk               = var.sbk
  availability      = var.availability

  tags = {
    source         = "terraform"
    environment    = "development"
    "ITAB"         = "7656"
    "AppName"      = "test"
    "Owner"        = "test"
    "Creator"      = "iac-admin"
    "ServerRole"   = "container-platform"
    "CreationDate" = "auto-generated"
  }

  iam-entra-object-ids = {
    third-lvl-support_tier2 : "6a3a422d-814e-432b-9d79-f5fa30b38f3b",
    third-lvl-support_tier1 : "d771fde7-7f31-45e1-a3cc-dce3ca953ad1",
    third-lvl-support_tier0 : "f79f7b32-15f8-44ba-b0fd-1c7d33aea31d",
    second-lvl-support_tier2 : "183e5f5b-76ea-4f25-b15a-373b58b96634",
    second-lvl-support_tier1 : "d6b7e462-924b-4e5b-88e6-97d75103aeb9",
    second-lvl-support_tier0 : "3666aa92-691b-419f-8003-51b8a5420454",
    sec-inc-response_tier2 : "d64e1d59-31f9-450d-8bf9-ba10156a55cf",
    sec-inc-response_tier1 : "a3b7305e-aead-4abb-82ee-432cd81c5463",
    sec-inc-response_tier0 : "460572cc-c118-4441-bc37-4c6fdf2b98ed",
    cp-release-mgr_tier2 : "",
    cp-release-mgr_tier1 : "",
    cp-release-mgr_tier0 : "",
    cp-developer_tier2 : "78094547-6ed2-41f1-ab6a-a62065a033c8",
    cp-developer_tier1 : "c615a4af-5022-4e7f-81ab-a86ddbae65ba",
    cp-developer_tier0 : "13e919ea-5f7a-46d4-80b7-b857cb4530cb",
    app-owner_tier2 : "100f607b-797e-46fa-9c47-1bea43e73dde",
    app-owner_tier1 : "64764dc9-ff24-417f-a283-f427f6102f43",
    app-owner_tier0 : "aadbbc9f-bbe3-4c95-8b1e-3a52677c28f2",
    app-operator_tier2 : "6f04a56d-7ddf-4212-a3d7-c5cb0de9d51b",
    app-operator_tier1 : "3d8bde71-f942-41e6-bff0-a5c9dd2414a4",
    app-operator_tier0 : "49c4fa4c-90d3-4d11-a28e-ceb0abe2b73a",
    app-developer_tier2 : "66ad88af-b231-4522-960a-69be4c6dcfe5",
    app-developer_tier1 : "5c559b00-e82b-4a9d-b0ff-37bb301a9f6d",
    app-developer_tier0 : "2a522a3f-8b71-44f0-8435-53b28ad8dc62",
    db-access : "2a522a3f-8b71-44f0-8435-53b28ad8dc62"
  }
  is_iam_enabled = false


  ntwspoke_rg_id                  = "/subscriptions/xxx-xxx-xxx-xxx-xxx/resourceGroups/euho-e-rg-xtest-ntw"
  keyvault_encryption_key_id      = "xxx"
  platform_keyvault_id            = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.DataProtection/backupVaults/backupVaultName"
  keyvault_keyvault_ids           = { app : "/subscriptions/xxx-xxx-xxx-xxx-xxxx/resourceGroups/euho-e-rg-xtest-kv/providers/Microsoft.KeyVault/vaults/euho-e-kv-xtest-app", encrpt : "/subscriptions/xxx-xxx-xxx-xxx-xxxx/resourceGroups/euho-e-rg-xtest-kv/providers/Microsoft.KeyVault/vaults/euho-e-kv-xtest-encryp" }
  bvault_rg_name                  = "bvaultrgname"
  bvault_name                     = "bvaultname"
  bvault_id                       = "/subscriptions/541ac1c2-8b44-4aac-abdf-3ce58dd8f753/resourceGroups/euho-e-rg-xtest-bvault/providers/Microsoft.DataProtection/backupVaults/euho-e-bvault-xtest"
  bvault_principal_id             = "/subscriptions/xxx-xxx-xxx-xxx-xxx/resourceGroups/euho-e-rg-xtest-bvault/providers/Microsoft.DataProtection/backupVaults/euho-e-bvault-xtest"
  bvault_kubernetes_policy_id     = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.DataProtection/backupVaults/backupVaultName/backupPolicies/backupPolicyName"
  storageaccount_rg_recovery_name = "sargrecoveryname"
  storageaccount_rg_recovery_id   = "/subscriptions/xxx-xxx-xxx-xxx-xxx/resourceGroups/euho-e-rg-xtest-st"
  storageaccount_recovery_name    = "sarecoveryname"
  storageaccount_recovery_id      = "/subscriptions/xxx-xxx-xxx-xxx-xxx/resourceGroups/euho-e-rg-xtest-st/providers/Microsoft.Storage/storageAccounts/euhoestxtests1"
  storageaccount_share_names      = { share1-d1 : "share2name", share2-d2 : "share2name" }
  storageaccount_data             = { d1 : { name : "test1", primary_access_key : "share1" }, d2 : { name : "test2", primary_access_key : "share2" } }

  vnet_subnet_ids = { snet1 : "/subscriptions/xxx-xxx-xxx-xxx-xxx/resourceGroups/euho-e-rg-xtest-ntw/providers/Microsoft.Network/virtualNetworks/euho-e-vnet-xtest/subnets/snet1" }

  aks = {
    cluster = {
      kubernetes_version                  = "1.29.5"
      private_cluster_enabled             = true
      private_cluster_public_fqdn_enabled = false
      namespaces = {
        testnamespace1 : "testnamespace1"
        projectns2 : "projectns2"
      }
      workload_identity_enabled = true
      oidc_issuer_enabled       = true
      disk_encryption_set_id    = null

      default_node_pool = {
        auto_scaling_enabled = {
          min_count = "1"
          max_count = "3"
        }
        os_sku                  = "AzureLinux"
        vm_size                 = "Standard_D2s_v5"
        kubelet_disk_type       = "OS"
        os_disk_type            = "Managed"
        os_disk_size_gb         = 128
        vnet_subnet_key         = "snet1"
        type                    = "VirtualMachineScaleSets"
        host_encryption_enabled = true
        node_labels             = {}
        zones                   = ["3"]
      }
      managed_disks = {
        m1 = {
          create_option = "Empty"
          disk_size     = 128
          tier          = ""
          shared        = false
        }
      }

      file_shares = {
        fs1 = {
          storage_account_key = "d1"
          share_key           = "share1"
          read_only           = false
          secret_name         = "secret"
          secret_namespace    = "namespace"
          pv_size_gb          = "12"
        }
      }

      blobs = {
        b1 = {
          read_only  = false
          pv_size_gb = "12"
        }
      }

      identity = {
        type = "SystemAssigned"
      }
      azure_active_directory_role_based_access_control = {
        azure_rbac_enabled = true
      }
      network_profile = {
        network_plugin      = "azure"
        network_data_plane  = "cilium"
        network_plugin_mode = "overlay"
        dns_service_ip      = "10.0.0.10"
        service_cidr        = "10.0.0.0/21"
        outbound_type       = "userDefinedRouting"
      }

      storage_profile = {
        blob_driver_enabled = "true"
        disk_driver_enabled = "true"
        file_driver_enabled = "true"
      }
      rbac = {
        r1 = {
          scope                = ""
          role_definition_name = ""
          principal_id         = [""]
        }
      }
    }
  }
}