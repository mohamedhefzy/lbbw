run "execute" {
  module {
    source = "./setup"
  }

  command = plan

  assert {
    condition     = module.aks.rg_name == "euho-e-rg-xtest-aks-cluster"
    error_message = "The resource group does not match."
  }

  assert {
    condition     = module.aks.cluster_name == "euho-e-aks-xtest-cluster"
    error_message = "The cluster name does not match."
  }

  assert {
    condition     = module.aks.user_assigned_identity_name == "euho-e-mid-xtest"
    error_message = "The name of the user assigned identity does not match."
  }
}