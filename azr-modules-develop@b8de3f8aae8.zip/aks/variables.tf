variable "is_old_tenant" {
  description = "Flag to check if provided LZ is deployed in the old tenant or not"
  type        = bool
}

variable "app_environment" {
  description = "This variable defines the app environment of the specific application. Placeholder is 'x' if nothing is set."
  type        = string
}

variable "app_name" {
  description = "Name of the application per subscription"
  type        = string
}

variable "app_type" {
  description = "Type of app (shared, spoke...)"
  type        = string
}

variable "lbbw_location" {
  description = "LBBW Location"
  type        = string
}

variable "location" {
  description = "Azure location"
  type        = string
}

variable "infra_environment" {
  description = "This variable defines the environment to be built. (Prod,Cert,Dev,Engineering)."
  type        = string
}

variable "sbk" {
  description = "This variable defines the 'Schutzbedarfsklasse' (1, 2, 3, 4)"
  type        = string
}

variable "availability" {
  description = "The variable defines the availability (V1, V2, V3, V4)"
  type        = string
}

variable "patchwindow" {
  description = "This variable defines the patchwindow (Option1, Option2, Option3)"
  type        = string
}

variable "backupretention" {
  description = "This variable defines the backupretention (SHORT, MID, LONG)"
  type        = string
}

variable "ntwspoke_rg_id" {
  description = "The id of the ntwspoke resource group"
  type        = string
}

variable "vnet_subnet_ids" {
  description = "The ids of the subnet"
  type        = map(string)
}

variable "private_dns_zone_id" {
  description = "ID of the private DNS Zone"
  type        = string
}

variable "keyvault_encryption_key_id" {
  description = "The id of the key that is used for disk encryption"
  type        = string
}

variable "keyvault_keyvault_ids" {
  description = "The ids of all keyvaults"
  type        = map(string)
}

variable "bvault_rg_name" {
  description = "The resource group name of the backup vault"
  type        = string
}

variable "bvault_name" {
  description = "The name  of the backup vault"
  type        = string
}

variable "bvault_id" {
  description = "The id of the backup vault"
  type        = string
}

variable "bvault_principal_id" {
  description = "The principal id of the backup vault"
  type        = string
}

variable "bvault_kubernetes_policy_id" {
  description = "The kubernetes policy id within the backup vault"
  type        = string
}

variable "storageaccount_rg_name" {
  description = "The resource group name of the storage account"
  type        = string
}

variable "storageaccount_rg_recovery_name" {
  description = "The resource group name of the recovery storage account"
  type        = string
}

variable "storageaccount_rg_recovery_id" {
  description = "The resource group id of the recovery storage account"
  type        = string
}

variable "storageaccount_recovery_name" {
  description = "The name of the recovery storage account"
  type        = string
}

variable "storageaccount_recovery_id" {
  description = "The id of the recovery storage account"
  type        = string
}

variable "storageaccount_share_names" {
  description = "A map of all keys to the names of all storage account shares"
  type        = map(string)
}

variable "storageaccount_container_names" {
  description = "A map of all keys to the names of all storage account conatiner"
  type        = map(string)
}

variable "storageaccount_data" {
  description = "A map of all keys to data of all storage accounts"
  sensitive   = true
  type = map(object({
    name               = string
    primary_access_key = string
  }))
}

variable "aks" {
  description = "The configuration of aks"
  type = object({
    cluster = optional(object({
      kubernetes_version                  = string
      private_cluster_enabled             = bool
      private_cluster_public_fqdn_enabled = bool
      namespaces                          = map(string)
      workload_identity_enabled           = bool
      oidc_issuer_enabled                 = bool
      disk_encryption_set_id              = string
      sku_tier                            = string
      vnet_subnet_key                     = string
      dynamic_storage                     = bool
      default_node_pool = object({
        node_count                   = string
        auto_scaling_enabled         = bool
        min_count                    = string
        max_count                    = string
        os_sku                       = string
        vm_size                      = string
        kubelet_disk_type            = string
        only_critical_addons_enabled = string
        os_disk_type                 = string
        os_disk_size_gb              = number
        type                         = string
        host_encryption_enabled      = bool
        node_labels                  = map(string)
        zones                        = list(string)
      })
      app_node_pool = map(object({
        node_count              = string
        auto_scaling_enabled    = bool
        min_count               = string
        max_count               = string
        os_sku                  = string
        vm_size                 = string
        kubelet_disk_type       = string
        os_disk_type            = string
        os_disk_size_gb         = number
        host_encryption_enabled = bool
        node_labels             = map(string)
        node_taints             = list(string)
        zones                   = list(string)
      }))
      file_shares = map(object({
        storage_account_key  = string
        share_key            = string
        storage_account_type = string
        read_only            = bool
        secret_name          = string
        secret_namespace     = string
        pv_size_gb           = string
        protocol             = string
        reclaim_policy       = string
        volume_binding_mode  = string
        mount_options        = set(string)
      }))
      blobs = map(object({
        storage_account_key  = string
        container_key        = string
        storage_account_type = string
        read_only            = bool
        pv_size_gb           = string
        protocol             = string
        reclaim_policy       = string
        volume_binding_mode  = string
        mount_options        = set(string)
      }))
      managed_disks = map(object({
        storage_account_type    = string
        create_option           = string
        disk_size               = string
        tier                    = string
        shared                  = bool
        fsType                  = string
        cachingMode             = string
        writeAcceleratorEnabled = bool
        enableBursting          = bool
        reclaim_policy          = string
        volume_binding_mode     = string
        mount_options           = set(string)
      }))
      identity = object({
        type = string
      })
      azure_active_directory_role_based_access_control = object({
        azure_rbac_enabled = bool
      })
      network_profile = object({
        network_plugin      = string
        network_data_plane  = string
        network_plugin_mode = string
        dns_service_ip      = string
        service_cidr        = string
        outbound_type       = string
      })
      storage_profile = object({
        blob_driver_enabled         = bool
        disk_driver_enabled         = bool
        file_driver_enabled         = bool
        snapshot_controller_enabled = bool
      })
      rbac = optional(map(object({
        scope                = string
        role_definition_name = string
        principal_id         = list(string)
      })))
    }))
  })
}

variable "kubernetes" {
  description = "Configuration which should be deployed in aks."
  type = object({
    namespaces = map(string)
  })
}

variable "postgres_server_names" {
  description = "This configuration is used for RBAC permissions from managed identity assigned on postgres."
  type        = map(string)
}

variable "tags" {
  description = "Map of Tags per subscription"
  type        = map(string)
}

variable "is_iam_enabled" {
  description = "Toggle to disable IAM Entra RBAC role assignments in engineering"
  type        = bool
}

variable "iam-entra-object-ids" {
  description = "Map of Entra Security Group Object IDs for role assignments"
  type        = map(string)
}

variable "namespace-iam-entra-object-ids" {
  description = "Map of Entra Security Group Object IDs for role assignments for specific namespaces"
  type        = map(string)
  default     = {}
}

variable "eventhub_rg_id" {
  description = "The id of the eventhub resource group"
  type        = string
}
