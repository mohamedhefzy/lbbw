locals {
  name_prefix     = "${var.lbbw_location}-${var.infra_environment}"
  prefix_app_name = "${var.app_environment}${var.app_name}"

  system_namespaces = {
    kube-node-lease          = "kube-node-lease"
    kube-public              = "kube-public"
    kube-system              = "kube-system"
    default                  = "default"
    dynatrace                = "dynatrace"
    infrastructure           = "infrastructure"
    dataprotection-microsoft = "dataprotection-microsoft"
    external-secrets         = "external-secrets"
    external-dns             = "external-dns"
  }

  default_namespaces = {
    dynatrace                = "dynatrace"
    infrastructure           = "infrastructure"
    dataprotection-microsoft = "dataprotection-microsoft"
    external-secrets         = "external-secrets"
    external-dns             = "external-dns"
  }

  merged_namespaces = merge(var.kubernetes.namespaces, local.default_namespaces)

  merged_default_node_labels = merge(var.aks.cluster.default_node_pool.node_labels, { "nodepool" = "default" })

  merged_app_node_labels = {
    for pool_name, pool_config in var.aks.cluster.app_node_pool :
    pool_name => merge(
      pool_config.node_labels,  # User-defined node labels
      { "nodepool" = "worker" } # Default label for all nodes
    )
  }

  get_storage_account_type = var.availability == "V1" ? "Standard_LRS" : var.availability == "V2" ? "StandardSSD_LRS" : "Premium_LRS"
  get_csi_driver_type      = var.availability == "V1" ? "Standard_LRS" : "Premium_LRS"

  ##############################################################
  #
  # List of namespace IAM groups
  #
  ##############################################################

  namespace_iam_groups = {
    for iam_name, iam_id in var.namespace-iam-entra-object-ids :
    # iam_name currently is structured like "euho-<stage>-aks-<subscription>-cluster-<namespace name>". split extracts the namespace name
    split("-", iam_name)[5] => iam_id
  }

  private_dns_zone_id = {
    e = "/subscriptions/a1ce34e0-ffe5-46be-b04b-1cbf0735eeb5/resourceGroups/euho-e-rg-privatednszone/providers/Microsoft.Network/privateDnsZones/"
    d = "/subscriptions/b8c7d5eb-d942-400c-999c-1c741ffb52bf/resourceGroups/euho-d-rg-privatednszone/providers/Microsoft.Network/privateDnsZones/"
    c = "/subscriptions/b79558eb-d4b4-4d56-8f95-8d5c33f7c3cf/resourceGroups/euho-c-rg-privatednszone/providers/Microsoft.Network/privateDnsZones/"
    p = "/subscriptions/2836bb7c-3eaa-4fdd-9024-3f17daf08755/resourceGroups/euho-p-rg-privatednszone/providers/Microsoft.Network/privateDnsZones/"
  }

  private_dns_zone_id_new_tenant = {
    e = "/subscriptions/3da49d2d-46fc-4deb-a3aa-57cbc662e092/resourceGroups/euho-e-rg-privatednszones/providers/Microsoft.Network/privateDnsZones/"
    d = "/subscriptions/ceeadf22-6dcf-47f7-a232-818623b3afdc/resourceGroups/euho-p-rg-privatednszones/providers/Microsoft.Network/privateDnsZones/"
    c = "/subscriptions/ceeadf22-6dcf-47f7-a232-818623b3afdc/resourceGroups/euho-p-rg-privatednszones/providers/Microsoft.Network/privateDnsZones/"
    p = "/subscriptions/ceeadf22-6dcf-47f7-a232-818623b3afdc/resourceGroups/euho-p-rg-privatednszones/providers/Microsoft.Network/privateDnsZones/"
  }

  flatten_namespace_servers = {
    for n in(flatten(
      [
        for namespace_key, namespace in var.kubernetes.namespaces : [
          for server_key, server_name_key in var.postgres_server_names : {
            key             = "${namespace_key}-${server_key}"
            namespace       = namespace_key
            server_name_key = server_name_key
          }
        ]
    ])) : n.key => n
  }
}