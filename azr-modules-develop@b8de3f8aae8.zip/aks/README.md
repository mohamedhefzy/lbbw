[//]: <> (TODO: Describe specifics of module)


# Azure Kubernetes Service
This module is used to deploy an [Azure Kubernetes Service](https://azure.microsoft.com/en-us/products/kubernetes-service).

## Created Resources

This module creates the following resources on azure


- ``azurerm_resource_group.rg-aks``: A resource group where the following resources are located. 
- ``azurerm_route_table.rt``: Resource for a route table.
- ``azurerm_subnet_route_table_association.rta``: Association between route table and subnet.
- ``azurerm_disk_encryption_set.disc-encryption-set``: The disc encyrption set is created if sbk is 3 or 4.
- ``azurerm_role_assignment.kv-des-crypto-encryp``: The role assignment gives the authorization to perform encyption and decryption operations.
- ``azurerm_kubernetes_cluster.aks``: The resource for the azure kubernetes service.
- ``azurerm_managed_disk.managed-disks``: The resource for a managed disk.
- ``azurerm_role_assignment.cluster-access_network_contributor``: Set the role 'Network Contributor' to the network resource group.
- ``azurerm_role_assignment.cluster-access-nodepool_network_contributor``: Set the role 'Network Contributor' to the aks-cluster-nodepool resource group.
// backup resources
- ``azurerm_kubernetes_cluster_trusted_access_role_binding.aks_cluster_trusted_access``: Trusted access for the role Microsoft.DataProtection/backupVaults/backup-operator.
- ``azurerm_storage_container.container-aks-recovery``: Creates a container in the recovery storage account.
- ``azurerm_kubernetes_cluster_extension.aks-backup-extension``: Backup Extension for aks.
- ``azurerm_role_assignment.extension_and_storage_account_permission``
- ``azurerm_role_assignment.extension_and_storage_account_key_permission``
- ``azurerm_role_assignment.vault_msi_read_on_cluster``
- ``azurerm_role_assignment.vault_msi_read_on_snap_rg``
- ``azurerm_role_assignment.vault_msi_snapshot_contributor_on_snap_rg``
- ``azurerm_role_assignment.vault_msi_snapshot_contributor_on_snap_rg``
- ``azurerm_role_assignment.vault_data_operator_on_snap_rg``
- ``azurerm_role_assignment.vault_data_contributor_on_storage``
- ``azurerm_role_assignment.ext-msi_contributor_on_storage``
- ``azurerm_role_assignment.cluster_msi_contributor_on_snap_rg``:
- ``azurerm_role_assignment.msi_access_for_postmodules_cluster_admin``:
- ``azurerm_role_assignment.msi_access_for_postmodules_rbac_cluster_admin``:
- ``azurerm_data_protection_backup_instance_kubernetes_cluster.bkp-aks-instance``: Connection between aks and backup vault
// Resources required for the connection between aks and key vault / private dnszone.
- ``azurerm_user_assigned_identity.mid``: Is the managed identity that is authorized.
- ``azurerm_role_assignment.keyvault_access``:  The role assignment to access the app key vault.
- ``azurerm_role_assignment.pdns_access``:  The role assignment to access the private dnszone.
//
- ``azurerm_postgresql_flexible_server_active_directory_administrato.postgres_active_directory_administrator``: Set managed identity to postgres admin user.


## Variables

| Name               | Description                                                               | Type   |
| ------------------ | ------------------------------------------------------------------------- | -------|
| app_environment | This variable defines the app environment of the specific application. Placeholder is 'x' if nothing is set. | string |
| app_name | Name of the application per subscription. | string |
| app_type | Type of app (shared, spoke...) | string |
| lbbw_location | LBBW Location | string |
| location | Azure location | string |
| infra_environment | This variable defines the environment to be built. (Prod,Cert,Dev,Engineering). | string |
| sbk | This variable defines the 'Schutzbedarfsklasse' (1, 2, 3, 4). | string |
| availability | The variable defines the availability (V1, V2, V3, V4). | string |
| patchwindow | This variable defines the patchwindow (Option1, Option2, Option3). | string |
| backupretention | This variable defines the backupretention (SHORT, MID, LONG). | string |
| ntwspoke_rg_id | The id of the ntwspoke resource group. | string |
| vnet_subnet_ids | The ids of the subnet | map(string) |
| keyvault_encryption_key_id | The id of the key that is used for disk encryption. | string |
| platform_keyvault_id | The id of the keyvault that contains the passwords and secrets. | string |
| keyvault_keyvault_ids | The ids of the diffrent key vaults. | map(string)
| bvault_rg_name | The resource group name of the backup vault. | string |
| bvault_name | The name  of the backup vault. | string |
| bvault_id | The id of the backup vault. | string |
| bvault_principal_id | The principal id of the backup vault. | string |
| bvault_kubernetes_policy_id | The kubernetes policy id within the backup vault. | string |
| storageaccount_rg_recovery_name | The resource group name of the recovery storage account. | string |
| storageaccount_rg_recovery_id | The resource group id of the recovery storage account. | string |
| storageaccount_recovery_name | The name of the recovery storage account | string |
| storageaccount_recovery_id | The id of the recovery storage account. | string |
| aks | The configuration of aks. | object |
| kubernetes | Config of the kubernetes resources. | object |
| tags | Map of Tags per subscription. | map(string) |
| is_iam_enabled | Toggle to disable IAM Entra RBAC role assignments in engineering. | bool |
| iam-entra-object-ids | Map of Entra Security Group Object IDs for role assignments. | map(string) |
| eventhub_rg_id| The id of the eventhub resource group. | string |


### AKS Model

Model Deployments are described in a list of objects of the following structure:

```

aks =  {
    cluster = {
      kubernetes_version                  = string
      private_cluster_enabled             = bool
      private_cluster_public_fqdn_enabled = bool
      namespaces                          = map(string)
      workload_identity_enabled           = bool
      oidc_issuer_enabled                 = bool
      disk_encryption_set_id              = string
      sku_tier                            = string
      default_node_pool = {
        node_count              = string
        auto_scaling_enabled    = bool
        min_count               = string
        max_count               = string
        os_sku                  = string
        vm_size                 = string
        kubelet_disk_type       = string
        os_disk_type            = string
        os_disk_size_gb         = number
        vnet_subnet_key         = string
        type                    = string
        host_encryption_enabled = bool
        node_labels             = map(string)
        zones                   = list(string)
      }
      file_shares = map({
        storage_account_key = string
        share_key           = string
        read_only           = bool
        secret_name         = string
        secret_namespace    = string
        pv_size_gb          = string
      })
      blobs = map({
        storage_account_key = string
        container_key       = string
        read_only           = bool
        pv_size_gb          = string
      })
      managed_disks = map({
        storage_account_type = string
        create_option        = string
        disk_size            = string
        tier                 = string
        shared               = bool
      })
      identity = {
        type = string
      }
      azure_active_directory_role_based_access_control = {
        azure_rbac_enabled = bool
      }
      network_profile = {
        network_plugin      = string
        network_data_plane  = string
        network_plugin_mode = string
        dns_service_ip      = string
        service_cidr        = string
        outbound_type       = string
      }
      storage_profile = {
        blob_driver_enabled = bool
        disk_driver_enabled = bool
        file_driver_enabled = bool
      }
      rbac = map({
        scope                = string
        role_definition_name = string
        principal_id         = list(string)
      })
    }
  }

```

## Output

| Name             | Description                                                                                                       |
| ---------------- | ----------------------------------------------------------------------------------------------------------------- |
| rg_id | The `azurerm_kubernetes_cluster`'s resource group id. |
| rg_name | The `azurerm_kubernetes_cluster`'s resource group name. |
| cluster_id | The `azurerm_kubernetes_cluster`'s id. |
| cluster_name | The `azurerm_kubernetes_cluster`'s name. |
| cluster_private_fqdn | The FQDN for the Kubernetes Cluster when private link has been enabled, which is only resolvable inside the Virtual Network used by the Kubernetes Cluster. |


## Required Modules
- ntwspoke
- dnszone
- keyvault
- bvault
- storageaccount
