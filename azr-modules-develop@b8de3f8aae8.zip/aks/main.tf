provider "kubernetes" {
  host                   = azurerm_kubernetes_cluster.aks.kube_admin_config.0.host
  username               = azurerm_kubernetes_cluster.aks.kube_admin_config.0.username
  password               = azurerm_kubernetes_cluster.aks.kube_admin_config.0.password
  client_certificate     = base64decode(azurerm_kubernetes_cluster.aks.kube_admin_config.0.client_certificate)
  client_key             = base64decode(azurerm_kubernetes_cluster.aks.kube_admin_config.0.client_key)
  cluster_ca_certificate = base64decode(azurerm_kubernetes_cluster.aks.kube_admin_config.0.cluster_ca_certificate)
}

data "azurerm_client_config" "current" {
  # Returns the values of the currently logged in user
  # client_id         - is set to the Azure Client ID (Application Object ID).
  # tenant_id         - is set to the Azure Tenant ID.
  # subscription_id   - is set to the Azure Subscription ID.
  # object_id         - is set to the Azure Object ID.
}

resource "azurerm_resource_group" "rg-aks" {
  name     = "${local.name_prefix}-rg-${local.prefix_app_name}-aks-cluster"
  location = var.location

  tags = var.tags

  lifecycle {
    ignore_changes = [
      tags["CreationDateTime"],
      tags["Owner"],
      tags["Environment"],
      tags["ITAB"],
      tags["AppName"],
      tags["AppEnv"],
      tags["SubscriptionType"],
      tags["PlatformId"],
      tags["Availability"],
      tags["Confidentiality"],
      tags["Integrity"]
    ]
  }
}

resource "azurerm_route_table" "rt" {
  location            = azurerm_resource_group.rg-aks.location
  name                = "${local.name_prefix}-rt-${local.prefix_app_name}-aks-cluster"
  resource_group_name = azurerm_resource_group.rg-aks.name

  tags = var.tags

  lifecycle {
    ignore_changes = [
      tags["CreationDateTime"],
      tags["Owner"],
      tags["Environment"],
      tags["ITAB"],
      tags["AppName"],
      tags["AppEnv"],
      tags["SubscriptionType"],
      tags["PlatformId"],
      tags["Availability"],
      tags["Confidentiality"],
      tags["Integrity"]
    ]
  }
}

resource "azurerm_subnet_route_table_association" "rta" {

  subnet_id      = var.vnet_subnet_ids[var.aks.cluster.vnet_subnet_key]
  route_table_id = azurerm_route_table.rt.id
}

resource "azurerm_disk_encryption_set" "disc-encryption-set" {
  count               = contains(["3", "4"], var.sbk) ? 1 : 0
  name                = "${local.name_prefix}-des-${local.prefix_app_name}"
  resource_group_name = azurerm_resource_group.rg-aks.name
  location            = azurerm_resource_group.rg-aks.location
  key_vault_key_id    = var.keyvault_encryption_key_id

  identity {
    type         = "UserAssigned"
    identity_ids = ["/subscriptions/${data.azurerm_client_config.current.subscription_id}/resourceGroups/${local.name_prefix}-rg-${local.prefix_app_name}-infra/providers/Microsoft.ManagedIdentity/userAssignedIdentities/${local.name_prefix}-mid-${local.prefix_app_name}-infra"]
  }

  tags = var.tags

  lifecycle {
    ignore_changes = [
      tags["CreationDateTime"],
      tags["Owner"],
      tags["Environment"],
      tags["ITAB"],
      tags["AppName"],
      tags["AppEnv"],
      tags["SubscriptionType"],
      tags["PlatformId"],
      tags["Availability"],
      tags["Confidentiality"],
      tags["Integrity"]
    ]
  }
}

resource "null_resource" "delete-recovery-snapshots" {
  count = var.infra_environment == "e" ? 1 : 0 # We don't just want to delete all Snapshots on Productive Stages

  triggers = {
    rg_st_snapshots = var.storageaccount_rg_recovery_name
  }

  provisioner "local-exec" {
    when       = destroy
    command    = "chmod +x ../../azr-modules/gen_scripts/delete_recovery_snapshots.sh && ../../azr-modules/gen_scripts/delete_recovery_snapshots.sh ${self.triggers.rg_st_snapshots}"
    on_failure = "continue"
  }

  depends_on = [azurerm_disk_encryption_set.disc-encryption-set]
}

resource "null_resource" "script-permission_EncryptionAtHost" {
  provisioner "local-exec" {
    command = "chmod 777 ../../azr-modules/aks/registerFeature_EncryptionAtHost.sh"
  }
}

resource "null_resource" "register-feature_EncryptionAtHost" {
  provisioner "local-exec" {
    command = "../../azr-modules/aks/registerFeature_EncryptionAtHost.sh"
  }
  depends_on = [null_resource.script-permission_EncryptionAtHost]
}

resource "null_resource" "script-permission_KubernetesConfiguration" {
  provisioner "local-exec" {
    command = "chmod 777 ../../azr-modules/aks/registerProvider_KubernetesConfiguration.sh"
  }
}

resource "null_resource" "register-provider_KubernetesConfiguration" {
  provisioner "local-exec" {
    command = "../../azr-modules/aks/registerProvider_KubernetesConfiguration.sh"
  }
  depends_on = [null_resource.script-permission_KubernetesConfiguration]
}

resource "azurerm_kubernetes_cluster" "aks" {
  name                                = "${local.name_prefix}-aks-${local.prefix_app_name}-cluster"
  dns_prefix                          = "${local.name_prefix}-aks-${local.prefix_app_name}-cluster"
  location                            = var.location
  resource_group_name                 = azurerm_resource_group.rg-aks.name
  kubernetes_version                  = var.aks.cluster.kubernetes_version
  private_cluster_enabled             = true
  private_cluster_public_fqdn_enabled = false
  private_dns_zone_id                 = var.is_old_tenant ? "${local.private_dns_zone_id[var.infra_environment]}privatelink.westeurope.azmk8s.io" : "${local.private_dns_zone_id_new_tenant[var.infra_environment]}privatelink.germanywestcentral.azmk8s.io"
  workload_identity_enabled           = var.aks.cluster.workload_identity_enabled
  oidc_issuer_enabled                 = var.aks.cluster.oidc_issuer_enabled
  azure_policy_enabled                = true
  disk_encryption_set_id              = contains(["3", "4"], var.sbk) ? azurerm_disk_encryption_set.disc-encryption-set[0].id : null
  node_resource_group                 = "${local.name_prefix}-rg-${local.prefix_app_name}-aks-cluster_nodepool"
  sku_tier                            = can(var.aks.cluster.sku_tier) ? var.aks.cluster.sku_tier : var.infra_environment == "e" ? "Free" : "Standard"

  default_node_pool {
    name                         = "dnp${local.prefix_app_name}${substr("cluster", 0, 1)}${substr("cluster", -1, -1)}"  # max 12 chars
    temporary_name_for_rotation  = "tdnp${local.prefix_app_name}${substr("cluster", 0, 1)}${substr("cluster", -1, -1)}" # max 12 chars
    orchestrator_version         = var.aks.cluster.kubernetes_version
    node_count                   = var.aks.cluster.default_node_pool.node_count
    auto_scaling_enabled         = var.aks.cluster.default_node_pool.auto_scaling_enabled
    max_count                    = var.aks.cluster.default_node_pool.auto_scaling_enabled == true ? var.aks.cluster.default_node_pool.max_count : null
    min_count                    = var.aks.cluster.default_node_pool.auto_scaling_enabled == true ? var.aks.cluster.default_node_pool.min_count : null
    os_sku                       = var.aks.cluster.default_node_pool.os_sku
    vm_size                      = var.aks.cluster.default_node_pool.vm_size
    kubelet_disk_type            = var.aks.cluster.default_node_pool.kubelet_disk_type
    only_critical_addons_enabled = var.aks.cluster.default_node_pool.only_critical_addons_enabled
    os_disk_type                 = var.aks.cluster.default_node_pool.os_disk_type
    os_disk_size_gb              = var.aks.cluster.default_node_pool.os_disk_size_gb
    vnet_subnet_id               = var.vnet_subnet_ids[var.aks.cluster.vnet_subnet_key]
    host_encryption_enabled      = var.aks.cluster.default_node_pool.host_encryption_enabled
    node_labels                  = local.merged_default_node_labels       # "nodepool" : "default" set as default node label
    type                         = var.aks.cluster.default_node_pool.type # The type of Default Node Pool for the Kubernetes Cluster must be "VirtualMachineScaleSets" to attach multiple node pools
    zones                        = var.aks.cluster.default_node_pool.zones

    upgrade_settings {
      # Has to be at least 5 minutes long
      drain_timeout_in_minutes = 5
      # As we have many 1 node nodepools, we need at least another node to guarantee no downtime during upgrade processes.
      max_surge                     = "1"
      node_soak_duration_in_minutes = 0
    }
  }

  identity {
    type         = var.aks.cluster.identity.type # must be used in conjunction with private dns zone
    identity_ids = ["/subscriptions/${data.azurerm_client_config.current.subscription_id}/resourceGroups/${local.name_prefix}-rg-${local.prefix_app_name}-infra/providers/Microsoft.ManagedIdentity/userAssignedIdentities/${local.name_prefix}-mid-${local.prefix_app_name}-infra"]
  }
  azure_active_directory_role_based_access_control {
    azure_rbac_enabled = true
    tenant_id          = data.azurerm_client_config.current.tenant_id
  }
  network_profile {
    network_plugin      = var.aks.cluster.network_profile.network_plugin
    network_data_plane  = var.aks.cluster.network_profile.network_data_plane
    network_plugin_mode = var.aks.cluster.network_profile.network_plugin_mode
    dns_service_ip      = var.aks.cluster.network_profile.dns_service_ip
    service_cidr        = var.aks.cluster.network_profile.service_cidr
    outbound_type       = var.aks.cluster.network_profile.outbound_type
  }
  storage_profile {
    blob_driver_enabled         = var.aks.cluster.storage_profile.blob_driver_enabled
    disk_driver_enabled         = var.aks.cluster.storage_profile.disk_driver_enabled
    file_driver_enabled         = var.aks.cluster.storage_profile.file_driver_enabled
    snapshot_controller_enabled = var.aks.cluster.storage_profile.file_driver_enabled
  }

  web_app_routing {
    dns_zone_ids             = [var.private_dns_zone_id]
    default_nginx_controller = "None"
  }

  depends_on = [azurerm_subnet_route_table_association.rta, null_resource.register-provider_KubernetesConfiguration, null_resource.register-feature_EncryptionAtHost]

  tags = var.tags

  lifecycle {
    ignore_changes = [
      microsoft_defender, # Wird immer bei jedem reapply destroyed
      tags["CreationDateTime"],
      tags["Owner"],
      tags["Environment"],
      tags["ITAB"],
      tags["AppName"],
      tags["AppEnv"],
      tags["SubscriptionType"],
      tags["PlatformId"],
      tags["Availability"],
      tags["Confidentiality"],
      tags["Integrity"]
    ]
  }
}

resource "azurerm_kubernetes_cluster_node_pool" "aks_nodepool" {
  for_each = var.aks.cluster.app_node_pool != null ? var.aks.cluster.app_node_pool : {}

  name                        = "${each.key}${local.prefix_app_name}${substr("cluster", 0, 1)}${substr("cluster", -1, -1)}"  # max 12 chars
  temporary_name_for_rotation = "t${each.key}${local.prefix_app_name}${substr("cluster", 0, 1)}${substr("cluster", -1, -1)}" # max 12 chars
  kubernetes_cluster_id       = azurerm_kubernetes_cluster.aks.id
  orchestrator_version        = var.aks.cluster.kubernetes_version
  node_count                  = each.value.node_count
  auto_scaling_enabled        = each.value.auto_scaling_enabled
  max_count                   = each.value.auto_scaling_enabled == true ? each.value.max_count : null
  min_count                   = each.value.auto_scaling_enabled == true ? each.value.min_count : null
  os_sku                      = each.value.os_sku
  vm_size                     = each.value.vm_size
  kubelet_disk_type           = each.value.kubelet_disk_type
  os_disk_type                = each.value.os_disk_type
  os_disk_size_gb             = each.value.os_disk_size_gb
  vnet_subnet_id              = var.vnet_subnet_ids[var.aks.cluster.vnet_subnet_key]
  host_encryption_enabled     = each.value.host_encryption_enabled
  node_labels                 = local.merged_app_node_labels[each.key] # "nodepool" : "worker" set as default node label
  node_taints                 = each.value.node_taints
  zones                       = each.value.zones

  upgrade_settings {
    # Has to be at least 5 minutes long
    drain_timeout_in_minutes = 5
    # As we have many 1 node nodepools, we need at least another node to guarantee no downtime during upgrade processes.
    max_surge                     = "1"
    node_soak_duration_in_minutes = 0
  }

  tags = var.tags

  lifecycle {
    ignore_changes = [
      tags["CreationDateTime"],
      tags["Owner"],
      tags["Environment"],
      tags["ITAB"],
      tags["AppName"],
      tags["AppEnv"],
      tags["SubscriptionType"],
      tags["PlatformId"],
      tags["Availability"],
      tags["Confidentiality"],
      tags["Integrity"]
    ]
  }
}

resource "azurerm_managed_disk" "managed-disks" {
  for_each               = var.aks.cluster.dynamic_storage ? {} : var.aks.cluster.managed_disks
  name                   = "${local.name_prefix}-disk-${local.prefix_app_name}-md-${each.key}"
  resource_group_name    = azurerm_resource_group.rg-aks.name
  location               = var.location
  storage_account_type   = each.value.storage_account_type == null ? local.get_storage_account_type : each.value.storage_account_type
  tier                   = each.value.tier
  zone                   = var.aks.cluster.default_node_pool.zones == null ? null : var.aks.cluster.default_node_pool.zones[0]
  create_option          = each.value.create_option
  disk_size_gb           = each.value.disk_size
  max_shares             = each.value.shared ? (tonumber(each.value.disk_size) <= 1023 ? 3 : tonumber(each.value.disk_size) <= 8191 ? 5 : 10) : null # max shares depends on the disk size
  disk_encryption_set_id = contains(["3", "4"], var.sbk) ? azurerm_disk_encryption_set.disc-encryption-set[0].id : null                              # disk encyrption if sbk is 3 or 4
  tags                   = var.tags

  lifecycle {
    ignore_changes = [
      tags["CreationDateTime"],
      tags["Owner"],
      tags["Environment"],
      tags["ITAB"],
      tags["AppName"],
      tags["AppEnv"],
      tags["SubscriptionType"],
      tags["PlatformId"],
      tags["Availability"],
      tags["Confidentiality"],
      tags["Integrity"]
    ]
  }
}

resource "kubernetes_secret" "pv-share-secret" {
  for_each = var.aks.cluster.dynamic_storage ? {} : var.aks.cluster.file_shares
  metadata {
    name      = "${local.name_prefix}-kubesecret-${local.prefix_app_name}-${each.value.secret_name}"
    namespace = each.value.secret_namespace
  }
  data = {
    "azurestorageaccountname" = var.storageaccount_data[each.value.storage_account_key].name
    "azurestorageaccountkey"  = var.storageaccount_data["${each.value.storage_account_key}"].primary_access_key
  }
  depends_on = [azurerm_kubernetes_cluster.aks]
}

### Kubernetes Persistent Volumes if Storage option is non-dynamic ###

resource "kubernetes_persistent_volume" "pv-share" {
  for_each = var.aks.cluster.dynamic_storage ? {} : var.aks.cluster.file_shares
  metadata {
    name = "${local.name_prefix}-pv-${local.prefix_app_name}-${each.key}"
  }
  spec {
    access_modes = ["ReadWriteMany"]
    capacity = {
      storage = "${each.value.pv_size_gb}Gi"
    }
    storage_class_name = "azurefile"
    persistent_volume_source {
      azure_file {
        share_name       = var.storageaccount_share_names["${each.value.share_key}-${each.value.storage_account_key}"]
        secret_name      = kubernetes_secret.pv-share-secret[each.key].metadata[0].name
        read_only        = each.value.read_only
        secret_namespace = each.value.secret_namespace
      }
    }
  }
}

resource "kubernetes_persistent_volume" "pv-blob" {
  for_each = var.aks.cluster.dynamic_storage ? {} : var.aks.cluster.blobs
  metadata {
    name = "${local.name_prefix}-pv-${local.prefix_app_name}-${each.key}"
  }
  spec {
    access_modes = ["ReadWriteMany"]
    capacity = {
      storage = "${each.value.pv_size_gb}Gi"
    }
    storage_class_name = "azureblob-nfs-premium"
    persistent_volume_source {
      csi {
        driver        = "blob.csi.azure.com"
        volume_handle = "${local.name_prefix}-pv-${local.prefix_app_name}-${each.key}"
        read_only     = each.value.read_only
        volume_attributes = {
          "resourceGroup"  = var.storageaccount_rg_name
          "storageAccount" = var.storageaccount_data[each.value.storage_account_key].name
          "containerName"  = var.storageaccount_container_names["${each.value.container_key}-${each.value.storage_account_key}"]
          "protocol"       = each.value.protocol
        }
      }
    }
  }
  depends_on = [azurerm_kubernetes_cluster.aks]
}

resource "kubernetes_persistent_volume" "pv-disk" {
  for_each = var.aks.cluster.dynamic_storage ? {} : var.aks.cluster.managed_disks
  metadata {
    name = "${local.name_prefix}-pv-${local.prefix_app_name}-${each.key}"
  }
  spec {
    access_modes = ["ReadWriteOnce"]
    capacity = {
      storage = "${azurerm_managed_disk.managed-disks[each.key].disk_size_gb}Gi"
    }
    storage_class_name = "managed-csi"
    persistent_volume_source {
      azure_disk {
        disk_name     = azurerm_managed_disk.managed-disks[each.key].name
        data_disk_uri = azurerm_managed_disk.managed-disks[each.key].id
        caching_mode  = "None"
        kind          = "Managed"
      }
    }
  }
  depends_on = [azurerm_kubernetes_cluster.aks]
}

### Kubernetes Storage Classes if Storage option is dynamic ###

resource "kubernetes_storage_class" "sc_share" {
  for_each = var.aks.cluster.dynamic_storage ? var.aks.cluster.file_shares : {}
  metadata {
    name = "${local.name_prefix}-sc-${local.prefix_app_name}-${each.key}"
  }
  storage_provisioner    = "file.csi.azure.com"
  allow_volume_expansion = true # Works only for increasing size, not decreasing
  reclaim_policy         = each.value.reclaim_policy
  volume_binding_mode    = each.value.volume_binding_mode

  mount_options = each.value.mount_options

  parameters = {
    protocol               = each.value.protocol
    requireInfraEncryption = contains(["3", "4"], var.sbk) ? true : false
    skuName                = each.value.storage_account_type == null ? local.get_csi_driver_type : each.value.storage_account_type
    resourceGroup          = var.storageaccount_rg_name
    storageAccount         = var.storageaccount_data[each.value.storage_account_key].name
    networkEndpointType    = "privateEndpoint"
  }
}

resource "kubernetes_storage_class" "sc_blob" {
  for_each = var.aks.cluster.dynamic_storage ? var.aks.cluster.blobs : {}
  metadata {
    name = "${local.name_prefix}-sc-${local.prefix_app_name}-${each.key}"
  }
  storage_provisioner    = "blob.csi.azure.com"
  allow_volume_expansion = true # Works only for increasing size, not decreasingcy
  reclaim_policy         = each.value.reclaim_policy
  volume_binding_mode    = each.value.volume_binding_mode

  mount_options = each.value.mount_options

  parameters = {
    protocol            = each.value.protocol
    skuName             = each.value.storage_account_type == null ? local.get_csi_driver_type : each.value.storage_account_type
    resourceGroup       = var.storageaccount_rg_name
    storageAccount      = var.storageaccount_data[each.value.storage_account_key].name
    networkEndpointType = "privateEndpoint"
  }
  depends_on = [azurerm_kubernetes_cluster.aks]
}

resource "kubernetes_storage_class" "sc_disk" {
  for_each = var.aks.cluster.dynamic_storage ? var.aks.cluster.managed_disks : {}
  metadata {
    name = "${local.name_prefix}-sc-${local.prefix_app_name}-${each.key}"
  }
  storage_provisioner    = "disk.csi.azure.com"
  allow_volume_expansion = true # Works only for increasing size, not decreasing
  reclaim_policy         = each.value.reclaim_policy
  volume_binding_mode    = each.value.volume_binding_mode

  mount_options = each.value.mount_options

  parameters = {
    skuName                 = each.value.storage_account_type == null ? local.get_storage_account_type : each.value.storage_account_type
    resourceGroup           = azurerm_kubernetes_cluster.aks.node_resource_group
    fsType                  = each.value.fsType
    cachingMode             = each.value.cachingMode
    writeAcceleratorEnabled = (each.value.storage_account_type == "Premium_LRS" || local.get_storage_account_type == "Premium_LRS") ? each.value.writeAcceleratorEnabled : false
    enableBursting          = each.value.enableBursting
    diskEncryptionSetID     = contains(["3", "4"], var.sbk) ? azurerm_disk_encryption_set.disc-encryption-set[0].id : null
    diskEncryptionType      = contains(["3", "4"], var.sbk) ? "EncryptionAtRestWithCustomerKey" : null
  }
  depends_on = [azurerm_kubernetes_cluster.aks]
}


resource "azurerm_role_assignment" "cluster-access_network_contributor" {
  scope                = var.ntwspoke_rg_id
  role_definition_name = "Network Contributor"
  principal_id         = data.azurerm_client_config.current.object_id
}

resource "azurerm_role_assignment" "cluster-access-nodepool_network_contributor" {
  scope                = "/subscriptions/${data.azurerm_client_config.current.subscription_id}/resourceGroups/${local.name_prefix}-rg-${local.prefix_app_name}-aks-cluster_nodepool"
  role_definition_name = "Network Contributor"
  principal_id         = data.azurerm_client_config.current.object_id

  depends_on = [azurerm_kubernetes_cluster.aks]
}


#############################################################################################################################
#
# Backup TF Resources
#
#############################################################################################################################
resource "azurerm_kubernetes_cluster_trusted_access_role_binding" "aks_cluster_trusted_access" {
  kubernetes_cluster_id = azurerm_kubernetes_cluster.aks.id
  name                  = "trusted-cluster" # max. 20 chars
  roles                 = ["Microsoft.DataProtection/backupVaults/backup-operator"]
  source_resource_id    = var.bvault_id
}


resource "azurerm_storage_container" "container-aks-recovery" {
  name                  = "aksrecovery"
  storage_account_id    = var.storageaccount_recovery_id
  container_access_type = "private"
}

resource "time_sleep" "wait_300_seconds_before_aks_backup_extension" {
  create_duration = "300s"

  depends_on = [azurerm_kubernetes_cluster.aks]
}

resource "azurerm_kubernetes_cluster_extension" "aks-backup-extension" {
  name              = "aks-backup-extension"
  cluster_id        = azurerm_kubernetes_cluster.aks.id
  extension_type    = "Microsoft.DataProtection.Kubernetes"
  release_train     = "stable"
  release_namespace = "dataprotection-microsoft"
  configuration_settings = {
    "configuration.backupStorageLocation.bucket"                = azurerm_storage_container.container-aks-recovery.name
    "configuration.backupStorageLocation.config.resourceGroup"  = var.storageaccount_rg_recovery_name
    "configuration.backupStorageLocation.config.storageAccount" = var.storageaccount_recovery_name
    "configuration.backupStorageLocation.config.subscriptionId" = data.azurerm_client_config.current.subscription_id
    "credentials.tenantId"                                      = data.azurerm_client_config.current.tenant_id
    "configuration.backupStorageLocation.config.useAAD"         = true
  }
  depends_on = [time_sleep.wait_300_seconds_before_aks_backup_extension]
}

resource "azurerm_role_assignment" "extension_and_storage_account_permission" {

  scope                = var.storageaccount_rg_recovery_id
  role_definition_name = "Storage Account Contributor"
  principal_id         = azurerm_kubernetes_cluster_extension.aks-backup-extension.aks_assigned_identity[0].principal_id
}

resource "azurerm_role_assignment" "extension_and_storage_account_key_permission" {
  scope                = var.storageaccount_rg_recovery_id
  role_definition_name = "Storage Account Key Operator Service Role"
  principal_id         = azurerm_kubernetes_cluster_extension.aks-backup-extension.aks_assigned_identity[0].principal_id
}

resource "azurerm_role_assignment" "vault_msi_read_on_cluster" {
  scope                = azurerm_kubernetes_cluster.aks.id
  role_definition_name = "Reader"
  principal_id         = var.bvault_principal_id
}

resource "azurerm_role_assignment" "vault_msi_read_on_snap_rg" {
  scope                = var.storageaccount_rg_recovery_id
  role_definition_name = "Reader"
  principal_id         = var.bvault_principal_id
}

resource "azurerm_role_assignment" "vault_msi_snapshot_contributor_on_snap_rg" {
  scope                = var.storageaccount_rg_recovery_id
  role_definition_name = "Disk Snapshot Contributor"
  principal_id         = var.bvault_principal_id
}

resource "azurerm_role_assignment" "vault_data_operator_on_snap_rg" {
  scope                = var.storageaccount_rg_recovery_id
  role_definition_name = "Data Operator for Managed Disks"
  principal_id         = var.bvault_principal_id
}

resource "azurerm_role_assignment" "vault_data_contributor_on_storage" {
  scope                = var.storageaccount_rg_recovery_id
  role_definition_name = "Storage Blob Data Contributor"
  principal_id         = var.bvault_principal_id
}

resource "azurerm_role_assignment" "ext-msi_contributor_on_storage" {
  scope                = var.storageaccount_rg_recovery_id
  role_definition_name = "Storage Blob Data Contributor"
  principal_id         = azurerm_kubernetes_cluster_extension.aks-backup-extension.aks_assigned_identity[0].principal_id
}

resource "azurerm_role_assignment" "msi_access_for_postmodules_cluster_admin" {
  scope                = azurerm_resource_group.rg-aks.id
  role_definition_name = "Azure Kubernetes Service Cluster Admin Role"
  principal_id         = data.azurerm_client_config.current.object_id
}

resource "azurerm_role_assignment" "msi_access_for_postmodules_rbac_cluster_admin" {
  scope                = azurerm_resource_group.rg-aks.id
  role_definition_name = "Azure Kubernetes Service RBAC Cluster Admin"
  principal_id         = data.azurerm_client_config.current.object_id
}


resource "time_sleep" "wait_180_seconds_before_bkp_aks_instance" {
  create_duration = "180s"

  depends_on = [azurerm_kubernetes_cluster_extension.aks-backup-extension]
}

resource "azurerm_data_protection_backup_instance_kubernetes_cluster" "bkp-aks-instance" {
  name                         = "kbi-cluster"
  location                     = azurerm_resource_group.rg-aks.location
  vault_id                     = var.bvault_id
  kubernetes_cluster_id        = azurerm_kubernetes_cluster.aks.id
  snapshot_resource_group_name = var.storageaccount_rg_recovery_name
  backup_policy_id             = var.bvault_kubernetes_policy_id

  backup_datasource_parameters {
    excluded_namespaces              = [] # ["test-excluded-namespaces"]
    excluded_resource_types          = [] # ["exvolumesnapshotcontents.snapshot.storage.k8s.io"]
    cluster_scoped_resources_enabled = true
    included_namespaces              = [] # ["test-included-namespaces"]
    included_resource_types          = [] # ["involumesnapshotcontents.snapshot.storage.k8s.io"]
    label_selectors                  = [] # ["kubernetes.io/metadata.name:test"]
    volume_snapshot_enabled          = true
  }

  depends_on = [
    azurerm_kubernetes_cluster_extension.aks-backup-extension,
    time_sleep.wait_180_seconds_before_bkp_aks_instance,
    azurerm_role_assignment.extension_and_storage_account_permission,
    azurerm_role_assignment.vault_msi_read_on_cluster,
    azurerm_role_assignment.vault_msi_read_on_snap_rg,
    azurerm_role_assignment.vault_msi_snapshot_contributor_on_snap_rg,
    azurerm_role_assignment.vault_data_operator_on_snap_rg,
    azurerm_role_assignment.vault_data_contributor_on_storage,
    azurerm_role_assignment.ext-msi_contributor_on_storage,
    azurerm_role_assignment.extension_and_storage_account_key_permission
  ]
}

##############################################
#### Connection between aks and key vault ####
##############################################

resource "azurerm_user_assigned_identity" "mid" {
  for_each            = var.kubernetes.namespaces != null ? var.kubernetes.namespaces : {}
  location            = azurerm_resource_group.rg-aks.location
  name                = "${local.name_prefix}-mid-${each.value}-${local.prefix_app_name}"
  resource_group_name = azurerm_resource_group.rg-aks.name

  tags = var.tags

  lifecycle {
    ignore_changes = [
      tags["CreationDateTime"],
      tags["Owner"],
      tags["Environment"],
      tags["ITAB"],
      tags["AppName"],
      tags["AppEnv"],
      tags["SubscriptionType"],
      tags["PlatformId"],
      tags["Availability"],
      tags["Confidentiality"],
      tags["Integrity"]
    ]
  }
}

resource "azurerm_user_assigned_identity" "default-mid" {
  location            = azurerm_resource_group.rg-aks.location
  name                = "${local.name_prefix}-default-mid-${local.prefix_app_name}"
  resource_group_name = azurerm_resource_group.rg-aks.name

  tags = var.tags

  lifecycle {
    ignore_changes = [
      tags["CreationDateTime"],
      tags["Owner"],
      tags["Environment"],
      tags["ITAB"],
      tags["AppName"],
      tags["AppEnv"],
      tags["SubscriptionType"],
      tags["PlatformId"],
      tags["Availability"],
      tags["Confidentiality"],
      tags["Integrity"]
    ]
  }
}


resource "azurerm_role_assignment" "keyvault_access" {
  for_each             = var.kubernetes.namespaces != null ? var.kubernetes.namespaces : {}
  scope                = var.keyvault_keyvault_ids["app"]
  role_definition_name = "Key Vault Secrets User"
  principal_id         = azurerm_user_assigned_identity.mid[each.key].principal_id
}

#####################################################
#### Connection between aks and private dns zone ####
#####################################################

resource "azurerm_role_assignment" "pdns_access" {
  scope                = var.private_dns_zone_id
  role_definition_name = "Private DNS Zone Contributor"
  principal_id         = azurerm_user_assigned_identity.default-mid.principal_id
}



#############################################################################################################################
#### Managed Identity for application registration in DNS (AKS Managed NGINX / app routing add-on)
#############################################################################################################################

resource "azurerm_role_assignment" "mid_managed_nginx_add_on" {
  scope                = var.private_dns_zone_id
  role_definition_name = "Private DNS Zone Contributor"
  principal_id         = azurerm_kubernetes_cluster.aks.web_app_routing[0].web_app_routing_identity[0].object_id
}


#############################################
#### Connection between aks and postgres ####
#############################################

resource "time_sleep" "wait_45_seconds_before_psql_ad_admin" {
  create_duration = "45s"

  depends_on = [azurerm_user_assigned_identity.mid]
}

resource "azurerm_postgresql_flexible_server_active_directory_administrator" "postgres_active_directory_administrator" {
  for_each            = var.postgres_server_names != {} ? local.flatten_namespace_servers : {}
  server_name         = each.value.server_name_key
  resource_group_name = "${var.lbbw_location}-${var.infra_environment}-rg-${var.app_environment}${var.app_name}-psql"
  tenant_id           = data.azurerm_client_config.current.tenant_id
  object_id           = azurerm_user_assigned_identity.mid[each.value.namespace].principal_id
  principal_name      = azurerm_user_assigned_identity.mid[each.value.namespace].name
  principal_type      = "ServicePrincipal"

  depends_on = [
    azurerm_user_assigned_identity.mid,
    time_sleep.wait_45_seconds_before_psql_ad_admin
  ]
}

#############################################
#### Connection between aks and eventhub ####
#############################################
resource "azurerm_role_assignment" "eventhub_sender" {
  for_each             = var.kubernetes.namespaces != null ? var.kubernetes.namespaces : {}
  scope                = var.eventhub_rg_id
  role_definition_name = "Azure Event Hubs Data Sender"
  principal_id         = azurerm_user_assigned_identity.mid[each.key].principal_id
}

resource "azurerm_role_assignment" "eventhub_receiver" {
  for_each             = var.kubernetes.namespaces != null ? var.kubernetes.namespaces : {}
  scope                = var.eventhub_rg_id
  role_definition_name = "Azure Event Hubs Data Receiver"
  principal_id         = azurerm_user_assigned_identity.mid[each.key].principal_id
}