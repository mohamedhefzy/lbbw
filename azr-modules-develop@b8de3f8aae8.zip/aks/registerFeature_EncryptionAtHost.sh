#!/bin/bash
function check_registration() {
    output=$(az feature show --namespace Microsoft.Compute --name EncryptionAtHost  --query 'properties.state' -o tsv)
    if [ "$output" == "Registered" ]; then
        exit 0
    fi
}

check_registration
az feature register --namespace Microsoft.Compute --name EncryptionAtHost
for i in {1..20}
do
    check_registration
    sleep 60
done
exit 1
