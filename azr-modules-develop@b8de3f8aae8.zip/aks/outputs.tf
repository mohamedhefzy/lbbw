output "rg_id" {
  description = "The `azurerm_kubernetes_cluster`'s resource group id."
  value       = azurerm_resource_group.rg-aks.id
}

output "rg_name" {
  description = "The `azurerm_kubernetes_cluster`'s resource group name."
  value       = azurerm_resource_group.rg-aks.name
}

output "cluster_id" {
  description = "The `azurerm_kubernetes_cluster`'s id."
  value       = azurerm_kubernetes_cluster.aks.id
}

output "cluster_name" {
  description = "The `azurerm_kubernetes_cluster`'s name."
  value       = azurerm_kubernetes_cluster.aks.name
}

output "cluster_private_fqdn" {
  description = "The FQDN for the Kubernetes Cluster when private link has been enabled, which is only resolvable inside the Virtual Network used by the Kubernetes Cluster."
  value       = azurerm_kubernetes_cluster.aks.private_fqdn
}

output "cluster_oidc_issuer_url" {
  description = "The oidc issuer url of AKS"
  value       = azurerm_kubernetes_cluster.aks.oidc_issuer_url
}

output "user_assigned_identity_ids" {
  description = "The user assigned identity id"
  value       = { for k, v in azurerm_user_assigned_identity.mid : k => v.id }
}

output "user_assigned_identity_client_ids" {
  description = "The user assigned identity client_id"
  value       = { for k, v in azurerm_user_assigned_identity.mid : k => v.client_id }
}

output "user_assigned_identity_names" {
  description = "The user assigned identity name"
  value       = { for k, v in azurerm_user_assigned_identity.mid : k => v.name }
}

output "user_assigned_identity_default_mid_id" {
  description = "todo"
  value       = azurerm_user_assigned_identity.default-mid.id
}

output "user_assigned_identity_default_mid_client_id" {
  description = "todo"
  value       = azurerm_user_assigned_identity.default-mid.client_id
}

output "host" {
  description = "todo"
  value       = azurerm_kubernetes_cluster.aks.kube_admin_config.0.host
}

output "username" {
  description = "todo"
  value       = azurerm_kubernetes_cluster.aks.kube_admin_config.0.username
}

output "password" {
  description = "todo"
  value       = azurerm_kubernetes_cluster.aks.kube_admin_config.0.password
}

output "client_certificate" {
  description = "todo"
  value       = base64decode(azurerm_kubernetes_cluster.aks.kube_admin_config.0.client_certificate)
}

output "client_key" {
  description = "todo"
  value       = base64decode(azurerm_kubernetes_cluster.aks.kube_admin_config.0.client_key)
}

output "cluster_ca_certificate" {
  description = "todo"
  value       = base64decode(azurerm_kubernetes_cluster.aks.kube_admin_config.0.cluster_ca_certificate)
}