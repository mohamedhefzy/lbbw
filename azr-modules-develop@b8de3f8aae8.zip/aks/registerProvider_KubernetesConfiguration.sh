#!/bin/bash
function check_registration() {
    output=$(az provider show --namespace Microsoft.KubernetesConfiguration  --query 'registrationState' -o tsv)
    if [ "$output" == "Registered" ]; then
        exit 0
    fi
}

check_registration
az provider register --namespace Microsoft.KubernetesConfiguration
for i in {1..20}
do
    check_registration
    sleep 60
done
exit 1
