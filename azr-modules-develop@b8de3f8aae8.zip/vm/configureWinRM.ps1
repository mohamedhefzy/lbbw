﻿### Aktuell ein Workaround bis winrm über das Golden Image der VMIF richtig konfiguriert wird

param (
    [Parameter(ValuefromPipeline=$true,Mandatory=$true)] [string]$RESOURCE_GROUP_NAME,
    [Parameter(ValuefromPipeline=$true,Mandatory=$true)] [string]$VM_NAME,
    [Parameter(ValuefromPipeline=$true,Mandatory=$true)] [string]$LBBW_LOCATION,
    [Parameter(ValuefromPipeline=$true,Mandatory=$true)] [string]$PREFIX_APP_NAME,
    [Parameter(ValuefromPipeline=$true,Mandatory=$true)] [string]$INFRA_ENVIRONMENT_LONG
)

# Form the VM FQDN
$vm_fqdn = "$VM_NAME.$PREFIX_APP_NAME.$INFRA_ENVIRONMENT_LONG.$LBBW_LOCATION.azure.lbbw.cloud"
$dns_fqdn = "$PREFIX_APP_NAME.$INFRA_ENVIRONMENT_LONG.$LBBW_LOCATION.azure.lbbw.cloud"

Write-Host "VM FQDN: $vm_fqdn"
Write-Host "DNS Name: $dns_fqdn"
Write-Host "Resource Group Name: $RESOURCE_GROUP_NAME"
Write-Host "VM Name: $VM_NAME"
Write-Host "Location: $LBBW_LOCATION"
Write-Host "Prefix App Name: $PREFIX_APP_NAME"
Write-Host "Infra Environment Long: $INFRA_ENVIRONMENT_LONG"

### Set correct NV Domain Name for Entra Setup ###

$path = "HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters"

if (-not (Get-ItemProperty -Path $path -Name "NV Domain" -ErrorAction SilentlyContinue)) {
    New-ItemProperty -Path $path -Name "NV Domain" -PropertyType String -Value $dns_fqdn | Out-Null
} else {
    Set-ItemProperty -Path $path -Name "NV Domain" -Value $dns_fqdn -Type String
}


# Configure winrm on boot
winrm quickconfig -force

# Delete preconfigured winrm https listener
winrm delete winrm/config/listener?Address=*+Transport=HTTPS

# Create new https listener with newly created self-signed ssl cert
New-SelfSignedCertificate -DnsName "$vm_fqdn"-CertStoreLocation Cert:\LocalMachine\My -KeyUsage DigitalSignature, KeyEncipherment -Type SSLServerAuthentication
$thumbprint = (Get-ChildItem -Path Cert:\LocalMachine\My | Where-Object {$_.Subject -match "CN=$vm_fqdn"}).Thumbprint
New-WSManInstance -ResourceURI winrm/config/Listener -SelectorSet @{Address="*"; Transport="HTTPS"} -ValueSet @{Hostname="$vm_fqdn"; CertificateThumbprint="$thumbprint"}

# Restart winrm service
Restart-Service WinRM

# Output winrm listeners
winrm enumerate winrm/config/listener


# initialize Windows Disks. This will be a scheduled task that regularly runs, due to issues with multiple disks, and also in case a disk gets added to the VM later on.
' 
# Gets every disk BUT the OS/Boot Disk, which should be every attached disk
$uninitializedDisks = Get-Disk | Where-Object {
    $_.IsSystem -eq $false -and $_.IsBoot -eq $false -and $_.PartitionStyle -eq "RAW"
}
foreach($disk in $uninitializedDisks) {
    Initialize-Disk -Number $disk.Number -PartitionStyle GPT -Confirm:$false
    #Die Initialisierung kann ein paar Sekunden dauern, weshalb ein kurzer Sleep benötigt ist, um eine Race Condition zu verhindern.
    #Wartet man nicht, ist die Initialisierung oft noch nicht abgeschlossen, die nächsten Schritte werden nicht ausgeführt und man muss die Disk mit "Clear-Disk --RemoveData" zurücksetzen (oder eine Fallunterscheidung implementieren)
    $initialized = $false 
    while (-not $initialized) {
        $initializedDisk = Get-Disk -Number $disk.Number
        Start-Sleep -Seconds 5
        if ($initializedDisk.PartitionStyle -ne "RAW") {
            $initialized = $true
        }
    }

    New-Partition -DiskNumber $disk.Number -UseMaximumSize -AssignDriveLetter | Format-Volume -FileSystem NTFS -Confirm:$false
}
' | Out-File -filepath C:\ProgramData\initializeManagedDisks.ps1

# Set up the scheduled task to regularly run the script

$action = New-ScheduledTaskAction -Execute "powershell.exe" -Argument '-ExecutionPolicy Bypass -File "C:\ProgramData\initializeManagedDisks.ps1"' -WorkingDirectory "C:\ProgramData"
$trigger = New-ScheduledTaskTrigger -Once -At (Get-Date) -RepetitionInterval (New-TimeSpan -Minutes 15)
# Sadly needs RunLevel Highest because all the disk management stuff needs admin permissions
Register-ScheduledTask -TaskName "InitializeManagedDisks" -Action $action -Trigger $trigger -RunLevel Highest -User "SYSTEM" -Force

shutdown /r /d p:2:4 /c "Restart for Domain Name setup registry change" /t 0