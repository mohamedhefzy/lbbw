# VM

This module is used to deploy multiple linux VMs or Windows VMs [Linux VM](https://azure.microsoft.com/en-us/products/virtual-machines/linux/)
[Windows VM](https://azure.microsoft.com/en-us/products/virtual-machines/windows/).

## Created Resources

This module creates the following resources on azure

- ``azurerm_resource_group.rg-vm``: A resource group where the following resources are located.
- ``azurerm_availability_set.availability-set``: The availability set. This resource is optional. 
- ``azurerm_disk_encryption_set.disc-encryption-set``: The disc encryption set is created if sbk is 3 or 4.
- ``azurerm_role_assignment.kv-des-crypto-encryp``: The role assignment gives the authorization to perform encyption and decryption operations.
// for linux
- ``azurerm_linux_virtual_machine.linux-vm``: The linux vm
- ``azurerm_key_vault_secret.password_entries_linux``: The password of the linux vm which is stored in the key vault.
- ``azurerm_virtual_machine_extension.linux_aad_login``: Extension for aad login.
- ``azurerm_marketplace_agreement.ama-linux``: The azure marketplace agreement.
// for windows
- ``azurerm_windows_virtual_machine.windows-vm``: The windows vm 
- ``azurerm_key_vault_secret.password_entries_windows``: The password of the windows vm which is stored in the key vault. 
- ``azurerm_virtual_machine_extension.windows_aad_login``: Extension for aad login.
- ``azurerm_marketplace_agreement.ama-windows``: The azure marketplace agreement.

- ``azurerm_network_interface.nic``: The network interface.
// backup
``azurerm_backup_policy_vm.policy-vm``: The resource defines the policy of the backup.
``azurerm_backup_protected_vm.protected-windows-vm``: The connection between windows vm, policy and rs vault.
``azurerm_backup_protected_vm.protected-linux-vm``: The connection between linux vm, policy and rs vault.
// managed disk
- ``azurerm_managed_disk.managed-disk-windows``: The managed disk for windows vms.
- ``azurerm_virtual_machine_data_disk_attachment.disk-attachement_windows``: The attachement of the disk with the windows vm.
- ``azurerm_managed_disk.managed-disk-linux``: The managed disk for linux vms.
- ``azurerm_virtual_machine_data_disk_attachment.disk-attachement_linux``: The attachement of the disk with the linux vm.


## Variables



| Name               | Description                                                               | Type   |
| ------------------ | ------------------------------------------------------------------------- | -------|
| app_environment | This variable defines the app environment of the specific application. Placeholder is 'x' if nothing is set. | string |
| app_name | Name of the application per subscription. | string |
| app_type | Type of app (shared, spoke...) | string |
| lbbw_location | LBBW Location | string |
| location | Azure location | string |
| infra_environment | This variable defines the environment to be built. (Prod,Cert,Dev,Engineering). | string |
| sbk | This variable defines the 'Schutzbedarfsklasse' (1, 2, 3, 4). | string |
| availability | The variable defines the availability (V1, V2, V3, V4). | string |
| patchwindow | This variable defines the patchwindow (Option1, Option2, Option3). | string |
| backupretention | This variable defines the backupretention (SHORT, MID, LONG). | string |
| rsvault_name | The name of the rsvault. | string |
| rsvault_rg_name | The name of the resource group where the rsvault is located. | string |
| subnet_ids | The ids of the subnet. | map(string) |
| keyvault_encryption_key_id | The id of the key that is used for disk encryption. | string |
| platform_keyvault_id | The id of the keyvault that contains the passwords and secrets. | string |
| vm | The configuration of the vms. | object |
| tags | Map of Tags per subscription. | map(string) |


### VM Model

Model Deployments are described in a list of objects of the following structure:

```
vm = {
    is_aad_active = bool
    availability_sets = map({
      platform_fault_domain_count  = number
      platform_update_domain_count = number
    })
    network_interfaces = map({
      subnet_key_name = string
    })
    linux = map({
      nic_id_key                      = string
      size                            = string
      admin_username                  = string
      zone                            = number
      availability_set_name           = string
      disable_password_authentication = bool
      managed_disks = map({
        tier         = string
        disk_size_gb = string
      })
      os_disk = {
        caching = string
      }
      custom_image_reference = {
        image_name     = string
        version        = string
        version_reason = string
      }
    })
    windows = map({
      nic_id_key            = string
      size                  = string
      admin_username        = string
      admin_password        = string
      zone                  = number
      availability_set_name = string
      managed_disks = map({
        tier         = string
        disk_size_gb = string
      })
      os_disk = {
        caching = string
      }
      custom_image_reference = {
        image_name     = string
        version        = string
        version_reason = string
      }
    })
}

```

## Output

| Name             | Description                                                                                                       |
| ---------------- | ----------------------------------------------------------------------------------------------------------------- |
| kv_ids           | The ids of the key vaults                                                                                         |
| encryp_key_ids   | Endpoint of this cognitive account
| vm_passwords_linux | List of the linux passwords. |
| vm_passwords-windows | List of the windows passwords. |
| vm_linux_ids | List of the linux ids. |
| vm_windows_ids | List of the windows ids. |
| backup_policy_name | The names of the policy. (Tests) |
| nic_names | The names of the network interfaces. (Tests) |
| disk_encryption_set | The disk encryption set. (Tests) |

## Required Modules
- ntwspoke
- keyvault
- rsvault
- bvault
