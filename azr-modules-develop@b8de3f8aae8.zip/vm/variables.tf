variable "is_old_tenant" {
  description = ""
  type        = bool
}

variable "app_environment" {
  description = "This variable defines the app environment of the specific application. Placeholder is 'x' if nothing is set."
  type        = string
}

variable "app_name" {
  description = "Name of the application per subscription"
  type        = string
}

variable "app_type" {
  description = "Type of app (shared, spoke...)"
  type        = string
}

variable "lbbw_location" {
  description = "LBBW Location"
  type        = string
}

variable "location" {
  description = "Azure location"
  type        = string
}

variable "infra_environment" {
  description = "This variable defines the environment to be built. (Prod,Cert,Dev,Engineering)."
  type        = string
}

variable "sbk" {
  description = "This variable defines the 'Schutzbedarfsklasse' (1, 2, 3, 4)"
  type        = string
}

variable "availability" {
  description = "The variable defines the availability (V1, V2, V3, V4)"
  type        = string
}

variable "rsvault_name" {
  description = "The name of the rsvault."
  type        = string
}

variable "rsvault_rg_name" {
  description = "The name of the resource group where the rsvault is located"
  type        = string
}

variable "rsvault_vm_policy_id" {
  description = "The id of the vm-policy in the rsvault"
  type        = string
}

variable "bvault_id" {
  description = "The id of the bvault."
  type        = string
}

variable "bvault_disk_policy_id" {
  description = "ID of the disk Policy in the bvault"
  type        = string
}

variable "bvault_principal_id" {
  description = "The principal id of the bvault"
  type        = string
}

variable "subnet_ids" {
  description = "The ids of the subnet"
  type        = map(string)
}

variable "keyvault_encryption_key_id" {
  description = "The id of the key that is used for disk encryption"
  type        = string
}

variable "keyvault_keyvault_ids" {
  description = "The ids of the ke vaults"
  type        = map(string)
}

variable "platform_keyvault_id" {
  description = "The id of the keyvault that contains the passwords and secrets"
  type        = string
}

variable "mssql_user_assigned_identity_ids" {
  description = "The user assigned identity ids of the mssql servers"
  type        = map(string)
}

variable "vm" {
  description = "The configuration of the vms"
  type = object({
    is_aad_active = bool
    availability_sets = map(object({
      platform_fault_domain_count  = number
      platform_update_domain_count = number
    }))
    network_interfaces = map(object({
      subnet_key_name = string
    }))
    linux = map(object({
      nic_id_key                      = string
      size                            = string
      admin_username                  = string
      vtpm_enabled                    = bool
      zone                            = number
      availability_set_name           = string
      disable_password_authentication = bool
      managed_disks = map(object({
        tier                 = string
        disk_size_gb         = string
        storage_account_type = string
      }))
      os_disk = object({
        disk_size_gb         = string
        storage_account_type = string
        caching              = string
      })
      custom_image_reference = object({
        image_name     = string
        version        = string
        version_reason = string
      })
    }))
    windows = map(object({
      nic_id_key            = string
      size                  = string
      admin_username        = string
      admin_password        = string
      vtpm_enabled          = bool
      zone                  = number
      availability_set_name = string
      managed_disks = map(object({
        tier                 = string
        disk_size_gb         = string
        storage_account_type = string
      }))
      os_disk = object({
        disk_size_gb         = string
        storage_account_type = string
        caching              = string
      })
      custom_image_reference = object({
        image_name     = string
        version        = string
        version_reason = string
      })
    }))
  })
}

variable "tags" {
  description = "Map of Tags per subscription"
  type        = map(string)
}