
run "execute_linux_sbk1" {
  module {
    source = "./setup/linux_sbk1"
  }

  command = plan

  assert {
    condition     = length(module.vm.vm_linux_ids) == 1
    error_message = "Count of linux vms does not match."
  }

  assert {
    condition     = length(module.vm.vm_windows_ids) == 0
    error_message = "Count of windows vms does not match."
  }

  assert {
    condition     = module.vm.nic_names.l1nic == "euho-e-nic-xtest-l1nic"
    error_message = "The nic name does not match"
  }

  assert {
    condition     = length(module.vm.disk_encryption_set) == 0
    error_message = "The count of disk encyption set does not match."
  }
}


run "execute_linux_sbk3" {
  module {
    source = "./setup/linux_sbk3"
  }

  command = plan

  assert {
    condition     = length(module.vm.disk_encryption_set) == 1
    error_message = "The count of disk encyption set does not match."
  }

  assert {
    condition     = length(module.vm.vm_linux_ids) == 1
    error_message = "Count of linux vms does not match."
  }

  assert {
    condition     = length(module.vm.vm_windows_ids) == 0
    error_message = "Count of windows vms does not match."
  }
}

run "execute_windows_sbk1" {
  module {
    source = "./setup/windows_sbk1"
  }

  command = plan

  assert {
    condition     = length(module.vm.vm_windows_ids) == 1
    error_message = "Count of windows vms does not match."
  }

  assert {
    condition     = length(module.vm.vm_linux_ids) == 0
    error_message = "Count of linux vms does not match."
  }

  assert {
    condition     = module.vm.nic_names.w1nic == "euho-e-nic-xtest-w1nic"
    error_message = "The nic name does not match"
  }
}

run "execute_windows_sbk3" {
  module {
    source = "./setup/windows_sbk3"
  }

  command = plan

  assert {
    condition     = length(module.vm.disk_encryption_set) == 1
    error_message = "The count of disk encyption set does not match."
  }

  assert {
    condition     = length(module.vm.vm_windows_ids) == 1
    error_message = "Count of windows vms does not match."
  }

  assert {
    condition     = length(module.vm.vm_linux_ids) == 0
    error_message = "Count of linux vms does not match."
  }
}
