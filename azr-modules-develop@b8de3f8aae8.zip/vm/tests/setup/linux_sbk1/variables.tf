variable "app_environment" {
  type    = string
  default = "x"
}
variable "app_name" {
  type    = string
  default = "test"
}
variable "app_type" {
  type    = string
  default = "spoke"
}
variable "lbbw_location" {
  type    = string
  default = "euho"
}
variable "location" {
  type    = string
  default = "westeurope"
}
variable "infra_environment" {
  type    = string
  default = "e"
}

variable "sbk" {
  type    = string
  default = "1"
}

variable "availability" {
  type    = string
  default = "V1"
}