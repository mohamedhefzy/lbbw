provider "azurerm" {
  features {}
  subscription_id = "541ac1c2-8b44-4aac-abdf-3ce58dd8f753"
}

module "vm" {
  source = "../../../"

  app_name          = var.app_name
  app_type          = var.app_type
  app_environment   = var.app_environment
  infra_environment = var.infra_environment
  lbbw_location     = var.lbbw_location
  location          = var.location
  sbk               = var.sbk
  availability      = var.availability

  tags = {
    source         = "terraform"
    environment    = "development"
    "ITAB"         = "7656"
    "AppName"      = "test"
    "Owner"        = "test"
    "Creator"      = "iac-admin"
    "ServerRole"   = "container-platform"
    "CreationDate" = "auto-generated"
  }



  # module specific variables
  subnet_ids = { snet1 : "/subscriptions/xxx-xxx-xxx-xxx-xxx/resourceGroups/euho-e-rg-xtest-ntw/providers/Microsoft.Network/virtualNetworks/euho-e-vnet-xtest/subnets/snet1" }


  keyvault_encryption_key_id = "https://euho-e-kv-xtest-encryp.vault.azure.net/keys/kvk-xtest-vm/1249e07110964e6c8b4499cf943e8aba"

  platform_keyvault_id = "/subscriptions/12345678-1234-9876-4563-123456789012/resourceGroups/example-resource-group/providers/Microsoft.KeyVault/vaults/vaultValue"
  rsvault_name         = "rsvaultname"
  rsvault_rg_name      = "rg_rsvault_name"

  vm = {
    is_aad_active     = true
    availability_sets = null
    network_interfaces = {
      l1nic = {
        subnet_key_name = "snet1"
      }
    }
    linux = {
      l1 = {
        nic_id_key                      = "l1nic"
        size                            = "Standard_D2s_v5"
        admin_username                  = "adminuser"
        zone                            = 2
        availability_set_name           = null
        disable_password_authentication = false
        managed_disks                   = {}
        os_disk = {
          caching = "ReadWrite"
        }
        custom_image_reference = {
          image_name     = "cis-redhat8-l1-gen2"
          version        = null
          version_reason = null
        }
      }
    }
    windows = {}
  }
}