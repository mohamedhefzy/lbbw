### Linux Outputs ###

output "vm_passwords_linux" {
  value       = { for k, v in random_password.vm_passwords_linux : k => v.result }
  description = "The passwords for the Linux VMs, which are randomly generated."
  sensitive   = true
}

output "vm_linux_ids" {
  value       = { for k, v in azurerm_linux_virtual_machine.linux-vm : k => v.id }
  description = "The linux vm ids."
}

output "vm_linux_ips" {
  value       = { for k, v in azurerm_linux_virtual_machine.linux-vm : k => v.private_ip_address }
  description = "The linux vms primary private ip address."
}

### Windows Outputs ###

output "vm_passwords_windows" {
  value       = { for k, v in random_password.vm_passwords_windows : k => v.result }
  description = "The passwords for the Windows VMs, which are randomly generated."
  sensitive   = true
}

output "vm_windows_ids" {
  value       = { for k, v in azurerm_windows_virtual_machine.windows-vm : k => v.id }
  description = "The windows vm ids."
}

output "vm_windows_ips" {
  value       = { for k, v in azurerm_windows_virtual_machine.windows-vm : k => v.private_ip_address }
  description = "The windows vms primary private ip address."
}

###

output "nic_names" {
  value = { for k, v in azurerm_network_interface.nic : k => v.name }
}

output "disk_encryption_set" {
  value = azurerm_disk_encryption_set.disc-encryption-set
}