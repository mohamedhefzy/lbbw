locals {
  name_prefix     = "${var.lbbw_location}-${var.infra_environment}"
  prefix_app_name = "${var.app_environment}${var.app_name}"

  infra_environment_long = var.infra_environment == "e" ? "eng" : (var.infra_environment == "d" ? "dev" : (var.infra_environment == "c" ? "cert" : (var.infra_environment == "p" ? "prod" : "unknown")))

  windows_agreements = toset(compact([for k, v in var.vm.windows : local.IMAGE_PLANS[v.custom_image_reference.image_name] == null ? null : v.custom_image_reference.image_name]))
  linux_agreements   = toset(compact([for k, v in var.vm.linux : local.IMAGE_PLANS[v.custom_image_reference.image_name] == null ? null : v.custom_image_reference.image_name]))

  IMAGE_VERSIONS = {
    "cis-redhat8-l1-gen2" : "3018.20250718.150000",
    "cis-redhat9-l1-gen2" : "208.20250718.150000",
    "cis-windows-server2022-l1-gen2" : "401.20250911.121000",
    # "rh-rhel810-non-cis" : "810.20240725.090000",
    # "rh-rhel89-non-cis" : "89.20240904.1030",
    "non-cis-rhel8-gen2" : "810.20250718.150000",
    "cis-rhel8-l1s-gen2" : "810.20250718.150000",
    "cis-rhel9-l1s-gen2" : "96.20250718.150000"
  }

  ### Set IMAGE_PLANS null IF image is a non-marketplace image e.g. Image Factory (vmif) ###
  IMAGE_PLANS = {
    "cis-redhat8-l1-gen2" : {
      publisher = "center-for-internet-security-inc",
      name      = "cis-redhat8-l1-gen2",
      product   = "cis-rhel"
    },
    "cis-redhat9-l1-gen2" : {
      publisher = "center-for-internet-security-inc",
      name      = "cis-redhat9-l1-gen2",
      product   = "cis-rhel"
    },
    "cis-windows-server2022-l1-gen2" : {
      publisher = "center-for-internet-security-inc",
      name      = "cis-windows-server2022-l1-gen2",
      product   = "cis-windows-server"
    },
    "non-cis-rhel8-gen2" : null,
    "cis-rhel8-l1s-gen2" : null,
    "cis-rhel9-l1s-gen2" : null
  }

  windows_managed_disks_flatten = {
    for w in(flatten([
      for windows_key, windows in var.vm.windows : [
        for managed_disk_key, managed_disk in windows.managed_disks : {
          key                  = "${windows_key}-${managed_disk_key}"
          windows_key          = windows_key
          tier                 = managed_disk.tier
          disk_size_gb         = managed_disk.disk_size_gb
          storage_account_type = managed_disk.storage_account_type
          zone                 = windows.zone
        }
      ]
    ])) : w.key => w
  }

  windows_indices = { for k, m in local.windows_managed_disks_flatten : k => index(keys(local.windows_managed_disks_flatten), k) }

  linux_managed_disks_flatten = {
    for l in(flatten([
      for linux_key, linux in var.vm.linux : [
        for managed_disk_key, managed_disk in linux.managed_disks : {
          key                  = "${linux_key}-${managed_disk_key}"
          linux_key            = linux_key
          disk_size_gb         = managed_disk.disk_size_gb
          tier                 = managed_disk.tier
          storage_account_type = managed_disk.storage_account_type
          zone                 = linux.zone
        }
      ]
    ])) : l.key => l
  }

  linux_indices = { for k, m in local.linux_managed_disks_flatten : k => index(keys(local.linux_managed_disks_flatten), k) }

  // todo check c
  image_subscription_id = {
    e = "48e3edb9-fa47-48b7-a560-de5de8a74c8b"
    d = "4027a13f-edff-41f3-a3e7-1b372710b54a"
    c = "cert_sub_id"
    p = "0e8e5df5-1cc9-48d8-a7d4-c55464f18858"
  }

  image_subscription_id_new_tenant = {
    e = "b8dbaa38-a324-4761-9255-a37938c142cb/resourceGroups/${var.lbbw_location}-e-rg-vmif-gal/providers/Microsoft.Compute/galleries/${var.lbbw_location}egalvmif"
    d = "19953fdc-494c-4fb5-bed0-e0323b4ffe48/resourceGroups/${var.lbbw_location}-p-rg-vmif-gal/providers/Microsoft.Compute/galleries/${var.lbbw_location}pgalvmif"
    c = "19953fdc-494c-4fb5-bed0-e0323b4ffe48/resourceGroups/${var.lbbw_location}-p-rg-vmif-gal/providers/Microsoft.Compute/galleries/${var.lbbw_location}pgalvmif"
    p = "19953fdc-494c-4fb5-bed0-e0323b4ffe48/resourceGroups/${var.lbbw_location}-p-rg-vmif-gal/providers/Microsoft.Compute/galleries/${var.lbbw_location}pgalvmif"
  }

  get_storage_account_type = var.availability == "V1" ? "Standard_LRS" : var.availability == "V2" ? "StandardSSD_LRS" : "Premium_LRS"
}
