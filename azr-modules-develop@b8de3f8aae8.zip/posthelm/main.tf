provider "kubernetes" {
  host                   = var.cluster_config.host
  username               = var.cluster_config.username
  password               = var.cluster_config.password
  client_certificate     = var.cluster_config.client_certificate
  client_key             = var.cluster_config.client_key
  cluster_ca_certificate = var.cluster_config.cluster_ca_certificate
}

resource "kubernetes_secret" "dynatrace_secret" {
  metadata {
    name      = "${var.lbbw_location}-${var.infra_environment}-aks-${var.app_environment}${var.app_name}-cluster"
    namespace = "dynatrace"
  }
  data = {
    apiToken = "${var.dynatrace_token}"
  }
  type = "Opaque"
}

resource "kubernetes_manifest" "dynakube" {
  manifest = {
    apiVersion = "dynatrace.com/v1beta5"
    kind       = "DynaKube"

    metadata = {
      name      = "${var.lbbw_location}-${var.infra_environment}-aks-${var.app_environment}${var.app_name}-cluster"
      namespace = "dynatrace"
      annotations = {
        "feature.dynatrace.com/k8s-app-enabled"           = "true"
        "feature.dynatrace.com/injection-readonly-volume" = "true"
      }
    }
    spec = {
      apiUrl = "https://${var.dynatrace_tenant_id}.live.dynatrace.com/api"
      metadataEnrichment = {
        enabled = true
      }
      oneAgent = {
        cloudNativeFullStack = {
          tolerations = [
            {
              effect   = "NoSchedule"
              operator = "Exists"
            }
          ]
          oneAgentResources = {
            requests = {
              cpu    = "${var.posthelm.dynakube.oneAgent.cloudNativeFullStack.oneAgentResources.requests.cpu}"
              memory = "${var.posthelm.dynakube.oneAgent.cloudNativeFullStack.oneAgentResources.requests.memory}"
            }
            limits = {
              cpu    = "${var.posthelm.dynakube.oneAgent.cloudNativeFullStack.oneAgentResources.limits.cpu}"
              memory = "${var.posthelm.dynakube.oneAgent.cloudNativeFullStack.oneAgentResources.limits.memory}"
            }
          }
        }
        hostGroup = "${var.lbbw_location}-${var.infra_environment}-${var.app_environment}-${var.app_name}"
      }
      activeGate = {
        capabilities = [
          "routing",
          "kubernetes-monitoring"
        ]
        tolerations = [
          {
            effect   = "NoSchedule"
            operator = "Exists"
          }
        ]
        nodeSelector = {
          nodepool = "default"
        }
        resources = {
          requests = {
            cpu    = "${var.posthelm.dynakube.activeGate.resources.requests.cpu}"
            memory = "${var.posthelm.dynakube.activeGate.resources.requests.memory}"
          }
          limits = {
            cpu    = "${var.posthelm.dynakube.activeGate.resources.limits.cpu}"
            memory = "${var.posthelm.dynakube.activeGate.resources.limits.memory}"
          }
        }
      }
    }
  }
}
