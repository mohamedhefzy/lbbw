variable "app_environment" {
  description = "This variable defines the app environment of the specific application. Placeholder is 'x' if nothing is set."
  type        = string
}

variable "app_name" {
  description = "Name of the application per subscription"
  type        = string
}

variable "infra_environment" {
  description = "This variable defines the environment to be built. (Prod,Cert,Dev,Engineering)."
  type        = string
}

variable "lbbw_location" {
  description = "LBBW Location"
  type        = string
}

variable "cluster_config" {
  description = "Kubernetes Cluster Konfigurationsdetails"
  type = object({
    host                   = string
    username               = string
    password               = string
    client_certificate     = string
    client_key             = string
    cluster_ca_certificate = string
  })
}

variable "dynatrace_token" {
  description = "The dynatrace token"
  type        = string
}

variable "dynatrace_tenant_id" {
  description = "The dynatrace tenant id."
  type        = string
}

variable "posthelm" {
  description = "The dynakube configuration for the dynatrace operator"
  type = object({
    dynakube = optional(object({
      oneAgent = optional(object({
        cloudNativeFullStack = optional(object({
          oneAgentResources = optional(object({
            requests = optional(object({
              cpu    = optional(string, "0m")
              memory = optional(string, "0Mi")
            }), {})
            limits = optional(object({
              cpu    = optional(string, "300m")
              memory = optional(string, "1.5Gi")
            }), {})
          }), {})
        }), {})
      }), {})
      activeGate = optional(object({
        resources = optional(object({
          requests = optional(object({
            cpu    = optional(string, "0m")
            memory = optional(string, "0Mi")
          }), {})
          limits = optional(object({
            cpu    = optional(string, "300m")
            memory = optional(string, "1.5Gi")
          }), {})
        }), {})
      }), {})
    }), {})
  })
  default = {}
}