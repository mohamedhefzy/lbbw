# Postgres

This module is used to deploy helm resources in the aks.

## Created Resources

This module creates the following resources

``kubernetes_secret``: A kubernetes secrets that contains the dynatrace token.
``kubernetes_manifest``: Deploys the dynakube.


## Variables

| Name               | Description                                                               | Type   |
| ------------------ | --------------------------------------------------------------------------| -------|
| app_environment | This variable defines the app environment of the specific application. Placeholder is 'x' if nothing is set. | string |
| app_name | Name of the application per subscription. | string |
| infra_environment |  This variable defines the environment to be built. (Prod,Cert,Dev,Engineering). | string |
| lbbw_location | LBBW Location | string |
| cluster_config | The cluster config of the aks. | object |
| dynatrace_token | The dynatrace token. | string |
| dynatrace_tenant_id | The dynatrace tenant id. | string |



### Helm Model

Model Deployments are described in a list of objects of the following structure:

```
```

### Output

| Name                 | Description                                                                                                       |
| -------------------- | ----------------------------------------------------------------------------------------------------------------- |

## Required Modules
- aks
- kubernetes
- dynatrace helm chart