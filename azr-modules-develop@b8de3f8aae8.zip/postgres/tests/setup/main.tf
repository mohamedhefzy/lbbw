provider "azurerm" {
  features {}
  subscription_id = "541ac1c2-8b44-4aac-abdf-3ce58dd8f753"
}


module "postgres_server" {

  source = "../../"


  app_name          = var.app_name
  app_type          = var.app_type
  app_environment   = var.app_environment
  infra_environment = var.infra_environment
  lbbw_location     = var.lbbw_location
  location          = var.location
  sbk               = var.sbk

  tags = {
    source         = "terraform"
    environment    = "development"
    "ITAB"         = "7656"
    "AppName"      = "test"
    "Owner"        = "test"
    "Creator"      = "iac-admin"
    "ServerRole"   = "container-platform"
    "CreationDate" = "auto-generated"
  }



  keyvault_encryption_key_id = "https://euho-e-kv-xtest-encryp.vault.azure.net/keys/kvk-xtest-postgres/1249e07110964e6c8b4499cf943e8aba"
  bvault_id                  = "/subscriptions/541ac1c2-8b44-4aac-abdf-3ce58dd8f753/resourceGroups/euho-e-rg-xtest-bvault/providers/Microsoft.DataProtection/backupVaults/euho-e-bvault-xtest"
  bvault_principal_id        = "254bb5ec-5386-4a9a-83f6-356f3b32c71b"
  bvault_psql_policy_id      = "/subscriptions/541ac1c2-8b44-4aac-abdf-3ce58dd8f753/resourceGroups/euho-e-rg-xtest-bvault/providers/Microsoft.DataProtection/backupVaults/euho-e-bvault-xtest/backupPolicies/bkpol-psql"
  snet_ids                   = { snet1 : "/subscriptions/541ac1c2-8b44-4aac-abdf-3ce58dd8f753/resourceGroups/euho-e-rg-xtest-ntw/providers/Microsoft.Network/virtualNetworks/euho-e-vnet-xtest/subnets/snet1" }
  vnet_id                    = "/subscriptions/541ac1c2-8b44-4aac-abdf-3ce58dd8f753/resourceGroups/euho-e-rg-xtest-ntw/providers/Microsoft.Network/virtualNetworks/euho-e-vnet-xtest"


  postgres_servers = {
    config = {
      main = {
        postgres_version              = "16"
        subnet_key_name               = "snet1"
        public_network_access_enabled = false
        administrator_login           = "Psql1234"
        administrator_password        = "TEst123"
        storage_mb                    = "65536"
        storage_tier                  = "P10"
        sku_name                      = "GP_Standard_D2ds_v5"
        auto_grow_enabled             = false

        authentication = {
          active_directory_auth_enabled = false
        }
        high_availability = {
          mode = "SameZone"
        }
      }
    }
  }
}