run "execute" {
  module {
    source = "./setup"
  }

  command = plan

  assert {
    condition     = module.postgres_server.postgres_server_names.main == "euho-e-psql-xtest-main"
    error_message = "The name of the storage account does not match."
  }

  assert {
    condition     = module.postgres_server.private_dns_zone_name == "psql.e.euho.xtest.postgres.database.azure.com"
    error_message = "The private dns zone doese not match."
  }
  assert {
    condition     = module.postgres_server.vnet_link_name == "exampleVnetZone.com"
    error_message = "The private vnet link name does not match."
  }
}