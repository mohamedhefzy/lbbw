locals {
  default_tags = {
    app_environment = var.app_environment
  }
  name_prefix     = "${var.lbbw_location}-${var.infra_environment}"
  prefix_app_name = "${var.app_environment}${var.app_name}"

  backup_options = {
    Option1 = {
      e = {
        weekdays          = ["Tuesday"]
        weekday_as_number = "02"
        time              = "13:00"
      }
      d = {
        weekdays          = ["Tuesday"]
        weekday_as_number = "02"
        time              = "13:00"
      }
      c = {
        weekdays          = ["Tuesday"]
        weekday_as_number = "02"
        time              = "13:00"
      }
      p = {
        weekdays          = ["Tuesday"]
        weekday_as_number = "02"
        time              = "15:00"
      }
    }
    Option2 = {
      e = {
        weekdays          = ["Wednesday"]
        weekday_as_number = "03"
        time              = "13:00"
      }
      d = {
        weekdays          = ["Wednesday"]
        weekday_as_number = "03"
        time              = "13:00"
      }
      c = {
        weekdays          = ["Wednesday"]
        weekday_as_number = "03"
        time              = "13:00"
      }
      p = {
        weekdays          = ["Thursday"]
        weekday_as_number = "04"
        time              = "15:00"
      }
    }
    Option3 = {
      e = {
        weekdays          = ["Thursday"]
        weekday_as_number = "04"
        time              = "13:00"
      }
      d = {
        weekdays          = ["Thursday"]
        weekday_as_number = "04"
        time              = "13:00"
      }
      c = {
        weekdays          = ["Thursday"]
        weekday_as_number = "04"
        time              = "13:00"
      }
      p = {
        weekdays          = ["Saturday"]
        weekday_as_number = "06"
        time              = "04:00"
      }
    }
  }

  private_dns_zone_id = {
    e = "/subscriptions/3da49d2d-46fc-4deb-a3aa-57cbc662e092/resourceGroups/euho-e-rg-privatednszones/providers/Microsoft.Network/privateDnsZones/"
    d = "/subscriptions/ceeadf22-6dcf-47f7-a232-818623b3afdc/resourceGroups/euho-p-rg-privatednszones/providers/Microsoft.Network/privateDnsZones/"
    c = "/subscriptions/ceeadf22-6dcf-47f7-a232-818623b3afdc/resourceGroups/euho-p-rg-privatednszones/providers/Microsoft.Network/privateDnsZones/"
    p = "/subscriptions/ceeadf22-6dcf-47f7-a232-818623b3afdc/resourceGroups/euho-p-rg-privatednszones/providers/Microsoft.Network/privateDnsZones/"
  }

}