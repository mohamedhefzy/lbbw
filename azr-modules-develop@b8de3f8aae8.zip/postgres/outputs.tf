# outputs
output "rg_name" {
  value = azurerm_resource_group.rg-postgres.name
}

output "postgres_server_names" {
  value = { for k, v in azurerm_postgresql_flexible_server.postgres-server : k => v.name }
}