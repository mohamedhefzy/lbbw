variable "app_environment" {
  description = "This variable defines the app environment of the specific application. Placeholder is 'x' if nothing is set."
  type        = string
}

variable "app_name" {
  description = "Name of the application per subscription"
  type        = string
}

variable "app_type" {
  description = "Type of app (shared, spoke...)"
  type        = string
}

variable "lbbw_location" {
  description = "LBBW Location"
  type        = string
}

variable "location" {
  description = "Azure location"
  type        = string
}

variable "infra_environment" {
  description = "This variable defines the environment to be built. (Prod,Cert,Dev,Engineering)."
  type        = string
}

variable "sbk" {
  description = "This variable defines the 'Schutzbedarfsklasse' (1, 2, 3, 4)"
  type        = string
}

variable "tags" {
  description = "Map of Tags per subscription"
  type        = map(string)
}

variable "vnet_id" {
  description = "value of vnet_id "
}

variable "pepsnet_id" {
  description = "The id of the private endpoints subnet"
  type        = string
}

variable "bvault_id" {
  description = "The id of the bvault."
  type        = string
}

variable "bvault_principal_id" {
  description = "The principal id of the bvault"
  type        = string
}

variable "bvault_psql_policy_id" {
  description = "ID of the PSQL Policy in the bvault"
  type        = string
}

variable "keyvault_encryption_key_id" {
  description = "The id of the key"
  type        = string
}

variable "postgres_servers" {
  description = "The configuration of the postgres-server"
  type = map(object({

    postgres_version              = string
    public_network_access_enabled = bool
    storage_mb                    = number
    storage_tier                  = string
    sku_name                      = string
    auto_grow_enabled             = bool
    zone                          = number
    authentication = object({
      active_directory_auth_enabled = bool
    })
    high_availability = object({
      mode                      = string
      standby_availability_zone = string
    })
  }))
}