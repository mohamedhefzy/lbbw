# Postgres

This module is used to deploy an Azure Postgres Flex Server.

## Created Resources

This module creates the following resources on azure

- ``azurerm_resource_group.rg-postgres``: A resource group where the follwoing resources are located.
- ``azurerm_postgresql_flexible_server.postgres-server``: The postgres flexible server.
- ``azurerm_role_assignment.psql-reader``: Role Assignment for postgres reader.
- ``azurerm_role_assignment.psql-backup-role``:
- ``azurerm_private_dns_zone.dns-zone``: Dns zone to be able to resolve the ip address. The dns zone is referenced in the resource for postgres server.
- ``azurerm_private_dns_zone_virtual_network_link.vnet-link``: Creates the link between vent and dns zone.
- ``azurerm_data_protection_backup_policy_postgresql_flexible_server.policy-postgres-flex-server``: The resource defines the policy of the backup.
- ``azurerm_data_protection_backup_instance_postgresql_flexible_server.backup-instance-postgres-flex-server``: The connection between postgres flex server, backup policy and backup vault.


### Importent
The private endpoint was removed with Ticket 1983. If 'delegated_subnet_id' and 'private_dns_zone_id' are set, no private endpoint can be added.


## Variables

| Name               | Description                                                               | Type   |
| ------------------ | --------------------------------------------------------------------------| -------|
| app_environment | This variable defines the app environment of the specific application. Placeholder is 'x' if nothing is set. | string |
| app_name | Name of the application per subscription. | string |
| app_type | Type of app (shared, spoke...) | string |
| lbbw_location | LBBW Location | string |
| location | Azure location | string |
| infra_environment | This variable defines the environment to be built. (Prod,Cert,Dev,Engineering). | string |
| sbk | This variable defines the 'Schutzbedarfsklasse' (1, 2, 3, 4) | string |
| patchwindow | This variable defines the patchwindow (Option1, Option2, Option3) | string |
| backupretention | This variable defines the backupretention (SHORT, MID, LONG) | string |
| tags | Map of Tags per subscription | map(string) |
| vnet_id | value of vnet_id | string |
| snet_ids | The ids of the subnet. | string |
| bvault_id | The id of the bvault. | string |
| bvault_principal_id | The principal id of the bvault. | string |
| keyvault_encryption_key_id | The id of the key. | string |
| postgres_servers | The configuration of the postgres-server. | object |


### Postgres Model

Model Deployments are described in a list of objects of the following structure:

```

postgres_servers = map({
  postgres_version              = string
  subnet_key_name               = string
  public_network_access_enabled = bool
  administrator_login           = string
  administrator_password        = string
  storage_mb                    = number
  storage_tier                  = string
  sku_name                      = string
  auto_grow_enabled             = bool
  authentication = object({
    active_directory_auth_enabled = bool
    zone                          = number
  })
  high_availability = object({
    mode = string
    #standby_availability_zone = string
    })
})

```

### Output

| Name                 | Description                                                                                                       |
| -------------------- | ----------------------------------------------------------------------------------------------------------------- |
| postgres_server_names | The name of the postgres servers. (Tests) |
| private_dns_zone_name | The name of the private dns zone. (Tests) |
| vnet_link_name | The vnet link name. (Tests) |


## Required Modules
- ntwspoke
- keyvault
- bvault