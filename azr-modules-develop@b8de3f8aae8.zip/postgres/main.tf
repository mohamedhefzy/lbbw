data "azurerm_client_config" "current" {
  # Returns the values of the currently logged in user
  # client_id         - is set to the Azure Client ID (Application Object ID).
  # tenant_id         - is set to the Azure Tenant ID.
  # subscription_id   - is set to the Azure Subscription ID.
  # object_id         - is set to the Azure Object ID.
}

data "azuread_service_principal" "example" {
  object_id = data.azurerm_client_config.current.object_id
}



resource "azurerm_resource_group" "rg-postgres" {
  name     = "${local.name_prefix}-rg-${local.prefix_app_name}-psql"
  location = var.location

  tags = var.tags

  lifecycle {
    ignore_changes = [
      tags["CreationDateTime"],
      tags["Owner"],
      tags["Environment"],
      tags["ITAB"],
      tags["AppName"],
      tags["AppEnv"],
      tags["SubscriptionType"],
      tags["PlatformId"],
      tags["Availability"],
      tags["Confidentiality"],
      tags["Integrity"]
    ]
  }
}

resource "azurerm_postgresql_flexible_server" "postgres-server" {
  for_each            = var.postgres_servers
  name                = "${local.name_prefix}-psql-${local.prefix_app_name}-${each.key}"
  resource_group_name = azurerm_resource_group.rg-postgres.name
  location            = var.location

  version                       = each.value.postgres_version
  public_network_access_enabled = each.value.public_network_access_enabled
  storage_mb                    = each.value.storage_mb
  storage_tier                  = each.value.storage_tier
  sku_name                      = each.value.sku_name
  auto_grow_enabled             = each.value.auto_grow_enabled
  backup_retention_days         = 35
  zone                          = each.value.zone

  authentication {
    # active_directory_auth_enabled = each.value.authentication.active_directory_auth_enabled
    active_directory_auth_enabled = true
    password_auth_enabled         = false
  }

  dynamic "high_availability" {
    # High availiability not supported for burstable server
    for_each = startswith(each.value.sku_name, "B_") ? [] : [1]
    content {
      mode                      = each.value.high_availability.mode
      standby_availability_zone = each.value.high_availability.standby_availability_zone
    }
  }

  dynamic "customer_managed_key" {
    for_each = contains(["3", "4"], var.sbk) ? [1] : []
    content {
      key_vault_key_id                  = var.keyvault_encryption_key_id
      primary_user_assigned_identity_id = "/subscriptions/${data.azurerm_client_config.current.subscription_id}/resourceGroups/${local.name_prefix}-rg-${local.prefix_app_name}-infra/providers/Microsoft.ManagedIdentity/userAssignedIdentities/${local.name_prefix}-mid-${local.prefix_app_name}-infra"
    }
  }

  identity {
    type         = "UserAssigned"
    identity_ids = ["/subscriptions/${data.azurerm_client_config.current.subscription_id}/resourceGroups/${local.name_prefix}-rg-${local.prefix_app_name}-infra/providers/Microsoft.ManagedIdentity/userAssignedIdentities/${local.name_prefix}-mid-${local.prefix_app_name}-infra"]
  }

  tags = var.tags

  lifecycle {
    ignore_changes = [
      tags["CreationDateTime"],
      tags["Owner"],
      tags["Environment"],
      tags["ITAB"],
      tags["AppName"],
      tags["AppEnv"],
      tags["SubscriptionType"],
      tags["PlatformId"],
      tags["Availability"],
      tags["Confidentiality"],
      tags["Integrity"]
    ]
  }
}

###########################
###### Network ############
###########################
resource "azurerm_private_endpoint" "pep" {
  for_each            = var.postgres_servers
  name                = "${local.name_prefix}-pep-${local.prefix_app_name}-${each.key}"
  location            = var.location
  resource_group_name = azurerm_resource_group.rg-postgres.name
  subnet_id           = var.pepsnet_id

  private_service_connection {
    name                           = "pep-sc-${each.key}"
    private_connection_resource_id = azurerm_postgresql_flexible_server.postgres-server[each.key].id
    subresource_names              = ["postgresqlServer"]
    is_manual_connection           = false
  }

  private_dns_zone_group {
    name                 = "postgres"
    private_dns_zone_ids = ["${local.private_dns_zone_id[var.infra_environment]}privatelink.postgres.database.azure.com"]
  }

  tags = var.tags

  lifecycle {
    ignore_changes = [
      tags["CreationDateTime"],
      tags["Owner"],
      tags["Environment"],
      tags["ITAB"],
      tags["AppName"],
      tags["AppEnv"],
      tags["SubscriptionType"],
      tags["PlatformId"],
      tags["Availability"],
      tags["Confidentiality"],
      tags["Integrity"]
    ]
  }

}

##########################
###### Backup ############
##########################
resource "azurerm_role_assignment" "psql-reader" {
  scope                = azurerm_resource_group.rg-postgres.id
  role_definition_name = "Reader"
  principal_id         = var.bvault_principal_id
}

resource "azurerm_role_assignment" "psql-backup-role" {
  scope                = azurerm_resource_group.rg-postgres.id
  role_definition_name = "PostgreSQL Flexible Server Long Term Retention Backup Role"
  principal_id         = var.bvault_principal_id
}

resource "azurerm_data_protection_backup_instance_postgresql_flexible_server" "backup-instance-postgres-flex-server" {
  for_each         = var.postgres_servers
  name             = "dpbipfs-${each.key}"
  location         = azurerm_resource_group.rg-postgres.location
  vault_id         = var.bvault_id
  server_id        = azurerm_postgresql_flexible_server.postgres-server[each.key].id
  backup_policy_id = var.bvault_psql_policy_id
}
