#!/bin/bash
# Delete all Azure managed snapshots in the given resource group (bulk).
set -euo pipefail

RESOURCE_GROUP="$1"

# Gather all snapshot IDs in the resource group into an array
mapfile -t SNAPSHOT_IDS < <(az snapshot list --resource-group "$RESOURCE_GROUP" --query "[].id" -o tsv)

if [ "${#SNAPSHOT_IDS[@]}" -eq 0 ]; then
  echo "No snapshots found in resource group '$RESOURCE_GROUP'. Nothing to delete."
  exit 0
fi

echo "Deleting snapshots in resource group '$RESOURCE_GROUP' in bulk:"
for id in "${SNAPSHOT_IDS[@]}"; do
  echo " - $id"
done

# Bulk delete all snapshots by passing all IDs to az snapshot delete
az snapshot delete --ids "${SNAPSHOT_IDS[@]}"

echo "Done. All snapshots in resource group '$RESOURCE_GROUP' have been deleted."