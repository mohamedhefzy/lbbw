# Storage Account
This module is used to deploy an Storage Account. 

| account_tier (sa)  | account_kind (sa)   | subresource_names (pep)  | Description                                           |
| ------------------ | ------------------- | ------------------------ | ----------------------------------------------------- |
| Standard (Default) | StorageV2 (Default) | blob, file, queue, table | Fully supports Files and standard storage options     |
| Premium            | StorageV2 (Default) | blob                     | Optimized for Block Blob storage. Cannot support file |
| Premium	           | FileStorage         | file                     | Specific for Premium Azure File Shares                |
| Premium            | BlockBlobStorage    | blob                     | Specific for Premium Block Blobs                      |
| Premium/Standard   | BlobStorage         | blob                     | Specific for Standard & Premium Blob Storages         |

## Created Resources

This module creates the following resources on azure

- ``azurerm_resource_group.rg-st``: A resource group where the resources of the storage accounts are located.
- ``azurerm_resource_group.rg-st-recovery``: A resource group where the resources for recovery are located.
- ``azurerm_storage_account.storage_account_recovery``: The recovery storage account.
- ``azurerm_private_endpoint.pls_storage_account_recovery``: The private endpoint of recovery storage account.
- ``azurerm_storage_account.storage_account_vm-recovery``: The recovery storage account of the vm.
- ``azurerm_private_endpoint.pls_storage_account_vm-recovery``: The endpoint of the recovery storage account of the vm.
- ``azurerm_storage_account.storage_accounts``: The storage account-
- ``azurerm_storage_share.sa_share``: The storage account share files
- ``azurerm_backup_container_storage_account.protection-container``: A backup resource for container.
- ``azurerm_backup_protected_file_share.protected-share``: A backup resource for file shares.
- ``azurerm_private_endpoint.pls_storage_account_file``: The private endpoint for the file shares.
- ``azurerm_private_endpoint.pls_storage_account_blob``: The private endpoint for blob containers.
- ``azurerm_storage_container.st_container``: The storage account containers.
- ``azurerm_role_assignment.role_assignement_backup``: The role assignment for blob backup instance.
- ``azurerm_data_protection_backup_instance_blob_storage.backup_instance_blob``: The blob backup instance.

## Variables

| Name               | Description                                                               | Type   |
| ------------------ | --------------------------------------------------------------------------| -------|
| app_type | Type of app (shared, spoke...) | string |
| app_name | Name of the application per subscription | string |
| lbbw_location | LBBW Location | string |
| location | Azure location | string |
| infra_environment | This variable defines the environment to be built. (Prod,Cert,Dev,Engineering). | string |
| app_environment | This variable defines the app environment of the specific application. Placeholder is 'x' if nothing is set. | string |
| sbk | This variable defines the 'Schutzbedarfsklasse' (1, 2, 3, 4) | string |
| patchwindow | This variable defines the patchwindow (Option1, Option2, Option3) | string |
| backupretention | This variable defines the backupretention (SHORT, MID, LONG) | string |
| rsvault_name | The possible ids of recovery service vaults. | string |
| rsvault_rg_name | The name of the resource group where the rsvault is located. | string |
| rsvault_share_policy_id | The id of the backup policy for file share. | string |
| bvault_id |The id of the backup vault. | string |
| bvault_blob_policy_id| The id of the blob policy. | string |
| bvault_principal_id | The id of bvault principle id. | string |
| is_iam_enabled | Toggle to disable IAM Entra RBAC role assignments in engineering. | bool |
| iam-entra-object-ids | Map of Entra Security Group Object IDs for role assignments. | map(string) |
| storage_accounts | Storage accounts | map(object) |
| subnet_id | Subnet ID for private endpoints | string |
| tags | Map of Tags per subscription | map(string) |



### Storage Account Model

Model Deployments are described in a list of objects of the following structure:

```
storage_accounts = {
    recovery_aks_shared_access_key = bool
    recovery_vm_shared_access_key  = bool
    storage_accounts = map(object({
      account_tier              = string
      account_kind              = string
      account_replication_type  = string
      shared_access_key_enabled = bool
      is_hns_enabled            = bool

      storage_containers = map(object({
        container_access_type = string
      }))

      shares = map(object({
        quota       = number
        access_tier = string
      }))

      blob_properties = object({
        delete_retention_policy = object({
          days = number
        })
        container_delete_retention_policy = object({
          days = number
        })
        restore_policy = object({
          days = number
        })
        change_feed_enabled = bool
        versioning_enabled  = bool
      })
    }))
}

```

## Output

| Name                 | Description                                                                                                       |
| -------------------- | ----------------------------------------------------------------------------------------------------------------- |
| storageaccount_ids | The ids of the storage accounts. |
| storageaccount_names | The names of the storage accounts. |
| storageaccount_rg_name | The name of the resource group where the storage accounts are located. |
| storageaccount_rg_recovery_name | The name of the resource group where the recovery storage account is located. |
| storageaccount_rg_recovery_id | The id of the resource group where the recovery storage account is located. |
| storageaccount_recovery_name | The name of the recovery storage account. |
| storageaccount_recovery_id | The id of the recovery storage account.|
| storageaccount_storage_share_names | The names of the file shares. (Tests) |
| storageaccount_storage_container_names | The names of the containers. (Tests) |

## Required Modules
- ntwspoke
- rsvault
- bvault