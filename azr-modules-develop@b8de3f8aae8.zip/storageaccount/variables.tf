variable "is_old_tenant" {
  description = "Is old tenant used"
  type        = bool
}

variable "app_type" {
  description = "Type of app (shared, spoke...)"
  type        = string
}

variable "app_name" {
  description = "Name of the application per subscription"
  type        = string
}

variable "lbbw_location" {
  description = "LBBW Location"
  type        = string
}

variable "location" {
  description = "Azure location"
  type        = string
}

variable "infra_environment" {
  description = "This variable defines the environment to be built. (Prod,Cert,Dev,Engineering)."
  type        = string
}

variable "app_environment" {
  description = "This variable defines the app environment of the specific application. Placeholder is 'x' if nothing is set."
  type        = string
}

variable "sbk" {
  description = "This variable defines the 'Schutzbedarfsklasse' (1, 2, 3, 4)"
  type        = string
}

variable "patchwindow" {
  description = "This variable defines the patchwindow (Option1, Option2, Option3)"
  type        = string
}

variable "backupretention" {
  description = "This variable defines the backupretention (SHORT, MID, LONG)"
  type        = string
}

variable "keyvault_encryption_key_id" {
  description = "The id of the key that is used for disk encryption"
  type        = string
}

variable "rsvault_name" {
  description = "The possible ids of recovery service vaults."
  type        = string
}

variable "rsvault_rg_name" {
  description = "The name of the resource group where the rsvault is located"
  type        = string
}

variable "rsvault_share_policy_id" {
  description = "The id of the backup policy for file share"
  type        = string
}

variable "bvault_id" {
  description = "The id of the backup vault."
  type        = string
}

variable "bvault_blob_policy_id" {
  description = "The id of the backup policy for blob."
  type        = string
}

variable "bvault_principal_id" {
  description = "The id of bvault principle id."
}

variable "is_iam_enabled" {
  description = "Toggle to disable IAM Entra RBAC role assignments in engineering"
  type        = bool
}

variable "iam-entra-object-ids" {
  description = "Map of Entra Security Group Object IDs for role assignments"
  type        = map(string)
}

variable "storage_accounts" {
  description = "Storage accounts"
  type = object({
    recovery_aks_shared_access_key = bool
    recovery_vm_shared_access_key  = bool
    storage_accounts = map(object({
      account_tier              = string
      account_kind              = string
      account_replication_type  = string
      shared_access_key_enabled = bool
      dynamic_storage           = bool
      is_hns_enabled            = bool
      nfsv3_enabled             = bool

      storage_containers = map(object({
        container_access_type = string
      }))

      shares = map(object({
        quota       = number
        access_tier = string
      }))

      blob_properties = object({
        delete_retention_policy = object({
          days = number
        })
        container_delete_retention_policy = object({
          days = number
        })
        restore_policy = object({
          days = number
        })
        change_feed_enabled = bool
        versioning_enabled  = bool
      })
    }))
  })
}

variable "subnet_ids" {
  description = "Subnet ID for private endpoints"
  type        = map(string)
}

######
variable "tags" {
  description = "Map of Tags per subscription"
  type        = map(string)
}
