locals {
  name_prefix                = "${var.lbbw_location}-${var.infra_environment}"
  name_prefix_without_hyphen = "${var.lbbw_location}${var.infra_environment}"
  prefix_app_name            = "${var.app_environment}${var.app_name}"


  storage_containers_flattened = {
    for sc in(flatten([
      for account_key, account in var.storage_accounts.storage_accounts : [
        for container_key, container in account.storage_containers : {
          key       = "${container_key}-${account_key}"
          account   = account_key
          container = container_key
        }
      ]
    ])) : sc.key => sc
  }

  shares_flattened = {
    for s in(flatten([
      for storage_account_key, storage_account in var.storage_accounts.storage_accounts : [
        for share_key, share in storage_account.shares : {
          key                 = "${share_key}-${storage_account_key}"
          storage_account_key = storage_account_key
          share_key           = share_key
          quota               = share.quota
          access_tier         = share.access_tier
        }
      ]
    ])) : s.key => s
  }

  sa_without_hns = { for k, v in var.storage_accounts.storage_accounts : k => v if v.is_hns_enabled == false }

  container_list_without_hns = {
    for storage_account_key, storage_account in local.sa_without_hns : storage_account_key => keys(storage_account.storage_containers)
    if length(storage_account.storage_containers) > 0
  }

  private_dns_zone_ids = {
    e = "/subscriptions/a1ce34e0-ffe5-46be-b04b-1cbf0735eeb5/resourceGroups/euho-e-rg-privatednszone/providers/Microsoft.Network/privateDnsZones/"
    d = "/subscriptions/b8c7d5eb-d942-400c-999c-1c741ffb52bf/resourceGroups/euho-d-rg-privatednszone/providers/Microsoft.Network/privateDnsZones/"
    c = "/subscriptions/b79558eb-d4b4-4d56-8f95-8d5c33f7c3cf/resourceGroups/euho-c-rg-privatednszone/providers/Microsoft.Network/privateDnsZones/"
    p = "/subscriptions/2836bb7c-3eaa-4fdd-9024-3f17daf08755/resourceGroups/euho-p-rg-privatednszone/providers/Microsoft.Network/privateDnsZones/"
  }

  private_dns_zone_id_new_tenant = {
    e = "/subscriptions/3da49d2d-46fc-4deb-a3aa-57cbc662e092/resourceGroups/euho-e-rg-privatednszones/providers/Microsoft.Network/privateDnsZones/"
    d = "/subscriptions/ceeadf22-6dcf-47f7-a232-818623b3afdc/resourceGroups/euho-p-rg-privatednszones/providers/Microsoft.Network/privateDnsZones/"
    c = "/subscriptions/ceeadf22-6dcf-47f7-a232-818623b3afdc/resourceGroups/euho-p-rg-privatednszones/providers/Microsoft.Network/privateDnsZones/"
    p = "/subscriptions/ceeadf22-6dcf-47f7-a232-818623b3afdc/resourceGroups/euho-p-rg-privatednszones/providers/Microsoft.Network/privateDnsZones/"
  }
}