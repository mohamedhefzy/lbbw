data "azurerm_client_config" "current" {
  # Returns the values of the currently logged in user
  # client_id         - is set to the Azure Client ID (Application Object ID).
  # tenant_id         - is set to the Azure Tenant ID.
  # subscription_id   - is set to the Azure Subscription ID.
  # object_id         - is set to the Azure Object ID.
}

resource "azurerm_resource_group" "rg-st" {
  name     = "${local.name_prefix}-rg-${local.prefix_app_name}-st"
  location = var.location

  tags = var.tags

  lifecycle {
    ignore_changes = [
      tags["CreationDateTime"],
      tags["Owner"],
      tags["Environment"],
      tags["ITAB"],
      tags["AppName"],
      tags["AppEnv"],
      tags["SubscriptionType"],
      tags["PlatformId"],
      tags["Availability"],
      tags["Confidentiality"],
      tags["Integrity"]
    ]
  }
}

### WARNING FOR FUTURE DEV IF WE EVER NEED TO SUPPORT PREMIUM STORAGE ACCOUNTS AND AZURE FILE SHARES AT THE SAME TIME ###
/* **

| account_tier (sa)  | account_kind (sa)   | subresource_names (pep)  | Description                                           |
| ------------------ | ------------------- | ------------------------ | ----------------------------------------------------- |
| Standard (Default) | StorageV2 (Default) | blob, file, queue, table | Fully supports Files and standard storage options     |
| Premium            | StorageV2 (Default) | blob                     | Optimized for Block Blob storage. Cannot support file |
| Premium	           | FileStorage         | file                     | Specific for Premium Azure File Shares                | <-- Relevant for Premium Azure File Shares
| Premium            | BlockBlobStorage    | blob                     | Specific for Premium Block Blobs                      |
| Premium/Standard   | BlobStorage         | blob                     | Specific for Standard & Premium Blob Storages         |

This means that the 'azurerm_storage_account.storage_accounts.account_kind' need to be set to 'FileStorage' in order to use '*.account_tier = "Premium"' for a Azure File Share
*/

resource "azurerm_storage_account" "storage_accounts" {
  for_each            = var.storage_accounts.storage_accounts
  name                = "${local.name_prefix_without_hyphen}st${local.prefix_app_name}${each.key}"
  resource_group_name = azurerm_resource_group.rg-st.name
  location            = azurerm_resource_group.rg-st.location
  # customer_managed_key can only be set when the account_kind is set to StorageV2 OR account_tier set to Premium **
  account_tier             = each.value.account_tier
  account_kind             = each.value.account_kind
  account_replication_type = each.value.account_replication_type
  is_hns_enabled           = each.value.dynamic_storage || each.value.nfsv3_enabled ? true : each.value.is_hns_enabled # Support Azure DataLake Gen2 storage account for blobfuse mount - If nfsv3 is used ST has to be hns enabled
  nfsv3_enabled            = each.value.dynamic_storage ? true : each.value.nfsv3_enabled                              # If dynamic storage is used force enable nfsv3

  public_network_access_enabled   = false
  shared_access_key_enabled       = each.value.shared_access_key_enabled # must be set to true if Azure Files are used, otherwise Azure Files will not work - hard requirement - can be false for blobs though
  default_to_oauth_authentication = false
  https_traffic_only_enabled      = each.value.dynamic_storage || each.value.nfsv3_enabled ? false : true # nfsv3 does not use https traffic and nfsv4 is not supported yet - hard requirement # Looks like policy is forcing it to true though - it still works ¯\_(ツ)_/¯
  allow_nested_items_to_be_public = false

  # Additional you will need to enable the storage_use_azuread flag in the Provider block 
  # to use Azure AD/Entra for authentication

  dynamic "blob_properties" {
    for_each = each.value.dynamic_storage || each.value.nfsv3_enabled ? [] : lookup(each.value, "blob_properties", null) != null ? [each.value.blob_properties] : [] # blob_properties don't work with hns_enabled
    content {
      delete_retention_policy {
        days = lookup(blob_properties.value.delete_retention_policy, "days", 30)
      }
      container_delete_retention_policy {
        days = lookup(blob_properties.value.container_delete_retention_policy, "days", 30)
      }
      # Conditionally add restore_policy only if HNS is disabled
      dynamic "restore_policy" {
        for_each = [lookup(blob_properties.value, "restore_policy", null)]
        content {
          days = lookup(restore_policy.value, "days", 29)
        }
      }
      change_feed_enabled = lookup(blob_properties.value, "change_feed_enabled", true)
      versioning_enabled  = lookup(blob_properties.value, "versioning_enabled", true)
    }
  }

  dynamic "network_rules" {
    for_each = each.value.dynamic_storage || each.value.nfsv3_enabled ? [1] : [] # NetworkAcls default action must be set to Deny for NFS enabled storage accounts
    content {
      default_action             = "Deny"
      bypass                     = ["AzureServices"]
      virtual_network_subnet_ids = [var.subnet_ids["default"], var.subnet_ids["private_endpoint_subnet"]] # maybe add potential more snets like psql or mssql? TODO
    }
  }

  dynamic "customer_managed_key" {
    for_each = contains(["3", "4"], var.sbk) ? [1] : []
    content {
      key_vault_key_id          = var.keyvault_encryption_key_id
      user_assigned_identity_id = "/subscriptions/${data.azurerm_client_config.current.subscription_id}/resourceGroups/${local.name_prefix}-rg-${local.prefix_app_name}-infra/providers/Microsoft.ManagedIdentity/userAssignedIdentities/${local.name_prefix}-mid-${local.prefix_app_name}-infra"
    }
  }

  identity {
    type         = "UserAssigned"
    identity_ids = ["/subscriptions/${data.azurerm_client_config.current.subscription_id}/resourceGroups/${local.name_prefix}-rg-${local.prefix_app_name}-infra/providers/Microsoft.ManagedIdentity/userAssignedIdentities/${local.name_prefix}-mid-${local.prefix_app_name}-infra"]
  }

  tags = var.tags

  lifecycle {
    ignore_changes = [
      network_rules[0].private_link_access, # Is always updated in-place - unnecessary
      tags["CreationDateTime"],
      tags["Owner"],
      tags["Environment"],
      tags["ITAB"],
      tags["AppName"],
      tags["AppEnv"],
      tags["SubscriptionType"],
      tags["PlatformId"],
      tags["Availability"],
      tags["Confidentiality"],
      tags["Integrity"]
    ]
  }

  depends_on = [
    azurerm_role_assignment.storage-file-data-privileged-contributor,
    azurerm_role_assignment.storage-file-data-smb-share-contributor,
    azurerm_role_assignment.storage_account_contributor_rg-st,
    azurerm_role_assignment.storage_account_contributor_rg-st-recovery,
    azurerm_role_assignment.storage_account_key_operator_service_rg-st,
    azurerm_role_assignment.storage_account_key_operator_service_rg-st-recovery,
    azurerm_role_assignment.storage_blob_data_contributor_rg-st,
    azurerm_role_assignment.storage_blob_data_contributor_rg-st-recovery,
    azurerm_role_assignment.disk_restore_operator_rg-st-recovery,
    azurerm_role_assignment.disk_backup_reader_rg-st-recovery,
    azurerm_role_assignment.backup_operator_rg-st-recovery,
    azurerm_role_assignment.storage_account_backup_contributor_rg-st-recovery
  ]
}

resource "azurerm_private_endpoint" "pls_storage_account_file" {
  for_each = var.storage_accounts.storage_accounts

  name                = "${local.name_prefix}-pep-${local.prefix_app_name}-${each.key}-file"
  location            = azurerm_resource_group.rg-st.location
  resource_group_name = azurerm_resource_group.rg-st.name
  subnet_id           = var.subnet_ids["private_endpoint_subnet"]

  private_service_connection {
    is_manual_connection           = false
    name                           = "pep-sc-${each.key}"
    private_connection_resource_id = azurerm_storage_account.storage_accounts[each.key].id
    subresource_names              = ["file"]
  }

  private_dns_zone_group {
    name                 = "file"
    private_dns_zone_ids = var.is_old_tenant ? ["${local.private_dns_zone_ids[var.infra_environment]}privatelink.file.core.windows.net"] : ["${local.private_dns_zone_id_new_tenant[var.infra_environment]}privatelink.file.core.windows.net"]
  }

  tags = var.tags

  lifecycle {
    ignore_changes = [
      tags["CreationDateTime"],
      tags["Owner"],
      tags["Environment"],
      tags["ITAB"],
      tags["AppName"],
      tags["AppEnv"],
      tags["SubscriptionType"],
      tags["PlatformId"],
      tags["Availability"],
      tags["Confidentiality"],
      tags["Integrity"]
    ]
  }
}

resource "azurerm_private_endpoint" "pls_storage_account_blob" {
  for_each = var.storage_accounts.storage_accounts

  name                = "${local.name_prefix}-pep-${local.prefix_app_name}-${each.key}-blob"
  location            = azurerm_resource_group.rg-st.location
  resource_group_name = azurerm_resource_group.rg-st.name
  subnet_id           = var.subnet_ids["private_endpoint_subnet"]

  private_service_connection {
    is_manual_connection           = false
    name                           = "pep-sc-${each.key}"
    private_connection_resource_id = azurerm_storage_account.storage_accounts[each.key].id
    subresource_names              = ["blob"]
  }

  private_dns_zone_group {
    name                 = "blob"
    private_dns_zone_ids = var.is_old_tenant ? ["${local.private_dns_zone_ids[var.infra_environment]}privatelink.blob.core.windows.net"] : ["${local.private_dns_zone_id_new_tenant[var.infra_environment]}privatelink.blob.core.windows.net"]
  }

  tags = var.tags

  lifecycle {
    ignore_changes = [
      tags["CreationDateTime"],
      tags["Owner"],
      tags["Environment"],
      tags["ITAB"],
      tags["AppName"],
      tags["AppEnv"],
      tags["SubscriptionType"],
      tags["PlatformId"],
      tags["Availability"],
      tags["Confidentiality"],
      tags["Integrity"]
    ]
  }
}

# Blob-Storage
resource "azurerm_storage_container" "st_container" {
  for_each              = local.storage_containers_flattened
  name                  = each.value.container
  storage_account_name  = azurerm_storage_account.storage_accounts[each.value.account].name
  container_access_type = "private"

  depends_on = [
    azurerm_private_endpoint.pls_storage_account_file,
    azurerm_private_endpoint.pls_storage_account_blob
  ]
}

resource "azurerm_storage_share" "sa_share" {
  for_each             = local.shares_flattened
  name                 = each.key
  quota                = each.value.quota
  access_tier          = each.value.access_tier
  storage_account_name = azurerm_storage_account.storage_accounts[each.value.storage_account_key].name

  depends_on = [
    azurerm_private_endpoint.pls_storage_account_file,
    azurerm_private_endpoint.pls_storage_account_blob
  ]
}

resource "azurerm_backup_container_storage_account" "protection-container" {
  for_each = var.storage_accounts.storage_accounts

  resource_group_name = var.rsvault_rg_name
  recovery_vault_name = var.rsvault_name
  storage_account_id  = azurerm_storage_account.storage_accounts[each.key].id
}

resource "azurerm_backup_protected_file_share" "protected-share" {
  for_each = local.shares_flattened

  resource_group_name       = var.rsvault_rg_name
  recovery_vault_name       = var.rsvault_name
  source_storage_account_id = azurerm_backup_container_storage_account.protection-container[each.value.storage_account_key].storage_account_id
  backup_policy_id          = var.rsvault_share_policy_id
  source_file_share_name    = azurerm_storage_share.sa_share[each.key].name

  depends_on = [
    azurerm_backup_container_storage_account.protection-container
  ]
}

#############################################################################################################################
#
# Storage Account for Backup Vault Recovery Operations
#
#############################################################################################################################

resource "azurerm_resource_group" "rg-st-recovery" {
  name     = "${local.name_prefix}-rg-${local.prefix_app_name}-st-recovery"
  location = var.location

  tags = var.tags

  lifecycle {
    ignore_changes = [
      tags["CreationDateTime"],
      tags["Owner"],
      tags["Environment"],
      tags["ITAB"],
      tags["AppName"],
      tags["AppEnv"],
      tags["SubscriptionType"],
      tags["PlatformId"],
      tags["Availability"],
      tags["Confidentiality"],
      tags["Integrity"]
    ]
  }
}

resource "null_resource" "delete-recovery-snapshots" {
  count = var.infra_environment == "e" ? 1 : 0 # We don't just want to delete all Snapshots on Productive Stages

  triggers = {
    rg_st_snapshots = azurerm_resource_group.rg-st-recovery.name
  }

  provisioner "local-exec" {
    when       = destroy
    command    = "chmod +x ../../azr-modules/gen_scripts/delete_recovery_snapshots.sh && ../../azr-modules/gen_scripts/delete_recovery_snapshots.sh ${self.triggers.rg_st_snapshots}"
    on_failure = "continue"
  }

  depends_on = [azurerm_resource_group.rg-st-recovery]
}


#This storage account is uniquely used for recovery operations by Azure Backup Vault, Azure Recovery Service Vault and other Azure Services
resource "azurerm_storage_account" "storage_account_recovery" {
  name                            = "${local.name_prefix_without_hyphen}st${local.prefix_app_name}recovery"
  resource_group_name             = azurerm_resource_group.rg-st-recovery.name
  location                        = azurerm_resource_group.rg-st-recovery.location
  account_tier                    = "Standard"
  account_replication_type        = "LRS"
  public_network_access_enabled   = false
  shared_access_key_enabled       = var.storage_accounts.recovery_aks_shared_access_key
  https_traffic_only_enabled      = true
  allow_nested_items_to_be_public = false

  dynamic "customer_managed_key" {
    for_each = contains(["3", "4"], var.sbk) ? [1] : []
    content {
      key_vault_key_id          = var.keyvault_encryption_key_id
      user_assigned_identity_id = "/subscriptions/${data.azurerm_client_config.current.subscription_id}/resourceGroups/${local.name_prefix}-rg-${local.prefix_app_name}-infra/providers/Microsoft.ManagedIdentity/userAssignedIdentities/${local.name_prefix}-mid-${local.prefix_app_name}-infra"
    }
  }

  identity {
    type         = "UserAssigned"
    identity_ids = ["/subscriptions/${data.azurerm_client_config.current.subscription_id}/resourceGroups/${local.name_prefix}-rg-${local.prefix_app_name}-infra/providers/Microsoft.ManagedIdentity/userAssignedIdentities/${local.name_prefix}-mid-${local.prefix_app_name}-infra"]
  }

  tags = var.tags

  lifecycle {
    ignore_changes = [
      tags["CreationDateTime"],
      tags["Owner"],
      tags["Environment"],
      tags["ITAB"],
      tags["AppName"],
      tags["AppEnv"],
      tags["SubscriptionType"],
      tags["PlatformId"],
      tags["Availability"],
      tags["Confidentiality"],
      tags["Integrity"]
    ]
  }

  depends_on = [
    azurerm_role_assignment.storage-file-data-privileged-contributor,
    azurerm_role_assignment.storage-file-data-smb-share-contributor,
    azurerm_role_assignment.storage_account_contributor_rg-st,
    azurerm_role_assignment.storage_account_contributor_rg-st-recovery,
    azurerm_role_assignment.storage_account_key_operator_service_rg-st,
    azurerm_role_assignment.storage_account_key_operator_service_rg-st-recovery,
    azurerm_role_assignment.storage_blob_data_contributor_rg-st,
    azurerm_role_assignment.storage_blob_data_contributor_rg-st-recovery
  ]
}

resource "azurerm_private_endpoint" "pls_storage_account_recovery" {
  name                = "${local.name_prefix}-pep-${local.prefix_app_name}-recovery"
  location            = azurerm_resource_group.rg-st-recovery.location
  resource_group_name = azurerm_resource_group.rg-st-recovery.name
  subnet_id           = var.subnet_ids["private_endpoint_subnet"]

  private_service_connection {
    is_manual_connection           = false
    name                           = "pep-sc-${azurerm_storage_account.storage_account_recovery.name}"
    private_connection_resource_id = azurerm_storage_account.storage_account_recovery.id
    subresource_names              = ["blob"]
  }

  private_dns_zone_group {
    name                 = "blob"
    private_dns_zone_ids = var.is_old_tenant ? ["${local.private_dns_zone_ids[var.infra_environment]}privatelink.blob.core.windows.net"] : ["${local.private_dns_zone_id_new_tenant[var.infra_environment]}privatelink.blob.core.windows.net"]
  }

  tags = var.tags

  lifecycle {
    ignore_changes = [
      tags["CreationDateTime"],
      tags["Owner"],
      tags["Environment"],
      tags["ITAB"],
      tags["AppName"],
      tags["AppEnv"],
      tags["SubscriptionType"],
      tags["PlatformId"],
      tags["Availability"],
      tags["Confidentiality"],
      tags["Integrity"]
    ]
  }
}

#############################################################################################################################
#
# Storage Account for VM Recovery Operations
#
#############################################################################################################################

#For VM recovery, this storage account is uniquely used for recovery operations by Azure Backup Vault, Azure Recovery Service Vault and other Azure Services
resource "azurerm_storage_account" "storage_account_vm-recovery" {
  name                            = "${local.name_prefix_without_hyphen}st${local.prefix_app_name}vmrecovery"
  resource_group_name             = azurerm_resource_group.rg-st-recovery.name
  location                        = azurerm_resource_group.rg-st-recovery.location
  account_tier                    = "Standard"
  account_replication_type        = "LRS"
  public_network_access_enabled   = false
  shared_access_key_enabled       = var.storage_accounts.recovery_vm_shared_access_key
  https_traffic_only_enabled      = true
  allow_nested_items_to_be_public = false

  dynamic "customer_managed_key" {
    for_each = contains(["3", "4"], var.sbk) ? [1] : []
    content {
      key_vault_key_id          = var.keyvault_encryption_key_id
      user_assigned_identity_id = "/subscriptions/${data.azurerm_client_config.current.subscription_id}/resourceGroups/${local.name_prefix}-rg-${local.prefix_app_name}-infra/providers/Microsoft.ManagedIdentity/userAssignedIdentities/${local.name_prefix}-mid-${local.prefix_app_name}-infra"
    }
  }

  identity {
    type         = "UserAssigned"
    identity_ids = ["/subscriptions/${data.azurerm_client_config.current.subscription_id}/resourceGroups/${local.name_prefix}-rg-${local.prefix_app_name}-infra/providers/Microsoft.ManagedIdentity/userAssignedIdentities/${local.name_prefix}-mid-${local.prefix_app_name}-infra"]
  }

  tags = var.tags

  lifecycle {
    ignore_changes = [
      tags["CreationDateTime"],
      tags["Owner"],
      tags["Environment"],
      tags["ITAB"],
      tags["AppName"],
      tags["AppEnv"],
      tags["SubscriptionType"],
      tags["PlatformId"],
      tags["Availability"],
      tags["Confidentiality"],
      tags["Integrity"]
    ]
  }

  depends_on = [
    azurerm_role_assignment.storage-file-data-privileged-contributor,
    azurerm_role_assignment.storage-file-data-smb-share-contributor,
    azurerm_role_assignment.storage_account_contributor_rg-st,
    azurerm_role_assignment.storage_account_contributor_rg-st-recovery,
    azurerm_role_assignment.storage_account_key_operator_service_rg-st,
    azurerm_role_assignment.storage_account_key_operator_service_rg-st-recovery,
    azurerm_role_assignment.storage_blob_data_contributor_rg-st,
    azurerm_role_assignment.storage_blob_data_contributor_rg-st-recovery,
    azurerm_role_assignment.disk_restore_operator_rg-st-recovery,
    azurerm_role_assignment.disk_backup_reader_rg-st-recovery,
    azurerm_role_assignment.backup_operator_rg-st-recovery,
    azurerm_role_assignment.storage_account_backup_contributor_rg-st-recovery
  ]
}

resource "azurerm_private_endpoint" "pls_storage_account_vm-recovery" {
  name                = "${local.name_prefix}-pep-${local.prefix_app_name}-vm_recovery"
  location            = azurerm_resource_group.rg-st-recovery.location
  resource_group_name = azurerm_resource_group.rg-st-recovery.name
  subnet_id           = var.subnet_ids["private_endpoint_subnet"]

  private_service_connection {
    is_manual_connection           = false
    name                           = "pep-sc-${azurerm_storage_account.storage_account_vm-recovery.name}"
    private_connection_resource_id = azurerm_storage_account.storage_account_vm-recovery.id
    subresource_names              = ["blob"]
  }

  private_dns_zone_group {
    name                 = "blob"
    private_dns_zone_ids = var.is_old_tenant ? ["${local.private_dns_zone_ids[var.infra_environment]}privatelink.blob.core.windows.net"] : ["${local.private_dns_zone_id_new_tenant[var.infra_environment]}privatelink.blob.core.windows.net"]
  }

  tags = var.tags

  lifecycle {
    ignore_changes = [
      tags["CreationDateTime"],
      tags["Owner"],
      tags["Environment"],
      tags["ITAB"],
      tags["AppName"],
      tags["AppEnv"],
      tags["SubscriptionType"],
      tags["PlatformId"],
      tags["Availability"],
      tags["Confidentiality"],
      tags["Integrity"]
    ]
  }
}

#############################################################################################################################
#
# Storage Account Role Assignments for Subscription MID
#
#############################################################################################################################

// todo which roles are needed and why?
resource "azurerm_role_assignment" "storage-file-data-privileged-contributor" {
  scope                = azurerm_resource_group.rg-st.id
  role_definition_name = "Storage File Data Privileged Contributor"
  principal_id         = data.azurerm_client_config.current.object_id
}

resource "azurerm_role_assignment" "storage-file-data-smb-share-contributor" {
  scope                = azurerm_resource_group.rg-st.id
  role_definition_name = "Storage File Data SMB Share Contributor"
  principal_id         = data.azurerm_client_config.current.object_id
}

resource "azurerm_role_assignment" "storage_account_contributor_rg-st" {
  scope                = azurerm_resource_group.rg-st.id
  role_definition_name = "Storage Account Contributor"
  principal_id         = data.azurerm_client_config.current.object_id
}

resource "azurerm_role_assignment" "storage_account_contributor_rg-st-recovery" {
  scope                = azurerm_resource_group.rg-st-recovery.id
  role_definition_name = "Storage Account Contributor"
  principal_id         = data.azurerm_client_config.current.object_id
}

resource "azurerm_role_assignment" "storage_account_key_operator_service_rg-st" {
  scope                = azurerm_resource_group.rg-st.id
  role_definition_name = "Storage Account Key Operator Service Role"
  principal_id         = data.azurerm_client_config.current.object_id
}

resource "azurerm_role_assignment" "storage_account_key_operator_service_rg-st-recovery" {
  scope                = azurerm_resource_group.rg-st-recovery.id
  role_definition_name = "Storage Account Key Operator Service Role"
  principal_id         = data.azurerm_client_config.current.object_id
}

resource "azurerm_role_assignment" "storage_blob_data_contributor_rg-st" {
  scope                = azurerm_resource_group.rg-st.id
  role_definition_name = "Storage Blob Data Contributor"
  principal_id         = data.azurerm_client_config.current.object_id
}

resource "azurerm_role_assignment" "storage_blob_data_contributor_rg-st-recovery" {
  scope                = azurerm_resource_group.rg-st-recovery.id
  role_definition_name = "Storage Blob Data Contributor"
  principal_id         = data.azurerm_client_config.current.object_id
}

resource "azurerm_role_assignment" "disk_restore_operator_rg-st-recovery" {
  scope                = azurerm_resource_group.rg-st-recovery.id
  role_definition_name = "Disk Restore Operator"
  principal_id         = data.azurerm_client_config.current.object_id
}

resource "azurerm_role_assignment" "disk_backup_reader_rg-st-recovery" {
  scope                = azurerm_resource_group.rg-st-recovery.id
  role_definition_name = "Disk Backup Reader"
  principal_id         = data.azurerm_client_config.current.object_id
}

resource "azurerm_role_assignment" "backup_operator_rg-st-recovery" {
  scope                = azurerm_resource_group.rg-st-recovery.id
  role_definition_name = "Backup Operator"
  principal_id         = data.azurerm_client_config.current.object_id
}

resource "azurerm_role_assignment" "storage_account_backup_contributor_rg-st-recovery" {
  scope                = azurerm_resource_group.rg-st-recovery.id
  role_definition_name = "Storage account Backup Contributor"
  principal_id         = data.azurerm_client_config.current.object_id
  #principal_id         = data.azurerm_recovery_services_vault.vault.identity.principal_id
}

### Blob Backup 
resource "azurerm_role_assignment" "role_assignement_backup" {
  for_each             = var.storage_accounts.storage_accounts
  scope                = azurerm_storage_account.storage_accounts[each.key].id
  role_definition_name = "Storage Account Backup Contributor"
  principal_id         = var.bvault_principal_id
}

resource "azurerm_data_protection_backup_instance_blob_storage" "backup_instance_blob" {
  for_each                        = local.container_list_without_hns # backup_instance_blob_storage does not work with hns enabled SAs
  name                            = "dpbibs-${each.key}"
  vault_id                        = var.bvault_id
  location                        = azurerm_resource_group.rg-st.location
  storage_account_id              = azurerm_storage_account.storage_accounts[each.key].id
  backup_policy_id                = var.bvault_blob_policy_id
  storage_account_container_names = local.container_list_without_hns[each.key]

  depends_on = [azurerm_role_assignment.role_assignement_backup, azurerm_storage_container.st_container]
}