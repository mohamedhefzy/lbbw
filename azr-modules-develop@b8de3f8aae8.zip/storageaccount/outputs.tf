output "storageaccount_ids" {
  value = { for k, v in azurerm_storage_account.storage_accounts : k => v.id }
}

output "storageaccount_names" {
  value = { for k, v in azurerm_storage_account.storage_accounts : k => v.name }
}

output "storageaccount_data" {
  sensitive = true
  value = { for k, v in azurerm_storage_account.storage_accounts : k => {
    name : v.name,
    primary_access_key : v.primary_access_key
    }
  }
}

output "share_names" {
  value = { for k, v in azurerm_storage_share.sa_share : k => v.name }
}

output "container_names" {
  value = { for k, v in azurerm_storage_container.st_container : k => v.name }
}

output "storageaccount_rg_name" {
  value = azurerm_resource_group.rg-st.name
}

output "storageaccount_rg_recovery_name" {
  value = azurerm_resource_group.rg-st-recovery.name
}

output "storageaccount_rg_recovery_id" {
  value = azurerm_resource_group.rg-st-recovery.id
}

output "storageaccount_recovery_name" {
  value = azurerm_storage_account.storage_account_recovery.name
}

output "storageaccount_recovery_id" {
  value = azurerm_storage_account.storage_account_recovery.id
}

output "storageaccount_storage_share_names" {
  value = { for k, v in azurerm_storage_share.sa_share : k => v.name }
}

output "storageaccount_storage_container_names" {
  value = { for k, v in azurerm_storage_container.st_container : k => v.name }
}
