run "execute" {
  module {
    source = "./setup"
  }

  command = plan

  assert {
    condition     = module.storageaccount.storageaccount_names.s1 == "euhoestxtests1"
    error_message = "The name of the storage account does not match."
  }

  assert {
    condition     = module.storageaccount.storageaccount_rg_name == "euho-e-rg-xtest-st"
    error_message = "The name of the storage account ressource group does not match."
  }

  assert {
    condition     = module.storageaccount.storageaccount_rg_recovery_name == "euho-e-rg-xtest-st-recovery"
    error_message = "The name of the recovery storage account ressource group does not match."
  }

  assert {
    condition     = module.storageaccount.storageaccount_recovery_name == "euhoestxtestrecovery"
    error_message = "The name of the recovery storage account does not match"
  }

  assert {
    condition     = module.storageaccount.storageaccount_storage_share_names["s1-s1"] == "s1-s1"
    error_message = "The name of a share does not match"
  }

  assert {
    condition     = module.storageaccount.storageaccount_storage_container_names["container1-s1"] == "container1"
    error_message = "The name of a container does not match"
  }

}