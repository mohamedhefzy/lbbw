provider "azurerm" {
  features {}
  subscription_id = "541ac1c2-8b44-4aac-abdf-3ce58dd8f753"
}


module "storageaccount" {

  source = "../../"

  is_old_tenant     = var.is_old_tenant
  app_name          = var.app_name
  app_type          = var.app_type
  app_environment   = var.app_environment
  infra_environment = var.infra_environment
  lbbw_location     = var.lbbw_location
  location          = var.location

  backupretention = var.backupretention
  patchwindow     = var.patchwindow
  sbk             = var.sbk

  tags = {
    source         = "terraform"
    environment    = "development"
    "ITAB"         = "7656"
    "AppName"      = "test"
    "Owner"        = "test"
    "Creator"      = "iac-admin"
    "ServerRole"   = "container-platform"
    "CreationDate" = "auto-generated"
  }

  iam-entra-object-ids = {
    third-lvl-support_tier2 : "6a3a422d-814e-432b-9d79-f5fa30b38f3b",
    third-lvl-support_tier1 : "d771fde7-7f31-45e1-a3cc-dce3ca953ad1",
    third-lvl-support_tier0 : "f79f7b32-15f8-44ba-b0fd-1c7d33aea31d",
    second-lvl-support_tier2 : "183e5f5b-76ea-4f25-b15a-373b58b96634",
    second-lvl-support_tier1 : "d6b7e462-924b-4e5b-88e6-97d75103aeb9",
    second-lvl-support_tier0 : "3666aa92-691b-419f-8003-51b8a5420454",
    sec-inc-response_tier2 : "d64e1d59-31f9-450d-8bf9-ba10156a55cf",
    sec-inc-response_tier1 : "a3b7305e-aead-4abb-82ee-432cd81c5463",
    sec-inc-response_tier0 : "460572cc-c118-4441-bc37-4c6fdf2b98ed",
    cp-release-mgr_tier2 : "",
    cp-release-mgr_tier1 : "",
    cp-release-mgr_tier0 : "",
    cp-developer_tier2 : "78094547-6ed2-41f1-ab6a-a62065a033c8",
    cp-developer_tier1 : "c615a4af-5022-4e7f-81ab-a86ddbae65ba",
    cp-developer_tier0 : "13e919ea-5f7a-46d4-80b7-b857cb4530cb",
    app-owner_tier2 : "100f607b-797e-46fa-9c47-1bea43e73dde",
    app-owner_tier1 : "64764dc9-ff24-417f-a283-f427f6102f43",
    app-owner_tier0 : "aadbbc9f-bbe3-4c95-8b1e-3a52677c28f2",
    app-operator_tier2 : "6f04a56d-7ddf-4212-a3d7-c5cb0de9d51b",
    app-operator_tier1 : "3d8bde71-f942-41e6-bff0-a5c9dd2414a4",
    app-operator_tier0 : "49c4fa4c-90d3-4d11-a28e-ceb0abe2b73a",
    app-developer_tier2 : "66ad88af-b231-4522-960a-69be4c6dcfe5",
    app-developer_tier1 : "5c559b00-e82b-4a9d-b0ff-37bb301a9f6d",
    app-developer_tier0 : "2a522a3f-8b71-44f0-8435-53b28ad8dc62",
    db-access : "2a522a3f-8b71-44f0-8435-53b28ad8dc62"
  }
  is_iam_enabled = false

  subnet_id               = "/subscriptions/541ac1c2-8b44-4aac-abdf-3ce58dd8f753/resourceGroups/euho-e-rg-xtest-ntw/providers/Microsoft.Network/virtualNetworks/euho-e-vnet-xtest/subnets/snet-xtest-snet1"
  rsvault_name            = "euho-e-rsv-xtest"
  rsvault_rg_name         = "euho-e-rg-xtest-rsv"
  rsvault_share_policy_id = "/subscriptions/541ac1c2-8b44-4aac-abdf-3ce58dd8f753/resourceGroups/euho-e-rg-xtest-rsv/providers/Microsoft.RecoveryServices/vaults/euho-e-rsv-xtest/backupPolicies/bkpol-share-SHORT"

  storage_accounts = {
    s1 = {
      account_tier              = "Standard"
      account_replication_type  = "ZRS"
      shared_access_key_enabled = true

      storage_containers = {
        container1 = {
          container_access_type = "private"
        }
      }

      shares = {
        s1 = {
          quota       = 5
          access_tier = "Hot"
        }
      }

      blob_properties = {
        delete_retention_policy = {
          days = 30
        }
        container_delete_retention_policy = {
          days = 30
        }
        restore_policy = {
          days = 30
        }
        change_feed_enabled = true
        versioning_enabled  = true
      }
    }
  }
}